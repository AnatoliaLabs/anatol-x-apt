# NEXO: THE LAST CORE

1.11.1 PERFORMANS DÜZELTMESİ — Dinamik Dalgalar paketi; üç dalga görevi, YANKI ve KUYRUKLU meteorları, üç yeni dalga olayı ve iki farklı mini boss karşılaşmasıyla uzun turlardaki tekrarı azaltır.

1.10.0 KARMA İÇERİK paketi; YARIK GÖZCÜ mini bossu, NOVA KIRINTISI ve KRONO meteorları, üç yeni tur gelişimi ve üç özel dalga olayı ekler. Kalkan temasındaki sarı yön ışınları kaldırıldı; boss sırasında arka plan çizim yükü azaltıldı.

1.9.1 düzeltmesi, hızlı boss mermilerinin tek karede kalkan bandını atlamasını önleyen süpürülmüş çarpışma denetimi ekler ve boss devrildiğinde havada kalan son saldırıları zararsızlaştırır.

1.9.0 SİNEMATİK CEPHE; yönlü darbe ışıkları, meteor türlerine özgü kırılmalar, NOVA ışık cephesi ve hit-stop, boss giriş/faz/çöküş sahneleri, yedi dalga atmosferi, canlı menü/HUD sunumu ve kapsamlı prosedürel ses kimlikleri ekler. YILDIZ MİRASI kariyer altyapısı destekleyici olarak 25 seviye, altı rütbe ve tur sonu XP sunumuyla korunur.

1.8.0 TUR DERİNLİĞİ VE TEMPO paketi; ilk dalgalarda öğrenme alanı, daha yavaş zorluk artışı, 36 saniyelik dalgalar, 16 dalgalık HAYATTA KAL ve 12 dalgalık ÇEKİRDEK SINAVI hedefleri, yedi temalı dalga profili, her üç dalgada üçlü tur gelişimi seçimi ve kurtarma araları ekler.

1.7.1 arayüz paketi; canlı tehdit sayacı, tehlike vurgusu, duraklatmada aktif hedef ve kısayol özeti, tur sonu performans rütbesi, görünür klavye odağı ve azaltılmış hareket desteği ekler.

1.7.0 büyük aşaması; 8 dalgalık ÇEKİRDEK SINAVI modu, YARIK MUHAFIZI bossu ve daraltma darbesi, dalga protokolleri, ALAN TEMİZLEME küresi, DALGA NANİTLERİ ile EGZOTİK SÜZGEÇ yükseltmeleri, MUHAFIZ teması ve üç başarım ekler.

1.6.1 sürümü meteor doğuş adaletini yeniler: erken dalgalarda eşzamanlı tehditler aynı savunma koridorunda tutulur, çiftli formasyonlar 6. dalgada ve gerçek çapraz saldırılar 10. dalgada açılır.

1.6.0 sürümü; PRİZMA ve SÖMÜRÜCÜ göktaşları, NOVA aşırı şarj ve çekirdek onarım küreleri, GÜNEŞ ve SPEKTRA kalkan temaları, dört başarım ve yeni egzotik görev ekler.

1.5.0 sürümü; adaptif savaş müziği, meteor giriş parlamaları, NOVA enerji yörüngesi, boss öfke halesi, dinamik savaş renk atmosferi, sinematik dalga/tam isabet parlamaları, kalkan dönüş parçacıkları ve duraklatmada ses yumuşatma ekler.

Oyun açılışında **ATD NEXUS** stüdyo identi gösterilir; tıklama, Enter, Boşluk veya Esc ile atlanabilir.

1.4.0 sürümü; kombo ve tam isabet serisi bildirimleri, çarpışma süreli ekran dışı uyarıları, son can kalp atışı, NOVA hazır bildirimi ve hasarsız dalga bonusu ekler.

1.3.0 sürümünde kamera %14 geri çekildi; oyun alanı genişledi ve tehditler özellikle üst kenarda daha erken görünür.

Evrenin son enerji çekirdeğini koruduğunuz hızlı tempolu bir arcade savunma oyunu.
HTML5 Canvas ile yazılmıştır, tek dosyadır ve tamamen çevrimdışı çalışır.

## Kurulum sonrası

Masaüstü menünüzde **NEXO: The Last Core** simgesini bulacaksınız.
Uçbirimden başlatmak için:

```
nexo
```

Kurulu tarayıcı otomatik bulunur; belirli bir tarayıcı zorlamak için:

```
NEXO_BROWSER=firefox nexo
```

## Kontroller

| Girdi | İşlev |
|---|---|
| Fare / dokunmatik | Kalkanı imlecin yönüne döndürür |
| ← / → veya A / D | Kalkanı saat yönünde / tersine döndürür |
| Boşluk | NOVA patlaması (şarj dolduğunda) |
| P veya Esc | Duraklat / devam et |

## Oyun modları

- **SONSUZ** — Klasik mod; tempo zamanla kendiliğinden artar.
- **90 SANİYE** — Zamana karşı puan yarışı.
- **HAYATTA KAL** — Sabit 2 can, 16 temalı dalga hedefi; tempo kademeli tırmanır.
  Her 4 dalgada bir boss gelir; 16. dalgayı bitirirsen tur kazanılır.
- **ÇEKİRDEK SINAVI** — 12 yoğun dalga, 3 boss ve dalga protokolleri.

## Göktaşı türleri

`normal` · `fast` · `big` · `gold` · `ice` · `ghost` · `splitter` · `spiral` · `plated` · `magnetar` · `prism` · `leech` · `novaShard` · `chrono` · `echo` · `comet`

- **SPİRAL** burgu çizerek yaklaşır, açı okumasını zorlaştırır.
- **ZIRHLI** yalnızca tam ortadan gelen darbeyi kabul eder; kenar vuruşu seker.
- **MANYETİK** yaklaşırken kalkanı kendine çeker.

## Boss dövüşleri

Her dört dalgada bir boss gelir. **Dört farklı boss tipi sırayla döner** —
her birinin kendine özgü saldırı deseni ve devrilme kuralı var:

| Boss | Nasıl devrilir? | İmza |
|---|---|---|
| **ÇEKİRDEK GÖZÜ** | Attığı topları kalkanla yansıt, gövdeye geri gönder; füzeleri kalkanla tut | Pembe göz |
| **ZIRHLI ÖRS** | 4 zırh plakasını en hızlı **NOVA** söker; tutulan füzeler zırhı yavaşça aşındırır. Zırh açılınca topları geri yansıt | Mavi çelik plakalar |
| **İKİZ ÇEKİRDEK** | İki gövde aynı anda saldırır, canları ortaktır. Yansıtılan top en yakın gövdeye gider | Yeşil çift gövde + enerji bağı |
| **YARIK MUHAFIZI** | Çift yansımalı topları geri gönder; kalkan daraltma darbelerine dayan | Mor yarık + enerji darbesi |

Boss çubuğunda tipin adı, canı ve (ÖRS için) kalan plaka sayısı görünür.

## Atölye (kalıcı yükseltmeler)

19 yükseltme ve 7 kalkan teması. ÖZ, sektirilen göktaşlarından kazanılır.

## Kayıtlar

Rekorlar, ÖZ, yükseltmeler, başarımlar ve görevler tarayıcının yerel depolamasında
(`localStorage`) tutulur. Tarayıcı profilini silmedikçe korunur. Paket kaldırıldığında
oyun verileri **silinmez** (ayrı konum: `~/.local/share/nexo-browser`).

## Dosya konumları

| Yol | İçerik |
|---|---|
| `/usr/share/nexo/game/nexo.html` | Oyunun kendisi (tek dosya) |
| `/usr/games/nexo` | Başlatıcı betik |
| `/usr/share/applications/nexo.desktop` | Menü girdisi |
| `/usr/share/icons/hicolor/*/apps/nexo.png` | Simgeler (16–512 px, SVG dahil) |
| `/usr/share/man/man6/nexo.6` | Kılavuz sayfası |

## Kaldırma

```
sudo apt remove nexo
```

## Lisans

MIT — ayrıntılar için `/usr/share/doc/nexo/copyright`.
