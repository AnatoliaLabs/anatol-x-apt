// Anatolium — AutoConfig etkinleştirme (0.4.1 faz 1).
//
// Bu dosya kurulumdan sonra <uygulama dizini>/defaults/pref/autoconfig.js olur.
// Firefox bu dosyadaki "general.config.filename" değerini okuyup uygulama
// dizinindeki anatolium.cfg dosyasını, TÜM varsayılan pref dosyalarından SONRA
// çalıştırır. Zorunlu değerler orada tanımlıdır.
//
// Neden gerekli: defaults/pref/anatolium.js, motorun kendi varsayılanlarından
// (browser/omni.ja → defaults/preferences/firefox.js ve firefox-branding.js)
// ÖNCE yükleniyor. Ölçüldü: o dosyada yazılan "app.support.baseURL" ve
// "breakpad.reportURL" değerleri motorun kendi değerleri tarafından
// eziliyordu. AutoConfig en son çalıştığı için bu ezilmeyi engeller.
//
// Önemli: Firefox iki dosyada da ilk satırın yorum olmasını ister; aşağıdaki
// ilk satır bu yüzden yorumdur.
pref("general.config.filename", "anatolium.cfg");
pref("general.config.obscure_value", 0);
pref("general.config.sandbox_enabled", true);
