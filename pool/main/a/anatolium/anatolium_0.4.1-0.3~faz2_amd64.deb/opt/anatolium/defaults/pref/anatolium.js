// Anatolium application defaults. User choices in about:preferences still win.
// Appearance defaults; every value is user-editable in Kişiselleştir.
pref("anatolium.theme.preset", "pusula");
pref("anatolium.theme.accent", "");
pref("anatolium.theme.mode", "dark");
pref("anatolium.theme.glass", "soft");
pref("anatolium.theme.density", "normal");
pref("anatolium.theme.radius", 12);
pref("anatolium.theme.motion", true);
pref("anatolium.theme.contrast", "normal");
pref("anatolium.theme.previews", true);
pref("anatolium.theme.homePattern", true);
pref("anatolium.theme.singleRow", false);

// Engine features the Anatolium shell builds on.
pref("browser.tabs.groups.enabled", true);
pref("browser.tabs.splitView.enabled", true);
pref("browser.tabs.hoverPreview.enabled", false);

// Start page / new tab: the Anatolium page, never Firefox's Activity Stream.
pref("browser.startup.homepage", "chrome://browser/content/anatolium/home.xhtml");
pref("browser.startup.page", 3);
pref("browser.startup.firstrunSkipsHomepage", false);
pref("browser.startup.homepage_override.mstone", "ignore");
pref("browser.startup.homepage.abouthome_cache.enabled", false);
pref("browser.newtabpage.enabled", true);
pref("browser.aboutwelcome.enabled", false);
pref("browser.startup.upgradeDialog.enabled", false);
pref("browser.uitour.enabled", false);
pref("datareporting.policy.firstRunURL", "");

// One window chrome: Anatolium's header owns the titlebar buttons.
pref("browser.tabs.inTitlebar", 1);
pref("browser.shell.checkDefaultBrowser", false);
pref("browser.uidensity", 1);
pref("browser.toolbars.bookmarks.visibility", "never");
pref("sidebar.revamp", true);
pref("sidebar.visibility", "always-show");
pref("sidebar.verticalTabs", false);
pref("browser.tabs.unloadOnLowMemory", true);
pref("browser.ctrlTab.sortByRecentlyUsed", false);

// No sponsored or remote start-page content.
pref("browser.newtabpage.activity-stream.showSponsored", false);
pref("browser.newtabpage.activity-stream.showSponsoredTopSites", false);
pref("browser.newtabpage.activity-stream.feeds.section.topstories", false);
pref("extensions.pocket.enabled", false);
pref("browser.discovery.enabled", false);
pref("app.normandy.enabled", false);
pref("app.shield.optoutstudies.enabled", false);
pref("datareporting.healthreport.uploadEnabled", false);
pref("datareporting.policy.dataSubmissionEnabled", false);
pref("toolkit.telemetry.enabled", false);
pref("toolkit.telemetry.unified", false);

// The bundled engine is updated by the RPM, not by Mozilla's in-place updater.
pref("app.update.enabled", false);
pref("app.update.auto", false);

// ---------------------------------------------------------------------------
// 0.4.1 faz 1 — destek, geri bildirim ve sürüm notu bağlantıları
//
// ÖNEMLİ (ölçümle doğrulandı): Bu dosya, motorun kendi varsayılanlarından
// (browser/omni.ja → defaults/preferences/firefox.js ve firefox-branding.js)
// ÖNCE yüklenir. Yani burada yazılan bir değeri motor kendi varsayılanıyla
// EZER. Bu yüzden "app.support.baseURL" ve "breakpad.reportURL" gibi adresler
// BURADA DEĞİL, en son çalışan src/config/anatolium.cfg (AutoConfig) içinde
// tanımlanır. Buradaki satırlar yalnızca belge/niyet amaçlıdır ve tek başına
// etkili olmayabilir.
//
// Doğrulanan pref adları (Firefox ESR 153.6.0, browser/omni.ja):
//   app.support.baseURL, app.feedback.baseURL, app.releaseNotesURL,
//   app.releaseNotesURL.aboutDialog, app.releaseNotesURL.prompt,
//   app.update.url.manual, app.update.url.details, breakpad.reportURL
// Bu sürümde BULUNMAYANLAR (uydurulmadı): app.privacyURL, app.helpMenu.
// ---------------------------------------------------------------------------
pref("app.support.baseURL", "chrome://browser/content/anatolium/support.xhtml#");
pref("app.support.vendor", "Anatolia Labs");
pref("app.feedback.baseURL", "chrome://browser/content/anatolium/support.xhtml#");
pref("app.releaseNotesURL", "chrome://browser/content/anatolium/support.xhtml#");
pref("app.releaseNotesURL.aboutDialog", "chrome://browser/content/anatolium/support.xhtml#");
pref("app.releaseNotesURL.prompt", "chrome://browser/content/anatolium/support.xhtml#");
pref("app.update.url.manual", "");
pref("app.update.url.details", "");
pref("startup.homepage_welcome_url", "");
pref("startup.homepage_override_url", "");
pref("startup.homepage_welcome_url.additional", "");

// ---------------------------------------------------------------------------
// 0.4.1 faz 1 — çökme bildirimi
//
// Üç katman birlikte uygulanır:
//   1) application.ini  → [Crash Reporter] Enabled=0, ServerURL boş
//   2) bu pref'ler      → çökme raporu gönderimi ve bildirimleri kapalı
//   3) launcher         → MOZ_CRASHREPORTER_DISABLE=1
// "breakpad.reportURL" yalnızca bu pref ile kapatılabilir; politika dosyası
// bu adı kilitleyemez (motorun izin verdiği pref önekleri arasında değil).
// ---------------------------------------------------------------------------
pref("breakpad.reportURL", "");
pref("browser.tabs.crashReporting.sendReport", false);
pref("browser.crashReports.unsubmittedCheck.enabled", false);
pref("browser.crashReports.unsubmittedCheck.autoSubmit2", false);

// Ağa çıkan motorda açık kalan nokta: yakalama portalı yoklaması
// (detectportal.firefox.com). Kapatıldı.
pref("network.captive-portal-service.enabled", false);
// Güvenli Gezinme kapatılmaz; değeri ve kilit durumu anatolium.cfg içinde
// yönetilir (true, kilitli değil). Burada false yazmak varsayılanı ezip
// kullanıcıya kapalı bir koruma göstermişti; faz 2'de düzeltildi.
pref("browser.safebrowsing.malware.enabled", true);
pref("browser.safebrowsing.phishing.enabled", true);
