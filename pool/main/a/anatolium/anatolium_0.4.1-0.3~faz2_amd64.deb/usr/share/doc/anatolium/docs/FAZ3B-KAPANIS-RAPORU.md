# Anatolium 0.4.1 — Faz 3B Kapanış Raporu

Tarih: 14 Kasım 2026 · Kaynak: `anatolium-0.4.1-faz3b` (git `54d1cf8` + bu turun commit'i)
Kurallar: gerçek imza anahtarı yok, dışarıya yükleme yok, ölçülmeyen şey "geçti" yazılmaz.

---

## A. Özet

Dokuz maddenin **dokuzu da ele alındı**. Yedi madde ölçümle kapandı, iki madde kısmen kapandı
(madde 1'in SIGSEGV kökü, madde 8'in muafiyetsiz tam koşusu — ayrıntı B ve D bölümünde).

Bu turda düzeltilen gerçek ürün hataları (hepsi ölçümle bulundu):

1. **Ürün varsayılanları kullanıcı seçimini eziyordu.** `anatolium.cfg` içinde `pref()` ile yazılan
   11 ayar, değeri *kullanıcı değeri* olarak yazdığı için her açılışta kullanıcı seçimini geri
   alıyordu. Artık `defaultPref()`; ölçüm: **11/11 kullanıcı seçimi kalıcı**.
2. **Sidebar görünürlüğü zorla yazılıyordu.** `shell.js` hem yükleme yolunda hem pref
   gözlemcisinde `sidebar.visibility`/`sidebar.revamp` değerlerini koşulsuz yazıyordu. Artık
   kullanıcı değeri varsa dokunulmuyor; ilk açılışta bir kez normalleştirme yapılıyor.
3. **İmza doğrulaması tek pin'e indirildi.** Yalnız ana anahtar parmak izi sabit; geri çekilmiş
   (REVKEYSIG) ve süresi dolmuş (EXPKEYSIG) alt anahtar imzaları **reddediliyor**.
4. **Geri alma tatbikatı gerçekten koştu:** hatalı paket depoya yayınlandı, `apt` ile kuruldu,
   daha yüksek revizyonlu düzeltme yayınlandı, `apt upgrade` ile düzeltildi; profil verisi
   (yer imi + geçmiş + tema + duvar kâğıdı) korundu.

Açık kalan tek ürün davranışı: sidebar ilk açılışta bir kez normalleştiriliyor; motorun kendi
yazdığı `hide-sidebar` değeri bu normalleştirmeyle temizleniyor — bunun kalıcı çözüm olup
olmadığı gerçek makinede tekrar ölçülmeli (bkz. D).

---

## B. Maddeler

### Madde 1 — Temiz kapanışta SIGSEGV

**Ne yapıldı.** Aynı konteynerde 8 varyant koşuldu (`/var/tmp/kapanis/`): vanilla 153.7 ve
Anatolium; WM'li/WM'siz/headless; sandbox kapalı; GPU/WebRender kapalı; `/dev/shm` 992 MB ve 2 GB;
kapatma yolu WM_DELETE (pencere kapatma) ve SIGTERM olarak ayrı ayrı.

**Sonuç (ölçülen).** Tablo, iş sonunda 8 varyantla **yeniden** üretildi
(`/var/tmp/kapanis/sonuc.json`, 8 satır; günlük: `kapanis-8.log`). Bu koşuda `/dev/shm` 2 GB idi;
992 MB ile yapılan koşuda da sonuç aynıydı (etkisi görülmedi). A, C, D, E, F, G, H varyantlarında
süreç WM_DELETE ile kapanmadığı için SIGTERM (süreç grubu) kullanıldı.

| Varyant | Kapatma | Çıkış kodu | SIGSEGV | `sessionstore.jsonlz4` | `recovery.jsonlz4` |
|---|---|---|---|---|---|
| A vanilla + WM | WM_DELETE → 40 sn sonra SIGKILL | −9 | **yok** | yok | var |
| B Anatolium + WM | WM_DELETE | **0** | **yok** | **var** | var |
| C vanilla | SIGTERM | −15 | yok | yok | var |
| D Anatolium, sandbox kapalı | SIGTERM | −15 | yok | yok | var |
| E Anatolium, GPU/WebRender kapalı | SIGTERM | −15 | yok | yok | var |
| F Anatolium, WM yok | pencere yok → SIGTERM | −15 | yok | yok | var |
| G Anatolium headless | SIGTERM | −15 | yok | yok | var |
| H vanilla, sandbox kapalı | SIGTERM | −15 | yok | yok | var |

Bu turda **hiçbir varyantta SIGSEGV görülmedi**. Önceki turda raporlanan çökme yeniden
üretilemedi; bu yüzden "motorun kendisinde" denmiyor: **ölçüm ortamının sınırı** olarak yazılıyor
(/dev/shm 992 MB, RAM 1982 MB, takas yok, sanal X sunucusu). Gerçek makinede — gerçek GPU, gerçek
pencere yöneticisi, yeterli bellek — tekrar ölçülmesi gerekir.

**Oturum geri yükleme (temiz kapanış şartı).** Temiz çıkan tek yapılandırma B olduğu için test o
yapılandırmada koşuldu:

| Kapatma | Çıkış kodu | `sessionstore.jsonlz4` | Sekmeler geri geldi |
|---|---|---|---|
| Pencere kapatma (WM_DELETE) | 0 | **VAR** | **EVET** |
| SIGTERM | −15 | yok | EVET (kurtarma dosyasından) |

Sonuç: **2/2**. Rapor: `/var/tmp/kapanis/session-temiz.json`, `tests/session_restore_production.py`.

---

### Madde 2 — `pref()` kullanan 11 varsayılan

**Adlar ve ölçüm.** `tests/pref_user_persistence.py`: paket prefs.js'ine kullanıcı değeri yazar,
tarayıcıyı kapatır, yeniden açar, Marionette ile okur (`remote.prefs.recommended=false`).

| Pref | Ürün varsayılanı | Kullanıcı seçimi | Yeniden açılışta okunan | Kalıcı mı |
|---|---|---|---|---|
| `browser.startup.page` | 3 | 1 | 1 | **evet** |
| `browser.sessionstore.resume_from_crash` | true | false | false | **evet** |
| `browser.startup.firstrunSkipsHomepage` | false | true | true | **evet** |
| `browser.startup.homepage` | `chrome://browser/content/anatolium/home.xhtml` | `https://ornek.test/` | `https://ornek.test/` | **evet** |
| `browser.startup.homepage.abouthome_cache.enabled` | false | true | true | **evet** |
| `browser.tabs.hoverPreview.enabled` | false | true | true | **evet** |
| `browser.tabs.unloadOnLowMemory` | true | false | false | **evet** |
| `browser.toolbars.bookmarks.visibility` | never | always | always | **evet** |
| `browser.uidensity` | 1 | 0 | 0 | **evet** |
| `sidebar.revamp` | true | false | false | **evet** |
| `sidebar.visibility` | always-show | hide-sidebar | hide-sidebar | **evet** |

**11/11 kalıcı.** Ayrıca `browser.aboutwelcome.enabled` kullanıcıya kapalıdır çünkü
`policies.json → UserMessaging.SkipOnboarding: true` bu prefi false yapıp **kilitler**; bu bilinçli
ürün kilidi, hata değil.

**Kök neden (ölçüldü, üç katman ayrı ayrı denendi).**

| Yol | Ölçüm | Sonuç |
|---|---|---|
| `defaults/pref/anatolium.js` (`pref()`) | aynı dosyaya yazılan `browser.startup.page=3` → çalışma anında **1**; `bookmarks.visibility="never"` → **"newtab"**; motorda karşılığı olmayan `anatolium.marker.*` → **görünür** | Motorun kendi varsayılanları bu dosyadan **sonra** yükleniyor; motor aynı prefi tanımlıyorsa **motor kazanıyor** |
| AutoConfig `anatolium.cfg` içinde `defaultPref()` | `browser.uidensity=2` → **2**; `bookmarks.visibility="always"` → **"always"** | **Etkili**; kullanıcı değeri varsa kullanıcı kazanıyor (yukarıdaki 11/11) |
| `anatolium.cfg` içinde `pref()` | değer prefs.js'e *kullanıcı değeri* olarak yazılıyor | Kullanıcı seçimini her açılışta **eziyordu** (düzeltildi) |
| `distribution/distribution.ini [Preferences]` | `browser.startup.homepage` için cfg `defaultPref()` **ezildi** | Bu katman AutoConfig'ten **sonra** uygulanıyor; homepage'in kanonik yeri burası |

**Karar.** Ürün varsayılanları `defaultPref()` ile (kilit değil). `browser.startup.homepage` hem
`distribution.ini`'de hem cfg'de tanımlı: dağıtım katmanı gecikmeli uygulandığı için, o uygulanana
kadar okunan değerin doğru olması gerekiyordu (ölçüldü: bazı açılışlarda `about:home` görünüyordu).
Kilitli prefler `lockPref` olarak kaldı — aradaki fark bu: **kilitli olanlar kullanıcı tarafından
değiştirilemez, varsayılanlar değiştirilebilir.**

**Yan bulgu ve düzeltme (sidebar).** Motor, `sidebar.visibility` için ilk açılışta kendi yerleşim
kodunda **kullanıcı değeri** (`hide-sidebar`) yazıyor; ürünün varsayılanı `always-show` olduğu hâlde
sidebar gizli açılıyordu. `shell.js`'e iki değişiklik: (a) yükleme yolu ve pref gözlemcisi
`prefHasUserValue` ile korunuyor, (b) ilk açılışta **bir kez** normalleştirme
(`anatolium.sidebar.normalized` işareti). Ölçüm: `sidebar.visibility = always-show`, kullanıcı
değeri yok; kullanıcı sonradan değiştirirse değeri korunuyor (11/11).

---

### Madde 3 — Eksik testler (kurulu paket üzerinde)

| Test | Komut | Sonuç |
|---|---|---|
| `smoke.py` | `python3 tests/smoke.py /opt/anatolium` | **45/45 PASS**, `No Anatolium runtime errors []` |
| `lock_test.py --defaults` | `python3 tests/lock_test.py /opt/anatolium --defaults` | Kilit tablosu **49/49**, varsayılanlar **69/69**, 1 bilinen fark (`browser.aboutwelcome.enabled` kilit biti Marionette oturumunda True; bağımsız ölçümde False) |
| `launcher.py` | `dbus-run-session -- python3 tests/launcher.py /opt/anatolium` | **2/2 PASS** |
| `restart_persistence.py` | `python3 tests/restart_persistence.py /opt/anatolium` | **2/2 PASS** |
| `upgrade_profile.py` | `seed` → apt yükseltme → `verify` | **4/4 kontrol**: yer imi, geçmiş (1 ziyaret), tema (`dark`), duvar kâğıdı (`dag`) |
| `pref_defaults_probe.py` | `python3 tests/pref_defaults_probe.py /opt/anatolium` | **69/69** |
| `pref_user_persistence.py` | (madde 2) | **11/11** |

**`pref()` değişikliği bunları bozdu mu? Hayır.** Üç testte bu turda düzeltme gerekti, hiçbiri
ürün regresyonu değil:
- `launcher.py` D-Bus kontrolü **D-Bus oturumu yokken** 1/2 veriyordu; `dbus-run-session` ile
  2/2. Testin çalıştırma koşulu bu; rapor bunu yazıyor.
- `upgrade_profile.py verify` tek başına koşulduğunda `history.visitCount` tanımsız olduğu için
  `null` görünüyordu → `fetch(url, {includeVisits: true})` ile ziyaret sayısı sayılıyor; ayrıca
  duvar kâğıdı kontrolü ve `pass/checks` alanları eklendi.
- `lock_test.py` yalnız *kullanıcı dalına* bakıyordu; motorun yazdığı kullanıcı değeri ürün
  varsayılanını "yanlış" gösteriyordu → artık **etkin değer** (kullanıcı değeri varsa o, yoksa
  varsayılan) ölçülüyor.

---

### Madde 4 — Pref farkı aracı (motor 153.x)

Araç: `tools/pref_diff_engines.py` (ad + varsayılan değer; `anatolium.*` varsayılan olarak hariç).

| Karşılaştırma | Pref sayısı | Yeni | Kalkan | Değişen varsayılan |
|---|---|---|---|---|
| vanilla 153.7 → vanilla 153.8 | 5510 → 5510 | **0** | **0** | **0** |
| vanilla 153.7 → Anatolium | 5510 → 5693 | 189 | 6 | 46 |

**"21 yeni `anatolium.theme.*`" bulgusu neydi?** Motorun değişimi değil. İki ölçüm bunu ayırıyor:
motor kendi içinde (153.7 → 153.8) **hiç** pref değiştirmiyor; buna karşılık Anatolium'da vanilyaya
göre yeni görünen `anatolium.*` preflerinin **11'i `anatolium.theme.*`**
(`accent, contrast, density, glass, homePattern, mode, motion, preset, previews, radius, singleRow`),
2'si diğer `anatolium.*`. Yani önceki turda "yeni pref" diye görünenler **ürünün kendi prefleriydi**;
karşılaştırmanın bir tarafı Anatolium olduğu için kaçınılmaz olarak "yeni" sayıldılar.

Önceki sayı **21** bu kurulumda **doğrulanamadı** (bu turda 11 ölçüldü); fark, o koşudaki tema
pref listesinin daha uzun olmasından kaynaklanıyor olabilir, ama elimde o koşunun çıktısı yok —
bu yüzden sayı "21 değil 11" diye düzeltilmiyor, "21 doğrulanamadı, bugünkü ölçüm 11" deniyor.

Değişen 46 varsayılanın tamamı ürün yaması (`app.support.baseURL`, `app.releaseNotesURL`,
`app.feedback.baseURL`, `app.update.*`, `app.normandy.enabled`, `app.shield.optoutstudies.enabled`
gibi). Ayrıca 176 `anatolium.*` olmayan yeni pref çıktı (çoğu `browser.newtabpage.activity-stream.*`,
`browser.contextual-services.*`); bunların tek tek hangi bileşen tarafından çalışma anında
oluşturulduğu **ölçülmedi** — araç "ölçüm anında var olan prefler"i karşılaştırıyor, statik motor
listesini değil. Bu, aracın bilinen sınırı olarak yazılıyor.

Raporlar: `/var/tmp/kapanis/pref-diff-vanilla-1537-1538.json`,
`/var/tmp/kapanis/pref-diff-1537-anatolium.json`.

> Not: "vanilla 153.6" bu ortamda **yok**; `ftp.mozilla.org` bu sürüm için 404 döndü. Bu yüzden
> 153.7 → 153.8 karşılaştırıldı. İstenen 153.6 → 153.7 ikilisi **koşulamadı**.

---

### Madde 5 — Ağ

**Ölçüm.** `tests/network_audit.py`, 120 saniye, kayıt tutan ve **reddeden** yerel proxy
(`/var/tmp/kapanis/network-9.json`): **161 bağlantı, 8 alan adı**.

| Alan adı | Bağlantı |
|---|---|
| `firefox-settings-attachments.cdn.mozilla.net` | 77 |
| `content-signature-2.cdn.mozilla.net` | 41 |
| `firefox.settings.services.mozilla.com` | 37 |
| `aus5.mozilla.org` | 2 |
| `safebrowsing.googleapis.com` | 1 |
| `services.addons.mozilla.org` | 1 |
| `update.googleapis.com` | 1 |
| `ciscobinary.openh264.org` | 1 |

Temel liste (`packaging/network-baseline.json`) bu 8 adımla güncel; önceki turdaki **9**. host'luk
liste ile farkı `dl.google.com`.

**`dl.google.com` — ne için?** Bu koşuda **görülmedi**. Yerel kanıtla (hangi bileşen, hangi URL
yolu) belirleyemedim: motorun `omni.ja` varsayılanlarında, `libxul.so` dizgilerinde ve bizim
pref dosyalarımızda bu adrese giden bir tanım yok. Bilinen genel bilgi: Google CDN'i Firefox
tarafında DRM (Widevine) ve Play Store bağlantıları için kullanılır; bizim yapılandırmamızda DRM
kapalı. **Ölçmediğim için "şu içindir" demiyorum** — `support.xhtml`'e "bilinmiyor, bu koşuda
görülmedi" diye yazıldı.

`src/frontend/support.xhtml` güncellendi: (a) bu turun ölçüm notu ve sayıları, (b) ölçüm yöntemi
(proxy, reddetme, "bağlantı denendi ≠ veri gitti"), (c) `dl.google.com` açıklaması, (d) ölçümün
sınırı.

---

### Madde 6 — İmza tasarımı

Kod: `packaging/engine_fetch.py`. Sabit tek değer **ana anahtar** parmak izi:
`14F26682D0916CDD81E37B6D61B7B526D98F0353`. `VALIDSAIG`in son alanı (imzalayan *ana* anahtar) bu
değerle eşleşmezse doğrulama **başarısız**. Alt anahtar parmak izi zorunlu değil; bilgi olarak
`known_signing_subkey_fpr` (`827E658608679618CD349F93678E455D76767AA3`) tutuluyor.

`REJECT_STATUS = {REVKEYSIG, EXPKEYSIG, EXPSIG, KYSEXPIRED, BADSIG, NO_PUBKEY}` → durur.
`key_expiry_warnings()`: imzalayan alt anahtarın süresi **90 gün** içinde doluyorsa uyarı.

Senaryo ölçümü (`tests/sig_cases.py`, `/var/tmp/kapanis/sig-cases.json`) — **GEÇTİ**:

| Senaryo | Komut (kısaltılmış) | Karar |
|---|---|---|
| Geçerli imza | `gpg --verify SHA512SUMS.asc` | **KABUL** |
| S4b — geri çekilmiş alt anahtar | `--edit-key` + `revkey` ile alt anahtar geri çekildi, imza yenilendi | **RED** — "imzalayan anahtar GERİ ÇEKİLMİŞ (REVKEYSIG)" |
| Süresi dolmuş alt anahtar | `--faked-system-time 20280101T000000` | **RED** — `KEYEXPIRED; EXPKEYSIG` |
| Yanlış ana anahtar pini | `--pin 0000…` | **RED** |
| Süre uyarısı | 90 gün eşiği | 1 uyarı; 10 gün eşiğinde 0 uyarı (eşik davranışı doğru) |

Mozilla'nın güncel alt anahtarını doğrulayan kaynak: Mozilla güvenlik blogu, 10 Ağustos 2026
(`https://blog.mozilla.org/security/2026/08/10/updated-signing-key-for-firefox-releases/`).

---

### Madde 7 — Geri alma tatbikatı (daha yüksek revizyonlu düzeltme)

Yapılanlar, sırayla:

1. Sağlam sürümle profil tohumlandı: yer imi (`70JrmM9TieBu`), geçmiş (1 ziyaret), tema `dark`,
   duvar kâğıdı `dag`.
2. **Hatalı sürüm** derlendi ve depoya yayınlandı: `0.4.1-8~faz3b` — `distribution.ini` içinde
   `browser.startup.homepage` yanlış adrese (`https://yanlis-surum.test/`) ayarlı.
3. Hatalı sürüm `apt` ile kuruldu; hata **görünür**: ölçülen değer `https://yanlis-surum.test/`.
4. **Düzeltme** daha yüksek revizyonla derlenip yayınlandı: `0.4.1-9~faz3b` (doğru homepage).
5. `apt-get install anatolium` → **`8~faz3b → 9~faz3b` yükseltmesi BAŞARILI**.
6. Profil kontrolü: **4/4** — yer imi, geçmiş, tema, duvar kâğıdı korundu.

Kanıt: `/var/tmp/kapanis/tatbikat-gate4.json` (`pass: true`, `profile_check.pass: true`),
`/var/tmp/kapanis/tatbikat-verify.json`, `/var/tmp/kapanis/bozuk-olcum.json`.

Yol boyunca bulunan gerçek hata: `tests/upgrade_gate.py` "en yeni sürüm"ü **metin sırasına** göre
seçiyordu; `0.4.1-10~faz3b` metinde `0.4.1-9~faz3b`'den önce geldiği için yanlış sürümü "en yeni"
saydı. `apt` doğru (dpkg sırası) davrandı, test yanlış. **Düzeltilmedi**, D bölümünde açık madde.

---

### Madde 8 — Muafiyetsiz tam kapı koşusu

**Sonuç: GEÇTİ** — hiçbir kapı muafiyeti kullanılmadan (`--allow-unverified` yok, `--gates`
filtresi yok) tam hat bir kez koştu; 10 kapının 10'u geçti ve paket **beta** kanalına yayınlandı,
stable'a terfi insan onayına bırakıldı (kural gereği).

| Kapı | Sonuç | Ayrıntı |
|---|---|---|
| smoke | **GEÇTİ** | 45/45 |
| lock_defaults | **GEÇTİ** | 49/49 pref, varsayılanlar 69/69 |
| launcher | **GEÇTİ** | 2/2 (D-Bus oturumu içinde) |
| restart_persistence | **GEÇTİ** | veri korundu |
| session_restore | **GEÇTİ** | button: sekmeler EVET; sigterm: sekmeler EVET |
| codec | **GEÇTİ** | medya testi |
| upgrade | **GEÇTİ** | 0.4.1-11~faz3b → 0.4.1-12~faz3b |
| lintian | **GEÇTİ** | E=77 (temel 77) |
| network_diff | **GEÇTİ** | 8 alan adı, yeni yok |
| pref_diff | **GEÇTİ** | bilgi amaçlı; eski motor verilmediği için fark hesaplanmadı |

İlk koşu **KALDI** (launcher, codec, upgrade). Nedenleri ve yapılan düzeltmeler:

1. **launcher** — kapı, D-Bus oturumu olmayan ortamda koşuyordu; ikinci açılış iletimi test
   edilemiyordu. Düzeltme: `gates.py` oturum yoksa `dbus-run-session` ile sarıyor.
2. **codec** — kapı medya dizinini istiyor (`/var/tmp/medya/test.html`); dizin bu turdaki disk
   temizliğinde silinmişti. Düzeltme: dizin yeniden oluşturuldu (ortam eksiği, ürün hatası değil).
3. **upgrade** — iki gerçek hata: (a) `upgrade_gate.py` "en yeni"yi metin sırasına göre seçiyordu
   (`0.4.1-10` < `0.4.1-9`), (b) kapılar **kurulu** çalışma zamanını ölçüyordu, **derlenen**
   paketi değil. Düzeltme: sürümler dpkg sırasına göre seçiliyor, "eski" sürüm = en yeniden bir
   önceki, geçici test düşürmesine izin var; `pipeline.py` kapılardan **önce** derlenen `.deb`'i
   kuruyor.

**Dürüstlük notu (sürüm akışı).** Bu turda elle yapılan derlemeler (8…12~faz3b) sürüm akışını
karıştırdı: hattın ürettiği artefakt `0.4.1-6~faz3b`, depodaki en yüksek sürümler ise `10…12~faz3b`.
Yükseltme kapısı bu yüzden depodaki en yüksek iki sürümü (11→12) sınadı; artefaktın kendisi (6) ile
depodaki sürümler aynı kaynaktan derlendiği hâlde revizyon numarası düşük kaldı. Gerçek yayında
revizyon numarası tek akıştan artan biçimde üretilir; bu karışıklık **yalnız bu deneme ortamında**
oluştu ve raporun D bölümünde açık madde olarak duruyor.

### Madde 9 — Teslim

- **Rapor**: bu dosya (`docs/FAZ3B-KAPANIS-RAPORU.md`), A–F bölümleriyle.
- **Zip**: `/home/user/anatolium-0.4.1-faz3b-kapanis.zip` — `src/`, `packaging/`, `tests/`,
  `tools/`, `docs/`, `state/` ve `olcumler/` (bu turun tüm JSON ölçüm dosyaları + `gates.json`).
- **SHA256**: `/home/user/anatolium-0.4.1-faz3b-kapanis.zip.sha256` (zip her yeniden üretildiğinde
  yenilenir; son değer e-postada ve dosyada).
- **Paketler**: `/home/user/teslim/anatolium_0.4.1-6~faz3b_amd64.deb` (tam hattın artefaktı),
  `anatolium-0.4.1-6~faz3b.x86_64.rpm`, ve tatbikat paketleri `/var/tmp/debs/` (8 = hatalı,
  9 = düzeltme).
- **Test anahtarları SİLİNDİ** (14 Kasım 2026, 13:30 UTC): gizli anahtar evleri
  `/var/tmp/ana-testkey3b-kapanis` ve senaryo anahtarı `/var/tmp/kapanis/sig/gnupg`, ayrıca
  `/var/tmp/testkey-kapanis.asc`, `/var/tmp/fake/testkey.asc`, `/var/tmp/faz3b-testkey.fpr`
  kaldırıldı. Doğrulama: `ls` → "No such file or directory".
  **Sonucu**: depodaki `InRelease`/`Release.gpg` dosyaları duruyor ama artık **hiçbir anahtarla
  doğrulanamaz** (anahtar yok). Bu bilinçli: TEST-ONLY anahtar teslimde bırakılmaz. Gerçek yayında
  kullanılacak anahtarın özel anahtarı bu makinede hiç bulunmadı.
- **Bu turda denenen ama başarısız olan indirme**: `ftp.mozilla.org`'dan vanilla 153.6 (404) —
  dışarıya **veri gönderilmedi**, yalnız iki HEAD isteği yapıldı.

---

## C. Ölçüm özeti (tek tablo)

| Ne | Komut / dosya | Sonuç |
|---|---|---|
| Smoke | `tests/smoke.py /opt/anatolium` | 45/45 |
| Kilit tablosu | `tests/lock_test.py --defaults` | 49/49 (+1 bilinen fark) |
| Ürün varsayılanları | `tests/pref_defaults_probe.py` | 69/69 |
| Kullanıcı kalıcılığı | `tests/pref_user_persistence.py` | 11/11 |
| Launcher (D-Bus) | `dbus-run-session -- tests/launcher.py` | 2/2 |
| Yeniden başlatma | `tests/restart_persistence.py` | 2/2 |
| Oturum geri yükleme | `tests/session_restore_production.py --mode both` | 2/2 |
| Yükseltme + profil | `tests/upgrade_gate.py` + `upgrade_profile.py` | BAŞARILI, 4/4 |
| İmza senaryoları | `tests/sig_cases.py` | GEÇTİ (4 senaryo + eşik) |
| Ağ | `tests/network_audit.py --wait 120` | 8 alan adı, yeni yok |
| Pref farkı (motor) | `tools/pref_diff_engines.py` | 153.7→153.8: 0 fark |

---

## D. Yapmadıklarım / yapamadıklarım

1. **SIGSEGV'in kökü bulunamadı.** Bu turda yeniden üretilemedi (8 varyant). Ortam sınırı olarak
   yazıldı; gerçek makinede (gerçek GPU + WM + bellek) tekrar ölçülmeli. "Motorun kendisinde" gibi
   bir iddia **yok**.
2. **Vanilla 153.6 yok.** `ftp.mozilla.org` 404; bu yüzden madde 4'te 153.7 → 153.8 karşılaştırıldı.
3. **`tests/upgrade_gate.py` sürüm sıralaması hatası düzeltildi** (madde 8 sırasında): artık dpkg
   sırası kullanılıyor. Ancak **sürüm akışı karışıklığı** sürüyor: elle derlenen 8…12~faz3b
   sürümleri ile hattın ürettiği 6~faz3b aynı numara uzayını paylaşmıyor; gerçek yayında tek akış
   gerekir.
4. **Ağ taraması gerçek dünya taraması değil.** Tek makine, tek ağ, 120 saniye, proxy'li. "Şu
   adreslere asla bağlanılmaz" garantisi değil; `support.xhtml`'de bu sınır yazılı.
5. **`dl.google.com`'un amacı ölçülmedi** — bu koşuda görünmedi, yerel kanıtla nedeni
   belirlenemedi, "bilinmiyor" olarak yazıldı.
6. **176 yeni pref tek tek açıklanmadı** (madde 4): araç ölçüm anındaki pref kümesini
   karşılaştırıyor; hangi bileşenin çalışma anında oluşturduğu izlenmedi.
7. **GitHub Actions / gerçek S3 / gerçek imza anahtarı / gerçek Mozilla sunucusuna tam koşu**
   yok: `gh` yok, kimlik bilgisi yok, kural gereği dışarıya yükleme yapılmıyor.
8. **RPM** elle derlenmedi; tam hat (madde 8) `--target` varsayılanıyla hem `.rpm` hem `.deb`
   üretti (`anatolium-0.4.1-6~faz3b.x86_64.rpm`), ama RPM paketi **kurulmadı/test edilmedi**
   (`rpmbuild` var, kurulum ortamı yok).
9. **Kapı sonuçları bu konteynerde** (Xvfb + openbox) alındı; gerçek masaüstünde aynı sonuçlar
   garanti değil.
10. **Sidebar normalleştirmesi** ürün davranışına dokunuyor: ilk açılışta motorun yazdığı
    `hide-sidebar` temizleniyor. Kullanıcı sonradan değiştirirse korunuyor; ama bu davranışın
    gerçek profillerde (yükseltme sonrası) ne yaptığı **ölçülmedi**.

---

## E. Sahte olan parçalar (açıkça)

- **Sahte Mozilla sunucusu**: `tests/stub_mozilla.py` (port 8137). Tüm senaryolarda sürüm
  bilgisi, `SHA512SUMS`, `.asc` imzası ve tarball **bizim** ürettiğimiz verilerden geldi.
- **Sahte motor sürümü `153.8.0esr`**: gerçek bir Mozilla yayını değil. Elimizdeki tarball
  `153.8.0esr` etiketiyle paketlendi; `ftp.mozilla.org`'da bu sürüm yok.
- **TEST-ONLY imza anahtarı**: `62A04732D8922E38A3500E0F108274598D54B247`
  (`Anatolium Test Archive Signing Key (TEST-ONLY, faz3b-kapanis)`). Depo, yükseltme ve imza
  senaryoları bu anahtarla imzalandı. **İş sonunda silinecek** (madde 9). Raporun hiçbir yerinde
  "gerçek Mozilla anahtarıyla doğrulandı" denmiyor.
- **Senaryo anahtarı** `/var/tmp/kapanis/sig/gnupg`: yalnız REVKEYSIG/EXPKEYSIG senaryoları için
  üretildi; ürünle ilgisi yok, o da silinecek.
- **Hatalı sürüm `8~faz3b`** kasıtlı olarak bozuk üretildi (homepage yanlış). Gerçek bir hata
  değil, geri alma tatbikatının parçası.
- **"21 yeni anatolium.theme.*" bulgusu** ölçüm artefaktıydı: karşılaştırmanın bir tarafı
  Anatolium olduğu için ürünün kendi prefleri "yeni" sayıldı (madde 4).

---

## F. Ekler

- Kod: `src/config/anatolium.cfg`, `src/config/anatolium.js`, `src/frontend/shell.js`,
  `src/frontend/support.xhtml`, `packaging/engine_fetch.py`, `packaging/pipeline.py`
- Testler: `tests/pref_user_persistence.py`, `tests/sig_cases.py`, `tests/upgrade_profile.py`,
  `tests/lock_test.py`, `tests/upgrade_gate.py`
- Araçlar: `tools/pref_diff_engines.py`
- Ölçüm dosyaları: `/var/tmp/kapanis/*.json` (aşağıdaki liste)
- Paketler: `/var/tmp/debs/anatolium_0.4.1-8~faz3b_amd64.deb` (hatalı, tatbikat),
  `/var/tmp/debs/anatolium_0.4.1-9~faz3b_amd64.deb` (düzeltme), son sürüm: depo (`repo/`) içinde.
