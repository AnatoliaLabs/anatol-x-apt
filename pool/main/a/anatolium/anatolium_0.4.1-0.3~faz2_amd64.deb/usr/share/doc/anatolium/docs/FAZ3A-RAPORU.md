# Anatolium 0.4.1 — Faz 3A Raporu: yerel apt deposu + imza zinciri

Tarih: 14 Kasım 2026 · Sürüm **0.4.1** (yalnızca derleme numarası değişti:
`0.4.1-0.3~faz2` → `0.4.1-0.4~faz3a`) · İmza: bu oturumda üretilmiş
**TEST-ONLY** RSA-4096 geçici anahtar (iş sonunda **silindi**)

---

## A. Özet (5 satır)

1. İki kanallı (`stable`, `beta`), `Acquire-By-Hash: yes` alanlı, SHA512 ile imzalanmış **statik apt deposu** üretildi; temiz Debian testing'de `apt install anatolium` çalıştı (77 → 306 paket).
2. **reprepro kullanılmadı**: ölçüldü ki reprepro 5.3.1 yeni sürüm eklenince eskiyi siliyor (son 3 sürüm tutulamıyor) ve `Acquire-By-Hash` alanını yazamıyor → depo `packaging/repo.py` ile doğrudan üretildi.
3. `anatolium-archive-keyring` paketi (anahtar + conffile `.sources`) yazıldı; **TEST-ONLY** anahtarla **üretim modunda derleme reddediliyor**, yalnızca `--allow-test-key` ile izin veriliyor.
4. Dört sahtecilik denemesi de **REDDEDİLDİ** (bozuk .deb, kurcalanmış InRelease, güvenilmeyen anahtar, SHA1 imza); `unattended-upgrade` yalnızca Origin "Anatolia Labs" + `stable` paketini yükseltti.
5. Ön işler tamam: `dpkg-shlibdeps` sürüm kısıtları geri kondu (lintian E sayısı **değişmedi: 77**), ağ denetimi Marionette'siz yeniden koşuldu (8 alan adı, sayfa düzeltildi), çalışırken yükseltme gözlendi.

---

## B. Görev görev

### P1 — Depends sürüm kısıtları

`packaging/deb.py` içine `shlibdeps_constraints()` eklendi: sahnelenmiş ağaçtaki
tüm ELF dosyaları için `dpkg-shlibdeps` çalıştırılıp `paket (>= sürüm)`
kısıtları üretiliyor ve `objdump`+`dpkg -S` ile bulunan paket listesine
uygulanıyor.

**Önce** (kısıtsız):
```
Depends: fontconfig, hicolor-icon-theme, libasound2t64, libatk-bridge2.0-0t64,
 libatk1.0-0t64, libc6, libcairo-gobject2, libcairo2, libdbus-1-3, libdrm2, ...
```
**Sonra:** 36 bağımlılık satırının **21'inde sürüm kısıtı** var
(`dpkg-deb -f … Depends` çıktısı sayılarak doğrulandı: 36 toplam, 21 kısıtlı,
15 kısıtsız):

```
Depends: fontconfig, hicolor-icon-theme, libasound2t64 (>= 1.0.16),
 libatk-bridge2.0-0t64, libatk1.0-0t64 (>= 1.12.4), libc6 (>= 2.34),
 libcairo-gobject2 (>= 1.10.0), libcairo2 (>= 1.10.0), libdbus-1-3 (>= 1.10),
 libdrm2, libfontconfig1 (>= 2.12.6), libfreetype6 (>= 2.3.9), libgbm1,
 libgcc-s1 (>= 4.2), libgdk-pixbuf-2.0-0 (>= 2.22.0),
 libglib2.0-0t64 (>= 2.78.0), libgtk-3-0t64 (>= 3.13.7),
 libpango-1.0-0 (>= 1.14.0), libpangocairo-1.0-0 (>= 1.14.0),
 libstdc++6 (>= 12), libwayland-client0, libwayland-egl1, libx11-6, libx11-xcb1,
 libxcb-shm0, libxcb1, libxcomposite1 (>= 1:0.4.6), libxcursor1 (>> 1.1.2),
 libxdamage1 (>= 1:1.1), libxext6, libxfixes3 (>= 1:5.0), libxi6,
 libxrandr2 (>= 2:1.4.0), libxrender1 (>= 1:0.9.12), libxshmfence1, zlib1g
```

Kısıt gelmeyen 15 paket: `fontconfig`, `hicolor-icon-theme`,
`libatk-bridge2.0-0t64`, `libdrm2`, `libgbm1`, `libwayland-client0`,
`libwayland-egl1`, `libx11-6`, `libx11-xcb1`, `libxcb-shm0`, `libxcb1`,
`libxext6`, `libxi6`, `libxshmfence1`, `zlib1g` — bunlar ya `dlopen` ile
yükleniyor ya da `dpkg-shlibdeps`'in sürüm bağı çıkaramadığı (sembol sürümü
taşımayan) kitaplıklar; sürüm kısıtı uydurulmadı.

Her iki paket de (yayındaki `0.3~faz2` ve `0.4~faz3a`) bu kısıtları taşıyor —
`dpkg-deb -f` ile tek tek doğrulandı.

**lintian yeniden koşuldu:**
```
E=77  W=1  I=8      (önce: E=77 W=1 I=8 — değişmedi)
```
E dağılımı aynı: 70 × `dir-or-file-in-opt`, 6 × `embedded-library`,
1 × `relative-library-search-path`.

### P2 — Ağ denetimi (Marionette'siz, kayıt tutan proxy)

Yeni araç: `tests/network_audit.py`. Tarayıcı `/usr/bin/anatolium` ile açıldı;
tüm bağlantılar yerel proxy'den geçti, proxy **her isteği 502 ile reddetti**
(dışarıya trafik çıkmadı). 120 saniye beklendi.

```
total_connections: 161
hosts:
  firefox-settings-attachments.cdn.mozilla.net  77
  content-signature-2.cdn.mozilla.net           41
  firefox.settings.services.mozilla.com         37
  aus5.mozilla.org                               2
  ciscobinary.openh264.org                       1
  safebrowsing.googleapis.com                    1
  services.addons.mozilla.org                    1
  update.googleapis.com                          1
```

**`support.xhtml` ile karşılaştırma:**

| Sayfada yazan | Ölçüm | Sonuç |
|---|---|---|
| Telemetri, deneyler, Pocket, konum, push, çökme, captive portal **kapalı** | Hiçbirine bağlantı yok | ✔ doğru |
| `safebrowsing.googleapis.com` | görüldü | ✔ |
| `firefox.settings.services.mozilla.com` + 2 CDN | görüldü | ✔ |
| `services.addons.mozilla.org` | görüldü | ✔ |
| `aus5.mozilla.org`, `update.googleapis.com`, `ciscobinary.openh264.org` | görüldü | ✔ |
| `edgedl.me.gvt1.com` | **görülmedi** | ✘ → **sayfa düzeltildi**: bu adresin yalnızca DRM'li içerik gerektiğinde devreye girdiği ve bu ölçümde görülmediği yazıldı |

Ayrıca sayfaya "Ölçüm notu (faz 3a)" paragrafı eklendi: 120 saniyelik ölçümün
tarihi, yöntemi ve görülen 8 adres. Sayfa **olduğundan iyi göstermiyor**;
ölçülmeyen adres artık "gerektiğinde kullanılır" diye ayrı yazılı.

### P3 — Çalışırken yükseltme (yalnızca gözlem)

Senaryo: `0.4.1-0.1.dev` kurulu, tarayıcı açık ve kullanımda; paket
`0.4.1-0.3~faz2`'ye yükseltildi (`apt-get install`, "Unpacking … over
(0.4.1-0.1.dev)").

| Ne kontrol edildi | Yükseltmeden ÖNCE | Yükseltmeden SONRA | Sonuç |
|---|---|---|---|
| Tarayıcı süreci | PID 53750 (tek başlangıç kaydı) | aynı PID, aynı Marionette oturumu | **ayakta kaldı** |
| Açık sekmeler | `file:///opt/testler/medya/test.html` | aynı sekme (+ açtığımız `about:preferences`) | **korundu** |
| Yeni sekme açma | çalışıyor | çalışıyor | **bozulmadı** |
| `about:preferences` | "Ayarlar", bölümler yüklendi (359 karakter) | "Ayarlar", bölümler yüklendi (360 karakter) | **çalışıyor** |
| Kütüphane (geçmiş) dolabı | açıldı (`open: true`) | açıldı | **çalışıyor** |
| Kişiselleştirme dolabı | açıldı | açıldı | **çalışıyor** |
| Mevcut sekmede gezinme | `?nav=once` yüklendi | `?nav=sonra` yüklendi | **çalışıyor** |
| Konsol hataları | boş | boş | **hata yok** |
| Kapat → aç | 3 sekme | **yalnızca başlangıç sayfası** | ⚠ sekmeler geri gelmedi |

**Kapat-aç bulgusu (gözlem, çözüm yok):** Yeniden açılışta sekmeler geri
gelmiyor. Kök neden ölçüldü: `browser.startup.page` değeri çalışma anında **1**
(önceki oturumu geri yükle değil), oysa `src/config/anatolium.js` içinde **3**
yazıyor. Bu dosya motorun kendi varsayılanlarından önce yüklendiği için motor
kendi değerini (1) eziyor — yani bu pref AutoConfig dosyasına taşınmadığı için
etkisiz. **Bu fazda düzeltilmedi** (kapsam: depo + imza); Faz 3B/5 için not.

### §1 — Depo yapısı

* **Araç:** `packaging/repo.py` (kendi üretici). **reprepro kullanılmadı**,
  gerekçe ölçümle:

  | Gereksinim | reprepro 5.3.1 ölçümü |
  |---|---|
  | Son 3 sürümü tut | Yeni sürüm eklenince eskiyi **siliyor** (`Deleting files no longer referenced`); test: `0.3~faz2` + `0.4~faz3a` → geriye yalnızca sonuncusu kaldı |
  | `Acquire-By-Hash: yes` | `conf/distributions` içinde alan **bilinmiyor** → Release'e yazılamıyor |

  Diğer araçlar (aptly: kendi DB'si + servis; pulpcore: ağır) CI için fazla.
* **Kanallar:** `stable`, `beta`. **Component:** `main`. **Mimari:** `amd64`.
* **Release alanları:** `Origin: Anatolia Labs`, `Label: Anatolia Labs`,
  `Suite`, `Codename`, `Date`, `Architectures`, `Components`,
  `Description`, `Acquire-By-Hash: yes`, `SHA256`.
* **Valid-Until yok.** Gerekçe (tek cümle): depo her yayında yeniden imzalanıyor
  ve eski sürümler bilerek erişilebilir tutuluyor; `Valid-Until` konsaydı uzun
  süre güncellenmeyen kurulumlar tarihi geçmiş indeks yüzünden `apt update`
  yapamaz hâle gelirdi.
* **İmza:** her kanal için `InRelease` (clearsign) + `Release.gpg` (ayrık),
  **SHA512** (`gpg --list-packets` → `digest algo 10`; `InRelease` başlığı
  `Hash: SHA512`). SHA1 yok.
* **Çıktı:** `dists/` + `pool/` (statik). `export-static` ile tek klasöre
  kopyalanır.

Komutlar:
```bash
export GNUPGHOME=/var/tmp/ana-testkey
python3 packaging/repo.py init    --basedir repo --allow-test-key --uri http://127.0.0.1:8080
python3 packaging/repo.py add     --basedir repo --suite beta --allow-test-key dist/*.deb
python3 packaging/repo.py promote --basedir repo --allow-test-key
python3 packaging/repo.py prune   --basedir repo --keep 3 --allow-test-key
python3 packaging/repo.py status  --basedir repo
```

`status` çıktısı (iki sürüm yayınlanmış hâli):
```
stable : 3 paket, 196.0 MB — anatolium=0.4.1-0.3~faz2, anatolium-archive-keyring=2026.11.14, anatolium=0.4.1-0.4~faz3a
beta   : 2 paket, 98.0 MB — anatolium=0.4.1-0.3~faz2, anatolium-archive-keyring=2026.11.14
```

### §2 — Anahtar paketi (`anatolium-archive-keyring`)

* `/usr/share/keyrings/anatolium-archive-keyring.gpg` (ikili, dearmored) +
  `.asc` kopyası — **conffile değil**.
* `/etc/apt/sources.list.d/anatolium.sources` (deb822,
  `Signed-By=/usr/share/keyrings/anatolium-archive-keyring.gpg`,
  `Suites: stable`) — **conffile** (`DEBIAN/conffiles` içinde).
* Derleme parametresi: `ANATOLIUM_ARCHIVE_PUBKEY=yol`. UID'sinde `TEST-ONLY`
  geçen anahtarla **release modunda derleme reddedilir**:
  ```
  REDDEDİLDİ: anahtarın UID'sinde 'TEST-ONLY' geçiyor.
  UID: Anatolium Test Archive Signing Key (TEST-ONLY) (TEST-ONLY, this session only) <test-only@anatolia.invalid>
  Deneme için --allow-test-key (veya ANATOLIUM_ALLOW_TEST_KEY=1) ekleyin.
  ```
  Aynı denetim `repo.py` içinde de var.
* Paket adı ve bağımlılıkları sade: `Architecture: all`, **Depends yok**
  (yalnızca iki dosya kurar; ISO'ya önceden kurulacak).
* Anahtar değişimi (rotation) yönergesi: `docs/ANAHTAR.md` §4.

### §3 — Kurulum metni

`docs/KURULUM.md`: 4 adımlı komut dizisi (anahtar → `.sources` → `apt update`
→ `apt install`), keyring paketiyle kolay yol, **anatol-x kullanıcısı için
"hiçbir şey yapma"** notu, kanal seçimi, kaldırma. Adres yer tutucu:
`https://REPO.ORNEK`.

### §4 — Testler

Ayrıntılı tablo: `docs/DURUM-VE-TEST.md` → "Faz 3A". Öne çıkanlar:

**a) Temiz kurulum (FORKY-4, 77 paket)**
```
Get:1 http://127.0.0.1:8080 stable InRelease [1415 B]      ← imza doğrulandı
0 upgraded, 228 newly installed, 0 to remove
Need to get 241 MB of archives.
Setting up anatolium (0.4.1-0.4~faz3a) ...
kurulum sonrası paket sayısı: 306
```
Kurulu paket üzerinde: `smoke.py` **45/45**, `lock_test.py` **37/37**.

**b) Yükseltme**
```
apt update && apt upgrade   → 1 upgraded; Setting up anatolium (0.4.1-0.4~faz3a)
upgrade_profile.py verify   → yer imi "Faz2 yükseltme yer imi" (GUID aynı),
                              geçmiş kaydı duruyor, anatolium.theme.mode = dark
```

**c) Sahtecilik denemeleri — dördü de REDDEDİLDİ**

| # | Saldırı | apt'ın verdiği hata |
|---|---|---|
| 1 | Depodaki `.deb` değiştirildi, Release yeniden imzalanmadı | `Err:1 … Hash Sum mismatch` |
| 2 | `InRelease` içeriği değiştirildi (imza yenilenmedi) | `Verifying signature: Message has been manipulated` |
| 3 | Depo başka (güvenilmeyen) test anahtarıyla imzalandı | `Missing key 19164249CCCC0B7CAA78470B47C5FCB54FAE6AFF, which is needed to verify signature.` |
| 4 | `InRelease` SHA1 ile imzalandı | `Policy rejected non-revocation signature (Text) requiring collision resistance because: SHA1 is not considered secure since 2013-02-01T00:00:00Z` |

**d) unattended-upgrades**
```
Allowed origins are: o=Anatolia Labs,a=stable, origin=Debian,codename=forky,…
Checking: anatolium=0.4.1-0.4~faz3a ([<Origin component:'main' archive:'stable'
  origin:'Anatolia Labs' label:'Anatolia Labs' site:'127.0.0.1' isTrusted:True>])
Packages that will be upgraded: anatolium
--- gerçek çalıştırma:
Setting up anatolium (0.4.1-0.4~faz3a) ...
All upgrades installed
kurulu sürüm: 0.4.1-0.4~faz3a
```
Başka depo paketi etkilenmedi (`Packages that will be upgraded` listesinde
yalnızca `anatolium`).

**e) Kanallar**
```
beta'da paket var, stable boş → apt-get install anatolium
   → E: Unable to locate package anatolium
sources dosyasında Suites: beta yapıldı → Candidate: 0.4.1-0.3~faz2
terfi (promote beta → stable) → apt-cache policy: Candidate: 0.4.1-0.3~faz2
```

**f) Boyut**

| Ölçüm | Değer |
|---|---|
| Tek sürümlü depo (pool) | **98,0 MB** |
| İki sürüm yayınlanmış depo (pool) | **196,0 MB** |
| `dists/` (indeksler + imzalar) | **0,03 MB** |
| Bir kullanıcının **her yükseltmede** indirdiği | **≈98 MB** (paket tam olarak indirilir; Firefox ikilisi paketin içinde) |
| Keyring paketi | 4,8 kB |

### §5 — Belgeler

`docs/DEPO.md` (yapı, komutlar, terfi, budama, reprepro gerekçesi, sorun
giderme, unattended-upgrades), `docs/ANAHTAR.md` (üretim anahtarı yönergesi +
rotation), `docs/KURULUM.md` (kullanıcı), `docs/YEREL-BUILD.md` ve
`docs/DURUM-VE-TEST.md` güncellendi.

### §6 — Teslim

| Dosya | Boyut | sha256 |
|---|---|---|
| `anatolium-0.4.1-faz3a.zip` (kaynak, 108 dosya) | ≈4,97 MB | zip kendi boyutunu/özetini içinde taşıyamaz; kesin değerler teslim e-postasında |
| `repo/` (dists + pool + state.json) | 196,1 MB (mantıksal) / 188 MB (diskte) | — |
| `repo/pool/…/anatolium_0.4.1-0.4~faz3a_amd64.deb` | 98 007 028 B | `1b2af098fe5c8dffc7d1cf47ebb76c54247b221f70c11aa918a1d909d656d305` |
| `repo/pool/…/anatolium_0.4.1-0.3~faz2_amd64.deb` | 98 007 832 B | `9c5920afba2d46265d00db398d2a15f522aa00198d55462f961e98420f27bb29` |
| `repo/pool/…/anatolium-archive-keyring_2026.11.14_all.deb` | 4 932 B | `ccfd14abac594f933e5826a547ef72651a8f1f83ecaa01f1b95bf3e6e5999880` |
| `SHA256SUMS.txt` | — | yukarıdaki 5 satır, `sha256sum -c` ile denetlenebilir |

`0.4~faz3a` paketi `dist-faz3a/` klasöründe de aynı özetle duruyor (depodaki
kopya ile bayt bayt aynı).

**Test anahtarı silindi.** Depoda kalan imzalar o anahtara aittir; anahtar
artık yok — bu yüzden bu depo **yayına alınmamalı**, yalnızca deneme içindir.
Depoyu yayına almak için üretim anahtarıyla `repo.py sign` yeniden koşulmalı.

---

## C. Değişen dosyalar

| Dosya | Tür | Ne değişti |
|---|---|---|
| `packaging/repo.py` | **yeni** | Statik apt deposu üreticisi (iki kanal, by-hash, budama, imza, TEST-ONLY denetimi) |
| `packaging/keyring.py` | **yeni** | `anatolium-archive-keyring` paket üreticisi |
| `packaging/deb.py` | değişti | `dpkg-shlibdeps` sürüm kısıtları (`shlibdeps_constraints`) |
| `tests/network_audit.py` | **yeni** | Marionette'siz ağ denetimi (proxy tabanlı) |
| `tests/running_upgrade.py` | **yeni** | Çalışırken yükseltme gözlemi |
| `src/frontend/support.xhtml` | değişti | `edgedl.me.gvt1.com` düzeltmesi + ölçüm notu |
| `docs/DEPO.md` | **yeni** | Depo belgesi |
| `docs/ANAHTAR.md` | **yeni** | Üretim anahtarı + rotation yönergesi |
| `docs/KURULUM.md` | **yeni** | Kullanıcı kurulum metni |
| `docs/FAZ3A-RAPORU.md` | **yeni** | Bu rapor |
| `docs/YEREL-BUILD.md`, `docs/DURUM-VE-TEST.md` | değişti | Depo bölümü + Faz 3A tabloları |

---

## D. Test tabloları

Tam tablo `docs/DURUM-VE-TEST.md` → "Faz 3A" (17 satır). Özet: **15 BAŞARILI**,
**4 sahtecilik denemesi REDDEDİLDİ**, 0 başarısız, 6 madde ÇALIŞTIRILAMADI
(alan adı/HTTPS, üretim anahtarı, rotation tatbikatı, arm64, `.changes` akışı,
`Valid-Until`).

---

## E. Açık sorular ve riskler

1. **Depo adresi ve barındırma sizin kararınız.** `.sources` dosyasındaki
   `URIs` alanı kurulum anında sabitlenir; adres değişirse yeni keyring paketi
   yayınlanmalı (conffile olduğu için kullanıcıdaki eski dosya korunur →
   kullanıcıya duyuru gerekir).
2. **Paket imzasız, depo imzalı.** `apt install ./dosya.deb` yolu hâlâ imza
   gerektirmez; "güvenli kurulum" depodan kurulumla sağlanıyor. Paketlerin
   kendisinin de imzalanması (`.changes`/debsign) 3B kapsamı.
3. **Beta → stable terfisi elle.** Otomatik terfi (CI kapısı) yok; yanlış
   terfi riski tamamen süreç disiplinine bağlı.
4. **98 MB'lık tam paket.** Her yükseltmede tüm Firefox ikilisi iniyor.
   Delta/diff indirme (apt'in `Acquire::PDiffs` yalnızca indeksler içindir)
   bu boyutta çözüm değil; ileride "motor paketi" ayrı tutulabilir.
5. **Son 3 sürüm kuralı** depoyu ~294 MB'a çıkarabilir (3 × 98 MB). Depolama
   ve bant genişliği planlanmalı.
6. **`browser.startup.page` bulgusu** (P3): oturum geri yükleme varsayılan
   olarak çalışmıyor; `anatolium.js` yerine `anatolium.cfg`'ye taşınmalı.
   Bu fazda **düzeltilmedi**.
7. **TEST deposunun anahtarı silindi.** Depodaki imzalar doğrulanamaz.
   Yayına almadan önce üretim anahtarıyla yeniden imzalanmalı.
8. **Keyring paketinde Depends yok.** `.sources` (deb822) biçimi apt ≥ 1.5
   gerektirir; Debian 13/Ubuntu 24.04 ve sonrası uygun. Çok eski sistemler
   desteklenmiyorsa sorun yok; desteklenecekse `Depends: apt (>= 1.5)` eklenmeli
   (o zaman lintian `essential` uyarısı gerekçelendirilmeli).
9. **`Valid-Until` yok** — eski indeksle kurulum yapılabilir; apt'ın hash
   denetimi paketi korur ama "eski ama geçerli" sürüm kurulabilir. 3B'de
   değerlendirilecek.
10. **Anahtar ömrü 7 gün (test) / 3 yıl (öneri).** Üretim anahtarının süresi
    dolmadan uzatılmazsa kullanıcılar `apt update` yapamaz.

---

## F. Yapmadıklarım

1. **Üretim anahtarı üretmedim, istemedim, kullanmadım.** `anatolium-imza-yedek.7z`
   açılmadı.
2. **Dışarıya hiçbir şey yüklemedim.** Ağda yalnızca debootstrap/apt indirmeleri
   ve localhost deposu vardı.
3. **reprepro kullanmadım** (gerekçe §1'de ölçümle).
4. **`browser.startup.page` bulgusunu düzeltmedim** — bu faz depo/imza fazı;
   gözlem olarak raporlandı.
5. **`unattended-upgrades` ayarını paketin içine koymadım.** Kullanıcı isterse
   ekliyor (DEPO.md §11); paketle zorla açmak istemedim (politika kararı).
6. **Paketleri imzalamadım** (debsign/`.changes` akışı yok).
7. **arm64/i386 deposu kurmadım** — paket yalnızca amd64.
8. **Gerçek alan adı HTTPS testi yapmadım** (yer tutucu adres).
9. **Rotation tatbikatı yapmadım** — yalnızca yönerge yazdım.
10. **Eski sürümleri geri alma (downgrade) akışını belgelemedim**; `apt install
    anatolium=<sürüm>` ile mümkün, test edilmedi.
