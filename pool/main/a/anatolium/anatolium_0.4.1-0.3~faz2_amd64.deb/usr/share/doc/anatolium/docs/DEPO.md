# Anatolium apt deposu

Bu belge depoyu **kuran**, **yayın yapan** ve **sorun gideren** ekip içindir.
Kullanıcı tarafı için `docs/KURULUM.md`, anahtar üretimi için `docs/ANAHTAR.md`.

> **Bu fazdaki depo TEST deposudur.** İmza anahtarı bu oturum için üretilmiş,
> adı `TEST-ONLY` olan geçici bir anahtardır ve iş sonunda silinmiştir.
> Üretim anahtarı `docs/ANAHTAR.md`'deki adımlarla sizin bilgisayarınızda
> üretilecek. Depo yeniden imzalanmadan yayına alınmamalıdır.

---

## 1. Neden reprepro değil?

İlk tercih reprepro'ydu (basit, statik çıktı, betiklenebilir). Bu ortamda
**reprepro 5.3.1** ile ölçüldü ve iki gereksinim karşılanamadı:

| Gereksinim | reprepro davranışı (ölçüldü) |
|---|---|
| Kanadında son **3 sürümü** tut | Yeni sürüm eklenince **eski sürümü siliyor** ("Deleting files no longer referenced"). Örnek: `0.4.1-0.3~faz2` + `0.4.1-0.4~faz3a` eklenince geriye yalnızca son sürüm kaldı. |
| `Acquire-By-Hash: yes` | `conf/distributions` içinde bu alan **bilinmiyor** ("Unknown header 'Acquire-By-Hash'"), Release dosyasına yazılamıyor. |

Bu iki nedenle depo, `packaging/repo.py` içindeki ~250 satırlık üretici ile
doğrudan yazılıyor. Üretici:

* paketleri `pool/main/<harf>/<paket>/` altına kopyalar,
* her kanal için `Packages`, `Packages.gz`, `Packages.xz` üretir,
* `Release` dosyasını yazar (`Origin`, `Label`, `Suite`, `Codename`, `Date`,
  `Architectures`, `Components`, `Description`, **`Acquire-By-Hash: yes`**, `SHA256`),
* by-hash kopyalarını oluşturur,
* `Release.gpg` + `InRelease` imzalar (GPG, **SHA512**).

Çıktı tamamen statiktir: `dists/` + `pool/`. Herhangi bir web sunucusuna
kopyalanabilir; özel bir yazılım gerekmez.

## 2. Klasör düzeni

```
repo/
├── REPO-INFO.txt            # insan için özet (Origin, adres, anahtar)
├── state.json               # hangi sürüm hangi kanalda (üreticinin defteri)
├── conf/                    # reprepro kalıntısı değil; yok. (üretici kullanmaz)
├── dists/
│   ├── stable/
│   │   ├── Release          # imzalanacak metin
│   │   ├── Release.gpg      # ayrık imza (SHA512)
│   │   ├── InRelease        # metin + imza bir arada
│   │   └── main/binary-amd64/
│   │       ├── Packages, Packages.gz, Packages.xz
│   │       └── by-hash/SHA256/<özet>   # apt'ın tutarlı indirmesi için
│   └── beta/ ...
└── pool/main/a/anatolium/anatolium_0.4.1-0.4~faz3a_amd64.deb
```

Yayına yüklenecek klasör: yalnızca `dists/` + `pool/`.
`state.json` ve `REPO-INFO.txt` üreticinin defteridir; yüklenmese de olur
(ama zarar vermez — içinde gizli bilgi yok).

**Valid-Until kullanılmıyor.** Gerekçe: depo her yayında yeniden imzalanıyor ve
sürüm arşivi (eski sürümler) bilerek erişilebilir tutuluyor; `Valid-Until`
konulsaydı uzun süre güncellenmeyen bir kurulum, tarihi geçmiş indeks yüzünden
`apt update` yapamaz hâle gelirdi. Bu karar 3B fazında yeniden değerlendirilecek.

## 3. Kurulum (yayıncı tarafı)

```bash
export GNUPGHOME=/yol/anahtar            # üretim anahtarının bulunduğu dizin
python3 packaging/repo.py init --basedir repo --uri https://REPO.ORNEK/anatolium
```

## 4. Paket ekleme

```bash
# beta kanalına (test edilmemiş)
python3 packaging/repo.py add --basedir repo --suite beta dist/anatolium_0.4.1-0.4~faz3a_amd64.deb

# anahtar paketi de depoda durmalı
python3 packaging/repo.py add --basedir repo --suite beta dist/keyring/anatolium-archive-keyring_2026.11.14_all.deb
```

Her `add` sonunda indeksler ve imzalar kendiliğinden yenilenir.

## 5. Terfi (beta → stable)

```bash
python3 packaging/repo.py promote --basedir repo --from beta --to stable
```

Terfi bir **kopyalamadır**: paket beta'da da kalır. Kanal başına en fazla
**3 sürüm** tutulur (`--keep 3`); fazlası budanır ve pool'daki kullanılmayan
dosyalar silinir.

## 6. Budama

```bash
python3 packaging/repo.py prune --basedir repo --keep 3        # iki kanal
python3 packaging/repo.py prune --basedir repo --suite beta --keep 2
```

## 7. Durum ve statik çıktı

```bash
python3 packaging/repo.py status --basedir repo
python3 packaging/repo.py export-static --basedir repo --out repo/static
```

`export-static` yalnızca `dists/` + `pool/` kopyalar; bu klasör olduğu gibi
(rsync/scp/S3) sunucuya atılır.

## 8. İmza ve anahtar denetimi

* İmza algoritması: **SHA512** (`gpg --digest-algo SHA512`).
* Her kanal için `InRelease` (clearsign) ve `Release.gpg` (ayrık imza) üretilir.
* Anahtarın UID'sinde **`TEST-ONLY`** geçiyorsa `repo.py` **çalışmayı reddeder**:

  ```
  REDDEDİLDİ: seçili anahtarın UID'sinde 'TEST-ONLY' geçiyor.
    UID: Anatolium Test Archive Signing Key (TEST-ONLY) ...
  Üretim deposu bu anahtarla imzalanamaz. Deneme için --allow-test-key.
  ```
  Yalnızca deneme için `--allow-test-key` (veya `ANATOLIUM_ALLOW_TEST_KEY=1`).

## 9. Hızlı doğrulama

```bash
# imzayı doğrula (sqv, apt'ın kullandığı araç)
sqv --keyring /usr/share/keyrings/anatolium-archive-keyring.gpg \
    repo/dists/stable/InRelease            # → anahtar parmak izi yazdırır

# apt'ın gözüyle
apt-get update -o Dir::Etc::sourcelist=/etc/apt/sources.list.d/anatolium.sources
```

## 10. Sık karşılaşılan durumlar

| Belirti | Anlamı / çözüm |
|---|---|
| `E: Unable to locate package anatolium` | Paket yalnızca beta'da. `promote` yapın veya `.sources` içinde `Suites: beta` kullanın. |
| `Message has been manipulated` | Release/InRelease içeriği imzalandıktan sonra değişmiş. Depoyu yeniden üretip imzalayın. |
| `Missing key <parmak izi>` | Kullanıcıda eski `anatolium-archive-keyring` paketi var. Yeni keyring paketini yayınlayın (bkz. ANAHTAR.md §4). |
| `SHA1 is not considered secure` | SHA1 ile imzalanmış. `--digest-algo SHA512` kullanın. |
| `Hash Sum mismatch` | İndirilen .deb, `Packages` içindeki özetle uyuşmuyor (bozuk indirme veya kurcalama). |

## 11. Otomatik güncelleme (unattended-upgrades)

Depo paketleri kendiliğinden kurulsun isteniyorsa, kullanıcı tarafında
`/etc/apt/apt.conf.d/52anatolium-unattended` dosyası oluşturulur:

```
Unattended-Upgrade::Allowed-Origins {
        "Anatolia Labs:stable";
};
Unattended-Upgrade::Package-Blacklist {
};
```

* Yalnızca **Origin `Anatolia Labs`** ve **`stable`** kanalı otomatik kurulur;
  `beta` kanalı asla otomatik kurulmaz.
* Debian'ın kendi güvenlik deposu ayarları bozulmaz (bu dosya ayrı bir
  dosyadır, `50unattended-upgrades` dosyasına dokunulmaz).
* Denetim: `sudo unattended-upgrade --dry-run -d` çıktısında
  `Packages that will be upgraded: anatolium` satırı görünür.

Bu fazdaki ölçümde doğrulandı: dry-run yalnızca `anatolium`'u listeledi,
gerçek çalıştırmada yalnızca Anatolium yükseldi (`All upgrades installed`).


## Faz 3B eklemeleri — yükleme (deploy) ve budama

- **Yükleme sırası zorunludur:** `pool/` (paketler) → `by-hash/` kopyaları →
  `Packages`/`Release` → `Release.gpg` → **EN SON `InRelease`** → budama.
  Ters sırada bir kullanıcı "imza var, paket yok" hatası alabilir.
- `python3 packaging/deploy.py --target local-dir --dest <dizin> [--dry-run] [--interrupt-after N]`
- `python3 packaging/deploy.py --target s3 --bucket <kova> [--dry-run]`
  — **s3 hedefi bu ortamda denenmedi** (`aws` komutu yok); yalnız `--dry-run` çalıştı.
- **Budama:** depoda **son 3 sürüm** tutulur (`repo.py prune --keep 3`), yükleme
  tamamlandıktan sonra çağrılır. Yarıda kalırsa istemci etkilenmez (imza dosyası
  eski sürümleri göstermez).
- Yarım yükleme senaryosu (S10) doğrulandı: yarıda kalan depoda `InRelease` yok,
  `pool/` içinde paket var → istemci eski indeksi görmeye devam eder.
