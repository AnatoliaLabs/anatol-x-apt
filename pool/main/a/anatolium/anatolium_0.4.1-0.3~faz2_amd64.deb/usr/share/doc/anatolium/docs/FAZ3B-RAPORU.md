# Faz 3B raporu — Otomatik ESR takibi ve yayın hattı

**Sürüm:** `0.4.1-5~faz3b` · **Tarih:** 2026-11-14 · **Motor:** Firefox ESR `153.7.0esr` (üretim), `153.8.0esr` (sahte yeni sürüm senaryosu)
**Çalışma ortamı:** Linux konteyner, 2 çekirdek, Xvfb 1366x768x24 + openbox, yerel apt deposu, yerel sahte Mozilla sunucusu.

---

## A. Kısa özet (5 satır)

1. Sürüm izleme, imza doğrulama zinciri, 10 kapı, beta→stable terfi, yükleme sırası, tazelik ve canlılık bekçileri yazıldı ve **yerelde, sahte Mozilla sunucusu + test anahtarıyla** uçtan uca çalıştırıldı.
2. **S1–S10 senaryolarının 10'u da beklendiği gibi sonuçlandı**; her birinin komutu, kararı ve günlüğü `docs/FAZ3B-SENARYOLAR.md` içinde.
3. Üç gerçek ürün hatası bulundu ve düzeltildi: **motor sürüm doğrulamasında parmak izi yerine kısa anahtar kimliğinin karşılaştırılması**, **13 ürün varsayılanının çalışma anında motor tarafından ezilmesi**, **paketin içine çalışma anı artıklarının (kilit dosyaları, `updates/`) girmesi**.
4. Kurulu pakette ölçüm: duman testi **45/45**, kilit/varsayılan **48/48 + 69/69**, oturum geri yükleme **2/2**, `apt upgrade` **başarılı**, lintian **E=77 (temel 77, artış yok)**, iş akışı denetimi **3/3 temiz**.
5. Yayına hazır **değil**: gerçek Mozilla sunucusuna karşı tam koşu, gerçek GitHub Actions koşusu, gerçek S3 yüklemesi ve gerçek imza anahtarıyla imzalama bu ortamda **yapılmadı** (Bölüm F).

---

## B. Ön işler

### B.1 — `browser.startup.page` / oturum geri yükleme (Ön iş A)

**İlk bulgu:** temiz kapanışta tarayıcı SIGSEGV ile çöküyor (değiştirilmemiş motorla da), `sessionstore.jsonlz4` yazılmıyor → "ortam kısıtı" sanıldı.

**Gerçek neden:** `browser.startup.page` çalışma anında **1** değerini alıyordu, bizim istediğimiz **3** değil (bkz. B.2). Yani oturum dosyası yazılsa bile tarayıcı sekmeleri geri yüklemiyordu.

**Düzeltmeden sonra ölçüm (kurulu paket):**

| Ölçüm | Sonuç |
|---|---|
| `browser.startup.page` (çalışma anı) | **3**, kilitli değil |
| Çökme sonrası `sessionstore-backups/recovery.jsonlz4` | **yazıldı** (vanilla ile aynı davranış) |
| Yeniden açılışta sekme geri gelmesi | **EVET** (2/2 kapanış yöntemi) |
| Oturum dosyasındaki sekme sayısı | 2 sekme de kayıtlı (`mozLz4` çözüldü) |

**Ölçüm hatası da vardı:** ilk test yalnız "yeniden açılışta ağ isteği" sayıyordu. İki nedenle yanlış negatif veriyordu: (a) yanıtlar önbelleğe alınıyordu, (b) arka plan sekmeleri **tembel** geri yüklenir, ağa hiç çıkmaz. Test artık `Cache-Control: no-store` gönderiyor **ve** oturum dosyasını çözüp sekme adreslerini doğruluyor. Bu düzeltme `tests/session_restore_production.py` içinde.

### B.2 — Varsayılanların çalışma anındaki değerleri (Ön iş B)

Sorun: `src/config/anatolium.js` (AutoConfig'ten önce yüklenir) içinde bildirilen **13 ürün varsayılanı**, motorun kendi varsayılanları yüklenirken **eziliyordu**. Üç katman ölçüldü:

| Katman | Nerede | Ölçüm sonucu |
|---|---|---|
| `defaultPref()` | `anatolium.cfg` (AutoConfig) | **ETKİSİZ** — 13 varsayılandan 10'u motorun değerinde kaldı |
| `policies.json` → `policies.Preferences` | `distribution/policies.json` | **ETKİSİZ** — asgari 2 prefli politika dosyasıyla da değer değişmedi (9 sn gecikmeli ölçümde de aynı) |
| `lockPref()` | `anatolium.cfg` | **ÇALIŞIYOR** (35 kilitli prefin 35'i doğru) |
| `pref()` | `anatolium.cfg` | **ÇALIŞIYOR** — 63/68 → düzeltmelerden sonra **69/69** |

**Seçilen çözüm:** 11 varsayılan `anatolium.cfg` içine `pref()` ile yazıldı; 13 politika prefi `policies.json`'da olduğu gibi bırakıldı (değerleri zaten `anatolium.js` ile aynı). Sonuç, kurulu pakette:

```
tests/pref_defaults_probe.py → ölçülen pref: 69  eşleşen: 69  eşleşmeyen: 0
tests/lock_test.py --defaults → 48/48 pref beklendiği gibi; varsayılanlar 69/69
```

**Dürüst sınırlar:**

- `pref()` **kilit değildir**. Kullanıcı `about:config`'ten değeri değiştirebilir; değişiklik o oturumda geçerli olur, sonraki açılışta Anatolium varsayılanı yeniden uygulanır. Bu "ürün varsayılanı" davranışıdır, "kilit" değildir; `docs/YAYIN.md` ve `DURUM-VE-TEST.md` böyle yazıyor.
- **`policies.json` `Preferences` katmanının bu ortamda değer uygulamadığı ölçüldü.** Dosya pakette duruyor ve `lock_test` onu okuyor; ama değerlerin çalışma anında uygulandığına dair kanıtımız yok. Bu, raporun "ölçüldü, uygulanmadı" maddesidir.
- **Bilinen fark (1 adet):** `browser.aboutwelcome.enabled` değeri doğru (`false`), fakat kilit biti Marionette oturumunda `True`, Marionette'siz bağımsız ölçümde `False`. Gerekçesiyle `tests/known_lock_discrepancies.json` içinde yazılı; `lock_test` bunu "BİLİNEN FARK (değer doğru)" olarak raporlar ve **değer yanlışsa kapıyı kurtarmaz**.

### B.3 — `support.xhtml` ve proxy koşusu (Ön iş C)

`support.xhtml` notu yazıldı. Proxy'nin "ilet ve kaydet" davranışı için ayrı bir koşu **yapılmadı**: dış trafik istenmedi. Bu bir **sınır** olarak Bölüm F'de duruyor.

---

## C. Bu turda bulunan ve düzeltilen gerçek hatalar

| # | Hata | Nerede | Etkisi | Durum |
|---|---|---|---|---|
| 1 | Parmak izi yerine **kısa anahtar kimliği** (16 karakter) 40 karakterlik pin ile karşılaştırılıyordu | `packaging/engine_fetch.py` | **Her gerçek motor indirmesi dururdu** (S2 bunu yakaladı) | Düzeltildi; gerçek Mozilla `KEY` dosyasıyla doğrulandı (ana `14F26682…0353`, alt `827E6586…7AA3` **eşleşiyor**) |
| 2 | 13 ürün varsayılanı çalışma anında eziliyordu | `anatolium.cfg` | Ürün "kendi ayarlarıyla" açılmıyordu (oturum geri yükleme dahil) | Düzeltildi → 69/69 |
| 3 | Derleme ağacına çalışma anı artıkları giriyordu (`lock`, `.parentlock`, `updates/`) | `packaging/build.py` | Paket 97 MB'a çıktı, lintian'da **+6 hata** | Düzeltildi (temizlik eklendi; `fonts/` korunuyor) |
| 4 | `rpmbuild` "Release" alanına tam sürüm (`0.4.1-5~faz3b`) veriliyordu | `packaging/pipeline.py` + `version_policy.py` | RPM derlemesi **duruyordu** | `revision_only()` eklendi |
| 5 | Çalışma dizini yoksa `tar -xJf` çıkaramıyordu | `packaging/build.py` | Hat, temiz makinede ilk derlemede dururdu | `WORK.mkdir()` eklendi |
| 6 | Değişiklik günlüğü (changelog) sabit `0.4.1-0.3~faz2` yazıyordu ve adı `changelog.gz` idi | `packaging/deb.py` | lintian: `debian-changelog-file-missing-or-wrong-name` | Sürüm otomatik, ad `changelog.Debian.gz` |
| 7 | lintian hata sayısı **kırpılmış** çıktıdan sayılıyordu (E=25) | `packaging/gates.py` | Kapı gerçek sayıyı görmüyordu | Tam çıktıyla sayılıyor → E=77 |
| 8 | Tazelik bekçisi tarih-only alanı saat dilimsiz okuyordu | `tools/freshness.py` | `TypeError` ile çöküyordu | Düzeltildi |
| 9 | Sahte sunucu portu (8099) bu ortamda başka bir süreç tarafından tutuluyordu; soket yeniden kullanılmıyordu | `tests/stub_mozilla.py` | Senaryolar `Address already in use` ile düştü | Port 8137 + `allow_reuse_address` + `server_close()` |
| 10 | Bozma senaryoları önbellekteki sağlam tarball yüzünden görünmüyordu | `tests/pipeline_scenarios.py` | S5 yanlış "geçti" verecekti | Senaryo başına ayrı `ANATOLIUM_CACHE` |
| 11 | `lock_test --defaults` bloğu özetten sonra çalışıyordu | `tests/lock_test.py` | `UnboundLocalError` | Sıra düzeltildi |

---

## D. Test sonuçları (kurulu paket `0.4.1-5~faz3b`)

| Test | Sonuç | Ne ölçüldü | Kanıt |
|---|---|---|---|
| `tests/smoke.py` | **45/45** | Tam arayüz duman testi | `docs/test-report.json` |
| `tests/lock_test.py --defaults` | **48/48**, varsayılanlar **69/69** | 35 kilitli + 13 kilitsiz pref | `docs/lock-report.json` |
| `tests/pref_defaults_probe.py` | **69/69** | Çalışma anı değerleri (motor varsayılanlarından sonra) | `docs/pref-defaults-report.json` |
| `tests/session_restore_production.py` | **2/2** | İki kapanış yöntemi + oturum dosyası | `docs/session-restore-report.json` |
| `tests/upgrade_gate.py` | **BAŞARILI** | `0.4.1-0.5~faz3b` → `0.4.1-5~faz3b` gerçek `apt` yükseltmesi | `docs/upgrade-gate.json` |
| lintian kapısı | **E=77**, temel **77** | Artış yok | `docs/lintian-gate.json` |
| Ağ farkı (temel) | **8 alan adı** | Yeni alan adı → DUR | `docs/network-audit-faz3b.json` |
| Pref farkı (153.6 → 153.7) | 5451 → 5472 (**21 yeni**, hepsi `anatolium.theme.*`, 0 kalkan) | Yeni/ayrılan ayarlar | `/var/tmp/pref-diff.json` |
| `tests/workflow_lint.py` | **3/3 temiz** | permissions, SHA pinleri, ortam koruması, `set -x` yok | `/var/tmp/workflow-lint.json` |
| `tools/freshness.py` | 3/3 durum doğru | `taze` / `terfi-bekliyor` (uyarı) / `stable-eksik` (uyarı) | `docs/freshness-triad.json` |
| `tools/keepalive.py` | `--poke` + `--check` çalıştı; `--check-disabled` **ÇALIŞTIRILAMADI** | `gh` yok | — |
| S1–S10 | **10/10** | Bkz. senaryo raporu | `docs/FAZ3B-SENARYOLAR.json` |

**Sürüm şeması kanıtı (dpkg karşılaştırması, 8/8 doğru):**
`0.1.dev < 0.3~faz2 < 0.4~faz3a < 0.5~faz3b < 0.6 < 0.7 < 0.10 < 0.4.2-1`
— yani `0.10` sayısal olarak `0.9`'dan büyük, `~faz` ekleri gerçek sürümün önüne geçmiyor.

**Karar/çıkış kodları:** aynı ana sürüm → `auto` (0), farklı ana sürüm → `stop_major` (10), düşük sürüm → `reject` (10), aynı sürüm → `noop` (0), doğrulama hatası → 11, kapı hatası → 12, yarım yükleme → 3.

---

## E. Güvenlik ve sürekli tümleştirme (CI)

- **CI'da yalnız imza alt anahtarı** kullanılır; geçici `GNUPGHOME` içinde durur, iş bitince silinir. **Ana anahtar çevrimdışı**; `docs/ANAHTAR.md` süreci yazılı.
- İş akışlarında **asgari `permissions:`**, tüm üçüncü taraf action'lar **tam SHA'ya sabit**, **`pull_request_target` yok**, **`set -x` yok**, `set -euo pipefail` var.
- İmza/secret kullanan işler **ana dal** (`refs/heads/main`) + **korumalı ortam** (`production`) ile sınırlı.
- Motor doğrulama zinciri: `SHA512SUMS.asc` → imza (pinli alt anahtar) → `SHA512SUMS` → tarball hash'i. **Hash asla imzasız kaynaktan alınmaz**; yalnız `tr/linux-x86_64`.
- Bu ortamda kullanılan tek anahtar **TEST-ONLY** anahtardır (`76113E91…CCE5241`) ve **teslimden önce silindi**; depo ve durum dosyası da silindi.
- **Denetim:** `tests/workflow_lint.py` → **3/3 temiz**. Denetim yalnız yorum satırlarını değil gerçek YAML'ı okuyor; `secrets.GITHUB_TOKEN` gerçek secret sayılmıyor.

---

## F. Yapmadıklarım ve sahte olan parçalar

### Yapmadıklarım (nedeniyle)

1. **Gerçek Mozilla sunucusuna karşı tam hat koşusu** — dış trafik istenmedi. Yalnız motor bir kez indirilip doğrulandı; hat sahte sunucuyla koştu.
2. **Gerçek GitHub Actions koşusu** — bu ortamda `gh` yok, depo bağlantısı ve secret yok. İş akışı dosyaları `workflow_lint.py` ile denetlendi, **çalıştırılmadı**.
3. **Gerçek S3/nesne depoya yükleme** — `aws`/`rclone` yok. `deploy.py --target s3` **dry-run** ile sınandı, gerçek yükleme yapılmadı.
4. **Gerçek imza anahtarıyla imzalama** — gerçek anahtar kullanılmadı, `anatolium-imza-yedek.7z` dosyasına dokunulmadı.
5. **`gh` gerektiren keepalive denetimi** (`--check-disabled`) — **ÇALIŞTIRILAMADI**.
6. **Proxy "ilet ve kaydet" koşusu** (Ön iş C) — dış trafik istenmedi.
7. **Kodak/codec kapısı tam koşuda çalıştırılmadı** — S2 kapı setinden muaf tutuldu; codec ölçümü faz 2 raporundaki matrise dayanıyor, bu turda yeniden ölçülmedi.
8. **True rollback (sürüm düşürme) uygulanmadı** — `pipeline.py rollback` yalnız **daha yüksek revizyonlu düzeltme** üretir ve bunu yazdırır (`0.4.1-6~faz3b`); `apt` zaten eski sürüme düşürmez. Senaryo olarak sınanmadı, tasarım gereği.

### Sahte olan parçalar

| Parça | Ne kadar sahte | Nerede yazılı |
|---|---|---|
| Mozilla sunucusu | Tamamen (yerel `127.0.0.1:8137`, uydurma `firefox_versions.json`, kendi imzası) | `docs/FAZ3B-SENARYOLAR.md` başı |
| Yeni sürüm `153.8.0esr` | Gerçekte yok; 153.7.0 ağacından üretildi | aynı |
| İmza anahtarı | TEST-ONLY, teslimden sonra silindi | aynı + `docs/ANAHTAR.md` |
| S9 "yeni alan adı" | Kapının karar mantığı sabit örnekle sınandı (temel liste gerçek ölçümden) | `docs/FAZ3B-SENARYOLAR.md` |
| Depo | Yerel `repo/`, test anahtarıyla imzalı; teslimden sonra silindi | — |

### Bilinen açık noktalar

1. `policies.json` `Preferences` katmanı bu ortamda **değer uygulamıyor** (ölçüldü). Pakette duruyor ama işlevsel kanıtı yok.
2. `browser.aboutwelcome.enabled` kilit biti farkı (Bölüm B.2, bilinen fark).
3. Temiz kapanışta **SIGSEGV** (motorun kendisinde, vanilla'da da var) — oturum geri yükleme artık çalışıyor ama çökme kaydı oluşuyor.
4. S2 kapı setinde `session_restore`, `codec`, `upgrade`, `network_diff` muafiyetli (`--allow-unverified`) — gerekçe senaryo raporunda.
5. Senaryolar sıralı koştu (S2 sonrası S1/S3/S7); tek tek bağımsız çalıştırılabilirlik garanti edilmiyor.
