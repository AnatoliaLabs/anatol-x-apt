# Anatolium 0.4.1 — geliştirme adayı

Bu kaynak, Firefox ESR 153.6.0 üzerine kurulu Anatolium kabuğunun 0.4.1 geliştirme adayıdır. **Henüz yayın sürümü değildir.** Paket sürümü `0.4.1-0.1.dev` (0.4.0 ile aynı NEVRA kullanılmaz). Yerel deneme için hazırlanmıştır; resmî yayın veya mevcut profil üzerinde kullanım öncesi `docs/DURUM-VE-TEST.md` dosyasındaki eksikler tamamlanmalıdır.

## Geliştirilenler

- Kütüphane: Yer imi arama/düzenleme, tekli ve seçimli silme; gerçek GUID ile tek yer imini silme. Geçmişte ayrı ziyaretler, tek ziyaret veya adresteki tüm ziyaretleri silme; aralıkla geçmiş temizleme. İndirmeyi yalnızca listeden kaldırma.
- Uzun listelerde 100'erli gösterim; yer imi sorgusu ilk 200 kayıtla sınırlı değil.
- Başlangıç notunda kaydın başarılı/başarısız durumu, tekrar deneme, okunamayan mevcut dosyanın üzerine sessizce yazmama.
- On palet, kapalı/hafif/zengin hareket seviyesi, sistemin azaltılmış hareket seçeneği; tarayıcının kontrolündeki yan panel çerçevesine tema.
- Marka ürün adının ve Türkçe oturum kurtarma başlığının güncellenmesi. Mozilla ve eklenti geliştiricisi isimleri korunur.
- Kenar çubuğu daima görünür; kütüphane, kişiselleştirme ve menü kenar çubuğunda. Dikey sekmelerde yatay şerit gizleme. Komut paneli filtreleri ve X kapatma. "Son kapatılanlar" kaldırıldı.
- Başlangıç sayfası, duvar kâğıdı seçici, "Anatolium Mobil · Yakında" sunumu; ürün alanında yalnızca bu.
- 0.3.2'nin Places kurtarma, profil kilidi, yerel yıldız ve uzantı paneli davranışlarını koruma hedefi.

## Gizlilik ve testler

- Tarayıcının hangi ağ bağlantılarını kapattığı, hangilerini bilerek açık tuttuğu
  (adres + gerekçe) yerel destek sayfasında yazılı: `src/frontend/support.xhtml`
  → "Ağ bağlantıları ve gizlilik" bölümü. Aynı sayfa tarayıcı içinden
  **Yardım → Anatolium Desteği** ile açılır.
- Kilitli ayarların listesi ve beklenen değerleri `tests/lock_test.py` ile
  denetlenir; her ESR güncellemesinden sonra çalıştırılmalıdır:
  `python3 tests/lock_test.py <sahnelenmiş-dizin> --json docs/lock-report.json`.
- Arayüz testi: `python3 tests/smoke.py <sahnelenmiş-dizin>` (Xvfb + Marionette).

Sınırlamalar ve test sonuçları için `docs/DURUM-VE-TEST.md`; Fedora'da derleme için `docs/YEREL-BUILD.md` dosyasına bakın. Kod MPL-2.0 lisanslıdır; motor ve diğer bileşenlerin lisansları pakette bulunur.
