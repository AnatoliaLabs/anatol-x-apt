# Fedora 44'te yerel geliştirme build'i

Bu kaynak bir **geliştirme adayıdır**. Build tamamlanması testlerin geçtiği veya paketin yayına hazır olduğu anlamına gelmez. Derleme komutlarını normal kullanıcı ile çalıştırın; sudo kullanmayın.

## Bağımlılıklar

```bash
sudo dnf install rpm-build rpm-sign python3 python3-pillow python3-numpy gnupg2 unzip xz tar desktop-file-utils
```

İnternet gerekir. Betik ilk kez çalıştığında ESR arşivini indirip sabitlenmiş SHA-512 özetini denetler. İkonlar kaynak görselden otomatik üretilir. `ANATOLIUM_WORK` ve `ANATOLIUM_DIST` için boş veya bu projeye ayrılmış klasörler seçin: `dist/anatolium` build sırasında silinip yeniden yaratılır. Kişisel profilinizi bu yollardan birine **vermeyin**.

```bash
mkdir -p "$HOME/AnatoliumBuild040/work" "$HOME/AnatoliumBuild040/dist"
cd "$HOME/Anatolium/anatolium-0.4.0"
ANATOLIUM_WORK="$HOME/AnatoliumBuild040/work" \
ANATOLIUM_DIST="$HOME/AnatoliumBuild040/dist" \
python3 packaging/build.py
```

İmzasız aday RPM `~/AnatoliumBuild040/dist/` içindedir. Gerçek profile kurmayın, resmî sürüm olarak yayımlamayın.

## Testler

Testlerin bazıları çalışma dizinleri içindeki test profillerini silip oluşturur. **Gerçek profil içermeyen, testlere ayrılmış bir ANATOLIUM_WORK kullanın.** Xvfb, openbox ve D-Bus test bağımlılıkları ayrıca gereklidir; bunlar derleme için zorunlu değildir.

```bash
sudo dnf install xorg-x11-server-Xvfb openbox dbus-daemon
mkdir -p "$HOME/AnatoliumBuild040/test"
ANATOLIUM_WORK="$HOME/AnatoliumBuild040/test" dbus-run-session -- \
  python3 tests/smoke.py "$HOME/AnatoliumBuild040/dist/anatolium/opt/anatolium"
```

Testler `docs` altında rapor ve ekran görüntüsü üretir. Bunlar gerçek RPM yükseltme testi yerine geçmez.

## İmza

**Nihai, test edilmiş sürümü** kullanıcı kendi bilgisayarında mevcut anahtarla imzalar; bu arşivde hiçbir özel anahtar veya parola yoktur. Resmî yayıncı ana parmak izi `B281B5BB3C5C9C260419F6685C4945D31E22475E`, mevcut imzalama alt anahtarı `A83FF29D1E7D5CD73DE0E25630943842A6454A01`'dir. Anahtarları, yedekleri ve parolayı bu kaynak ağacının, build ve dağıtım klasörlerinin dışında saklayın. Sürüm numarası ve testler tamamlanmadan resmî paket imzalamayın.

## Doğrudan Debian paketi (.deb) üretimi — Faz 2

RPM ve deb **aynı sahnelenmiş dizinden** üretilir; deb, RPM'den dönüştürülmez
(`alien` kullanılmaz, kullanılmayacak). Sürüm numarası 0.4.1'de sabittir;
yalnızca yapı numarası değişir (`0.4.1-0.3~faz2`).

### Debian/Ubuntu tarafında gereken araçlar

```bash
sudo apt install dpkg-dev binutils rpm rsync python3 python3-pillow python3-numpy xz-utils lintian
```

- `dpkg-deb` ve `dpkg` her Debian sisteminde vardır.
- `rpm` yalnızca *karşılaştırma için* RPM üretmek isterseniz gerekir; sadece deb
  üretmek için gerekmez (`--target deb`).
- `lintian` paket denetimi içindir.

### Üretim

```bash
cd anatolium-0.4.1-faz2
mkdir -p "$HOME/AnatoliumBuild041/work" "$HOME/AnatoliumBuild041/dist"
ANATOLIUM_WORK="$HOME/AnatoliumBuild041/work" \
ANATOLIUM_DIST="$HOME/AnatoliumBuild041/dist" \
python3 packaging/build.py --target deb        # yalnızca .deb
# python3 packaging/build.py                    # ikisi (rpm + deb)
```

Çıktı: `dist/anatolium_0.4.1-0.3~faz2_amd64.deb` (~98 MB) ve yanında
`SHA256SUMS.txt`.

Betik sırayla şunları yapar:

1. Firefox ESR 153.6.0 tarball'ını indirir ve **SHA-512** özetini doğrular.
2. Anatolium arayüzünü sahnelenmiş ağaca uygular (`opt/anatolium`).
3. Başlatıcı, `.desktop`, simgeler, AppStream metni ve man sayfasını ekler.
4. `*.so` dosyalarının çalıştırma bitini kaldırır (lintian `E:` uyarısı).
5. `usr/share/doc/anatolium/` altına `copyright`, `changelog.gz`, README ve
   `docs/` kopyasını koyar.
6. `DEBIAN/control`, `postinst`, `prerm`, `postrm`, `md5sums` yazar.
7. `dpkg-deb --root-owner-group -Zxz --build` ile paketi üretir.
8. Sürüm sıralamasını `dpkg --compare-versions` ile yazdırır:
   `0.4.1-0.1.dev < 0.4.1-0.3~faz2 < 0.4.2`.

### Paket denetimi

```bash
lintian --info --display-info dist/anatolium_0.4.1-0.3~faz2_amd64.deb
dpkg-deb -f dist/anatolium_0.4.1-0.3~faz2_amd64.deb      # control alanları
dpkg-deb -c dist/anatolium_0.4.1-0.3~faz2_amd64.deb | wc -l
```

Bilinen ve **gerekçeli bırakılan** lintian kalemleri `docs/FAZ2-RAPORU.md`
§4'teki tabloda listelenmiştir (en büyüğü: tüm çalışma zamanının `/opt`
altında olması).

### Temiz bir Debian testing sisteminde deneme (önerilen)

```bash
sudo apt install debootstrap
sudo debootstrap --variant=minbase forky /var/tmp/deneme http://deb.debian.org/debian
sudo mount --bind /proc /var/tmp/deneme/proc
sudo mount --bind /dev  /var/tmp/deneme/dev
sudo cp dist/anatolium_0.4.1-0.3~faz2_amd64.deb /var/tmp/deneme/root/
sudo chroot /var/tmp/deneme /bin/bash
# konteyner içinde:
apt update && apt install -y /root/anatolium_0.4.1-0.3~faz2_amd64.deb
/usr/bin/anatolium --version
```

**Paket imzasızdır.** `apt install` imza aramaz (yerel dosya), ancak depoya
koyup `apt update` ile kullanmak için imza gerekir; bu fazda imza atılmadı.

## Testler (Faz 2'de eklenenler)

```bash
python3 tests/pref_snapshot.py /opt/anatolium     # gerçek pref değerleri
python3 tests/codec_test.py /opt/anatolium /opt/testler/medya   # kodek matrisi
python3 tests/upgrade_profile.py seed   /opt/anatolium <profil> <çıktı.json>
python3 tests/upgrade_profile.py verify /opt/anatolium <profil> <çıktı.json>
```

> Not: `pref_snapshot.py`, `codec_test.py` ve `upgrade_profile.py` Marionette
> kullanır. Firefox, Marionette açıkken `browser.safebrowsing.*` pref'lerini
> kendi test listesiyle kapatır; bu yüzden betikler
> `user_pref("remote.prefs.recommended", false)` yazar. Bu satır olmadan
> ölçüm **yanlış** sonuç verir (bkz. FAZ2-RAPORU §0).

## Yerel apt deposu (Faz 3A)

Depo üreticisi `packaging/repo.py`, anahtar paketi üreticisi
`packaging/keyring.py`. Ayrıntılı kullanım: `docs/DEPO.md`.

```bash
# 1) Depo iskeleti (imza anahtarı GNUPGHOME'da olmalı)
export GNUPGHOME=/yol/anahtar
python3 packaging/repo.py init --basedir repo --uri https://REPO.ORNEK/anatolium

# 2) Paketleri kanala ekle
python3 packaging/repo.py add --basedir repo --suite beta \
    dist/anatolium_0.4.1-0.3~faz2_amd64.deb dist/keyring/*.deb

# 3) beta → stable terfi
python3 packaging/repo.py promote --basedir repo

# 4) Anahtar paketi (üretim anahtarıyla; --allow-test-key YOK)
ANATOLIUM_ARCHIVE_PUBKEY=/yol/genel-anahtar.asc \
  python3 packaging/keyring.py --uri https://REPO.ORNEK/anatolium

# 5) Yayına hazır statik klasör
python3 packaging/repo.py export-static --basedir repo --out repo/static
```

Yerel deneme (imza zinciri dahil):

```bash
python3 -m http.server 8080 --directory repo        # depoyu localhost'ta sun
# başka bir kabukta, temiz bir Debian testing sisteminde:
sudo apt install ./anatolium-archive-keyring_2026.11.14_all.deb
sudo apt update && apt-cache policy anatolium
```

> Test anahtarıyla çalışıyorsanız `repo.py` ve `keyring.py` komutlarına
> `--allow-test-key` eklemek zorunludur. Üretimde bu seçenek **verilmez**;
> anahtarın UID'sinde `TEST-ONLY` geçiyorsa betikler çalışmayı reddeder.
