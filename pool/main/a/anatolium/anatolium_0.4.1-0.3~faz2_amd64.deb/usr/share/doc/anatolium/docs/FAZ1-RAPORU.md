# Anatolium 0.4.1 — FAZ 1 RAPORU

> **Tarihsel kayıt.** Bu rapor faz 1 turunun o günkü ölçümünü anlatır
> (smoke 41/45). Düşen 4 kontrol faz 1b turunda kapatıldı; güncel sonuç
> ve ortam bilgisi için `docs/DURUM-VE-TEST.md` ve `docs/FAZ1B-RAPORU.md`.

Tarih: 2026-11-14 · Çalışma kopyası: `anatolium-0.4.1-faz1/` (orijinal arşiv hiç
değiştirilmedi, ayrı klasörde duruyor) · Sürüm numarası **değişmedi**.

## A. Özet

1. Metin hataları düzeltildi; repoda artık hiç Çince/Japonca/Korece karakter yok.
2. Destek, geri bildirim ve sürüm notu bağlantıları yerel "Hakkında / Destek"
   sayfasına çevrildi (yalnızca motorda gerçekten var olan pref adları kullanıldı).
3. Çökme bildirimi üç katmanda kapatıldı (application.ini + kilitli pref'ler +
   `MOZ_CRASHREPORTER_DISABLE=1`); crash helper dosyaları silinmedi.
4. `distribution/policies.json` eklendi: 12 politika; kişiselleştirme kilitlenmedi.
5. 120 saniyelik ağ denetimi yapıldı; 7 Mozilla/Google adresi kapatıldı, kalanlar
   gerekçesiyle belgelendi. Testler: smoke 41/45 (fark yok), launcher 2/2,
   restart 2/2, oturum kurtarma 2/2. İç test RPM'i üretildi (`0.4.1-0.2.dev2`).

## B. Görev görev yapılanlar

### 1) Metin hataları

Değişen dosya: `docs/DURUM-VE-TEST.md`

- "incelenip必要 düzenlemeler" → "incelendi ve gerekli düzenlemeler"
- "cihasında" → "cihazında"
- Ek olarak bulunan görünür yazım hataları: "geçiş temizleme" → "geçmiş
  temizleme", "geçiş ziyareti" → "geçmiş ziyareti", "kapsamlı ve scoped" →
  "kapsamlı ve kapsamı belirli".

CJK taraması (tüm repo, src/docs/packaging/tests/README/LICENSE,
dosya türü metin olan her şey):

```
$ python3 - <<'EOF'   # CJK Unicode aralıklarında tarama
...
CJK bulgu: 1  → docs/DURUM-VE-TEST.md:15: [CJK Unified] U+5FC5 必要
# düzeltmeden sonra:
CJK bulgu: 0 []
```

Kısa yazım hataları listesi: `cihasında`, `geçiş temizleme`, `geçiş ziyareti`,
`scoped` (İngilizce kalıntı), `incelenip必要`. Başka görünen hata bulunamadı.

### 2) Destek / geri bildirim bağlantıları

Önce **hangi pref'ler gerçekten var** diye motorun kendisine bakıldı
(`browser/omni.ja` → `defaults/preferences/firefox.js` ve
`firefox-branding.js`):

```
firefox.js:522: pref("app.support.baseURL", "https://support.mozilla.org/1/firefox/...")
firefox.js:523: pref("app.feedback.baseURL", "https://ideas.mozilla.org/")
firefox-branding.js:22: pref("app.releaseNotesURL", "https://www.firefox.com/...")
firefox-branding.js:23: pref("app.releaseNotesURL.aboutDialog", "https://www.firefox.com/...")
firefox-branding.js:25: pref("app.releaseNotesURL.prompt", "https://www.firefox.com/...")
firefox.js:519: pref("breakpad.reportURL", "https://crash-stats.mozilla.org/report/index/")
# app.privacyURL ve app.helpMenu: motorun hiçbir dosyasında YOK → uydurulmadı
```

Yeni dosyanın ölçümü (paket ağacı, izole profil):

```
supportPage: {uri: "chrome://browser/content/anatolium/support.xhtml",
              title: "Anatolium — Hakkında ve Destek", contact: true}
supportBase: "chrome://browser/content/anatolium/support.xhtml#"  (locked: true)
feedback:    "chrome://browser/content/anatolium/support.xhtml#"
aboutNotes:  "chrome://browser/content/anatolium/support.xhtml#"
supportMenu: "Anatolium Desteği | chrome://browser/content/anatolium/support.xhtml"
```

- Yeni sayfa: `src/frontend/support.xhtml` (proje durumu + `anatoliaosf@proton.me`,
  dış kaynak yüklemez, temaya duyarlı).
- Yardım menüsü ölçümü: `["Yardım al", …, "Anatolium hakkında", "Anatolium Desteği"]`.
- Adres sonundaki `#` bilinçli: motor "shield", "push" gibi ekleri adrese
  yapıştırıyor; `#` sayesinde adres bozulmuyor.

Görünen metinlerde "Firefox" taraması (tr arayüzü, 27 dize):
`branding/brand.ftl` (7 — ticari marka atfı), `browser/policies/policies-descriptions.ftl`
(6 — Mozilla özellik adları), `devtools/client/aboutdebugging.ftl` (5 — Android
Firefox'u anlatıyor), `browser/profile/default-bookmarks.ftl` (4 — Mozilla atfı),
`preferences.ftl` (2), `migrationWizard.ftl` (1 — başka tarayıcının adı),
`appExtensionFields.ftl` (1 — tema adı), `devtools/client/application.ftl` (1).
Bunların hiçbiri "bizim ürün adımız yanlış yazılmış" değil; ürün adı `brand.ftl`
üzerinden zaten Anatolium. **Silinmedi** (lisans/atıf gereği).
Pencere başlığı `Anatolium`, hakkında menüsü `Anatolium hakkında` ölçüldü.

### 3) Crash reporter

Gerçekte hangi dosya etkili? Ölçüm:

```
$ # kök application.ini'ye RemotingName=anatolium yazıldı
$ probe → Services.appinfo.remotingName = "anatolium"     ← dosya OKUNUYOR
$ # Name/Vendor değiştirildi → Services.appinfo.name hâlâ "Firefox"
   (bu iki alan motorda derleme zamanı markasıyla eziliyor)
$ ls browser/ → application.ini YOK
```
Sonuç: kök `application.ini` etkilidir; başındaki "bu dosya kullanılmaz" notu
Mozilla şablonundan kalmadır.

Yapılanlar:
- `packaging/apply_frontend.py`: `[Crash Reporter] Enabled=0`, `ServerURL=`.
- `src/config/anatolium.cfg`: `breakpad.reportURL=""`, çökme pref'leri `lockPref`.
- `src/launcher/anatolium.in`: `export MOZ_CRASHREPORTER_DISABLE=1`.

Ölçüm: `MOZ_CRASHREPORTER_DISABLE=1` → `Services.appinfo.crashReporterEnabled = false`.
Sadece `Enabled=0` bu bayrağı değiştirmedi; bu yüzden üç katman birlikte.

crashhelper/crashreporter **silinmedi** ama silinebilirliği kanıtlandı:

```
$ cp -a final3 final_nocrash && rm -rf final_nocrash/opt/anatolium/{crashhelper,crashreporter}
$ probe → {"ok": true, "ready": "true", "title": "Anatolium"}   ← tarayıcı açıldı
```

Gerekçe: bu iki dizin yalnızca çökme raporu *arayüzü*. Veriyi toplayan kod
motorun içinde (libxul). Silmek gönderimi tek başına engellemez; çökme anında
yarım arayüz bırakır ve "doğrulanmış ESR ağacı" bütünlüğünü bozar. Gönderim
zaten kapalı olduğu için silmeye gerek yok.

### 4) Politika dosyası

Yeni dosya: `src/config/policies.json` → kurulumda
`/opt/anatolium/distribution/policies.json` (yazma işini
`packaging/apply_frontend.py` yapıyor). Anahtarlar motorun kendi şemasından
doğrulandı: `browser/omni.ja → modules/policies/policies-schema.json` (125 politika).

| Politika | Ne yapıyor | Neden kilitli |
|---|---|---|
| DisableTelemetry | telemetri gönderimini kapatır/kilitler | kullanım verisi toplanmasın |
| DisableFirefoxStudies | Normandy/Nimbus deneylerini kapatır | uzaktan deney/kod dağıtımı |
| DisablePocket | Pocket kapalı | üçüncü taraf servis |
| DisableAppUpdate | tarayıcı içi güncelleme kapalı | güncelleme imzalı paketle |
| DontCheckDefaultBrowser | varsayılan tarayıcı sorusu yok | istenmeyen soru |
| DisableFeedbackCommands | geri bildirim komutları kapalı | Mozilla'ya geri bildirim |
| CaptivePortal: false | yakalama portalı yoklaması kapalı | detectportal.firefox.com |
| OverrideFirstRun/PostUpdatePage: "" | ilk açılış/güncelleme sayfaları boş | Mozilla tanıtım sayfası |
| UserMessaging | What's New/öneri/urlbar müdahalesi yok; MoreFromMozilla **açık** | kendi "Anatolium Mobil" kartımız görünsün |
| FirefoxHome | sponsorlu içerik/Pocket/hikâye/snippet kapalı | reklamsız başlangıç |
| SupportMenu | Yardım'a "Anatolium Desteği" ekler | destek bağlantısı |
| Preferences | 12 pref `locked` | aşağıdaki liste |

`Preferences` ile kilitlenenler: `browser.tabs.crashReporting.sendReport`,
`browser.crashReports.unsubmittedCheck.enabled`, `…autoSubmit2`,
`browser.newtabpage.activity-stream.showSponsored`, `…showSponsoredTopSites`,
`…feeds.section.topstories`, `…feeds.system.topstories`,
`browser.discovery.enabled`, `browser.safebrowsing.malware.enabled`,
`extensions.pocket.enabled`, `network.captive-portal-service.enabled`,
`datareporting.policy.dataSubmissionEnabled`.

Kişiselleştirme kilidi **yok** (ölçüldü): `anatolium.theme.preset` →
`locked=false`, `anatolium.theme.motion` → `locked=false`, palet/mod/cam/yoğunluk/
yarıçap/tek satır aynı şekilde serbest.

Ek dosya: `src/config/autoconfig.js` + `src/config/anatolium.cfg` (AutoConfig).
**Neden gerekliydi:** ölçüm, `defaults/pref/anatolium.js` dosyasının motorun kendi
varsayılanlarından ÖNCE yüklendiğini gösterdi; motor `app.support.baseURL` gibi
adresleri kendi değeriyle eziyordu. `anatolium.cfg` en son çalıştığı için bu
adresleri ve `breakpad.reportURL`'ü kilitleyebiliyor. (`app.*` ve `breakpad.*`
önekleri politika dosyasıyla kilitlenemiyor — motorun izin listesi buna izin
vermiyor; bu yüzden iki mekanizma birlikte kullanılıyor.)

### 5) Ağ trafiği denetimi

Yöntem: yerel kayıt tutan HTTP proxy + izole profil, ilk açılış, 120 saniye.

Düzeltme **öncesi** görülen bağlantılar:
`location.services.mozilla.com`, `firefox.settings.services.mozilla.com`,
`firefox-settings-attachments.cdn.mozilla.net`, `content-signature-2.cdn.mozilla.net`,
`push.services.mozilla.com` (×4), `detectportal.firefox.com`,
`incoming.telemetry.mozilla.org`, `normandy.cdn.mozilla.net`,
`classify-client.services.mozilla.com`, `aus5.mozilla.org`,
`update.googleapis.com`, `www.google.com`, `ciscobinary.openh264.org`,
`services.addons.mozilla.org`, `safebrowsing.googleapis.com`.

Düzeltme **sonrası** kalanlar:
`firefox.settings.services.mozilla.com`, `firefox-settings-attachments.cdn.mozilla.net`,
`content-signature-2.cdn.mozilla.net`, `aus5.mozilla.org`, `update.googleapis.com`,
`edgedl.me.gvt1.com`, `ciscobinary.openh264.org`, `services.addons.mozilla.org`,
`safebrowsing.googleapis.com`.

Kapatılanlar: push (dom.push.enabled), detectportal
(network.connectivity-service.enabled), konum (browser.region.update.enabled),
telemetri, Normandy, Pocket.

Bilinçli açık bırakılanlar (kapatmak işlev/güvenlik kaybı):
OpenH264 (video görüşme) + Widevine (DRM) indirmeleri → `aus5` /
`update.googleapis.com` / `edgedl.me.gvt1.com`; uzantı güncellemeleri →
`services.addons.mozilla.org`; kimlik avı koruması → `safebrowsing.googleapis.com`;
CRLite/sertifika listeleri → Remote Settings adresleri.

### 6) Testler

```
$ ANATOLIUM_WORK=/var/tmp/ana/testwork python3 tests/smoke.py <runtime>
41/45 checks passed
# düzeltme ÖNCESİ aynı ortamda: 41/45 (düşen 4 kontrol birebir aynı)

$ dbus-run-session -- python3 tests/launcher.py <runtime>
2/2 launcher checks passed

$ dbus-run-session -- python3 tests/restart_persistence.py <runtime>
2/2 restart checks passed   (yer imi + geçmiş korundu)

$ dbus-run-session -- python3 tests/session_restore_integration.py <runtime>
NORMAL {… "pass": true}   CRASH {… "recovery_page": false, "pass": true}
```

Düşen 4 smoke kontrolü (düzeltmelerden **önce de** düşüyordu): "Recently closed
tab restore", "Single-row chrome", "Narrow window falls back to two rows",
"History interval protects boundary". Yer imi, geçmiş ve oturum kurtarma
bozulmadı.

### 7) Paket

```
$ ANATOLIUM_WORK=… ANATOLIUM_DIST=… ANATOLIUM_RELEASE=0.2.dev2 python3 packaging/build.py
…
RPM ready: …/anatolium-0.4.1-0.2.dev2.x86_64.rpm (97.2 MB)
$ rpm -qpl … | grep -E "policies.json|anatolium.cfg|autoconfig.js|bin/anatolium"
/opt/anatolium/anatolium.cfg
/opt/anatolium/defaults/pref/autoconfig.js
/opt/anatolium/distribution/policies.json
/usr/bin/anatolium
```
- Sürüm `0.4.1` sabit, yalnızca yapı numarası `0.2.dev2` → mevcut `0.4.1-0.1.dev`
  ile çakışmıyor. Paket **imzasız**, yalnızca iç test için.
- `build.py` yalnızca RPM üretiyor; **deb üretilmedi**.

## C. Değişen dosyalar

```
 docs/DURUM-VE-TEST.md                | 204 +++++++++++++++++++++++++++++++-
 docs/restart-persistence-report.json |  10 +-
 docs/test-report.json                |  34 ++---
 packaging/anatolium.spec             |   3 +-
 packaging/apply_frontend.py          |  24 ++++-
 packaging/build.py                   |   6 +-
 src/config/anatolium.cfg             |  85 +++++++++++++++   (yeni)
 src/config/anatolium.js              |  49 +++++++++
 src/config/autoconfig.js             |  18 ++++            (yeni)
 src/config/policies.json             |  84 ++++++++++++++++  (yeni)
 src/frontend/support.xhtml           | 145 +++++++++++++++++++++++++  (yeni)
 src/launcher/anatolium.in            |   3 +
 12 dosya, 636 ekleme, 29 silme
```

## D. Test sonuçları

| Test | Geçen | Kalan | Çalıştırılamayan |
|---|---|---|---|
| smoke.py | 41 | 4 (faz 1 öncesi de aynı) | — |
| launcher.py | 2 | 0 | D-Bus'suz tek başına çalıştırınca 1/2 (ortam) |
| restart_persistence.py | 2 | 0 | — |
| session_restore_integration.py | 2 | 0 | — |
| Ağ denetimi (proxy) | 2 tur | — | — |
| Çökme minidump kanıtı | — | — | **ÇALIŞTIRILAMADI** (SIGSEGV ile içerik süreci öldürüldü; ne ham ESR'de ne düzeltilmiş sürümde `minidumps/` oluştu) |
| deb paketi | — | — | **ÇALIŞTIRILAMADI** (`build.py` deb hedefi içermiyor) |

## E. Açık sorular ve riskler

1. `[Crash Reporter] Enabled=0` gerçekten okunuyor mu? Bu ortamda minidump
   üretilemediği için ölçülemedi. (Kapatma zaten pref + ortam değişkeni ile de
   yapılıyor.)
2. `www.google.com` bağlantısının kaynağı bulunamadı; `[AppUpdate] URL` sentinel
   deneyi updater olmadığını gösterdi.
3. `chrome://` adresleri, ağ hata sayfası ve about:preferences gibi içerik
   süreçlerindeki "daha fazla bilgi" bağlantılarında engellenebilir. Menü, hakkında
   penceresi ve sekme açılışında çalıştığı ölçüldü; hata sayfası bağlantısı
   ayrıca test edilmedi.
4. Yeni arayüzde "Yardım al" menü maddesi hâlâ motorun `app.support.baseURL`
   yolunu kullanıyor (artık yerel sayfa). Bu davranış ileride Anatolium destek
   sitesi kurulunca tek yerden değiştirilebilir.
5. Remote Settings, Safe Browsing, uzantı güncellemeleri bilinçli açık →
   Mozilla/Google'a sınırlı trafik devam ediyor. Faz 2 kararı gerekli.
6. `Services.appinfo.name` hâlâ "Firefox" (motor derlemesinden). Görünen hiçbir
   yerde kullanılmıyor ama çökme raporu/telemetri gibi alanlarda görünebilir.

## F. Bu fazı kapatmak için yapmadıklarım (dürüst liste)

1. Gerçek çökmede minidump üretilmediğini **kanıtlayamadım** (ortam engeli).
2. Ağ hata sayfasındaki destek bağlantısının tıklanabilirliğini test etmedim.
3. `.deb` paketi üretmedim (build.py'de deb hedefi yok).
4. Paketi **imzalamadım** (özel anahtar istemedim/kullanmadım) ve kurmadım;
   kurulum/yükseltme testini Fedora'da yapmadım.
5. `smoke.py`'deki 4 eski hatayı düzeltmedim (faz 1 kapsamı değil).
6. Remote Settings / Safe Browsing / uzantı güncelleme trafiğini kapatmadım
   (güvenlik/işlev kaybı olur; karar sizin).
7. Tam çoklu dil (en-US dışındaki diller) ve gerçek destek sitesi bu fazda yok.
8. `crashhelper`/`crashreporter` dizinlerini silmedim (gerekçe yukarıda).
