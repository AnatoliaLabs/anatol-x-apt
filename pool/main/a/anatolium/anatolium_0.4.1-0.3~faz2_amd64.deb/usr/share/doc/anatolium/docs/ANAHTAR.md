# Üretim imza anahtarı ve anahtar değişimi (rotation)

**Bu belge bir yönergedir; anahtar burada ÜRETİLMEDİ.** Bu fazda yalnızca
adı `TEST-ONLY` olan geçici bir anahtar kullanıldı ve silindi. Üretim
anahtarını yalnızca siz, kendi bilgisayarınızda, aşağıdaki adımlarla
üretirsiniz. Anahtar üretimi geri alınamaz bir işlemdir; parola ve yedek
sizin sorumluluğunuzdadır.

---

## 1. Anahtar üretimi (adım adım)

### 1.1 Hazırlık

```bash
# Anahtarı ve iş dosyalarını proje klasörünün DIŞINDA tutun.
mkdir -p ~/anatolium-anahtar && chmod 700 ~/anatolium-anahtar
export GNUPGHOME=~/anatolium-anahtar
```

> `GNUPGHOME` yalnızca bu terminal oturumu için geçerli. Her yeni terminalde
> tekrar vermeniz gerekir. Anahtarı `~/.gnupg` içine koyarsanız bu satıra
> gerek kalmaz; ama o zaman aynı kullanıcıdaki diğer işlerle karışır.

### 1.2 Anahtarı üret

```bash
gpg --batch --gen-key <<'EOF'
%echo Anatolium üretim imza anahtarı
Key-Type: RSA
Key-Length: 4096
Key-Usage: sign
Name-Real: Anatolia Labs Archive Signing Key
Name-Email: anatoliaosf@proton.me
Expire-Date: 3y
%no-protection
%commit
%echo bitti
EOF
```

**Neden bu satırlar**

| Satır | Neden |
|---|---|
| `Key-Type/Length: RSA 4096` | Debian dünyasında en yaygın, her apt sürümünün desteklediği seçenek. |
| `Key-Usage: sign` | Bu anahtar yalnızca imza atar; şifreleme yapmaz. Çalınma riski düşük, kullanım alanı dar. |
| `Expire-Date: 3y` | Süresiz anahtar, kaybolduğunda sonsuza kadar risk taşır. 3 yıl, uzatılabilir (bkz. §5). |
| `%no-protection` | **Dikkat:** parolasız anahtar, dosyayı ele geçiren herkesin imza atması demek. Parola koymak isterseniz bu satırı silin; o zaman CI/otomasyon her seferinde parola ister. Karar sizin: parolasız + çevrimdışı saklama ya da parolalı + elle imzalama. |
| `Name-Real`/`Name-Email` | Kullanıcı `apt-key list` çıktısında bunu görür. **`TEST-ONLY` yazmayın**; yazarsanız `packaging/kepring.py` ve `packaging/repo.py` üretim modunda reddeder. |

### 1.3 Parmak izini yaz ve YEDEKLE

```bash
gpg --list-secret-keys --keyid-format long
gpg --export-secret-keys --armor > ~/anatolium-anahtar/GIZLI-ANAHTAR.asc
gpg --export --armor > ~/anatolium-anahtar/genel-anahtar.asc
```

* `GIZLI-ANAHTAR.asc` dosyasını **şifreli bir diskte / donanım anahtarda**
  saklayın, proje deposuna **koymayın**.
* Parmak izini (`fpr` satırı) ekip içinde paylaşın; paket açıklamalarında ve
  `docs/` içinde bu iz kullanılır.
* **İptal sertifikası** (`openpgp-revocs.d/…rev`) da yedeklenmeli; anahtar
  kaybolursa depoyu "bu anahtar artık geçersiz" diye işaretlemenin tek yolu odur.

## 2. Anahtarı paketlere bağlama

```bash
export GNUPGHOME=~/anatolium-anahtar
python3 packaging/repo.py init --basedir repo --uri https://REPO.ORNEK/anatolium
python3 packaging/repo.py add  --basedir repo --suite beta dist/*.deb

ANATOLIUM_ARCHIVE_PUBKEY=~/anatolium-anahtar/genel-anahtar.asc \
  python3 packaging/keyring.py --uri https://REPO.ORNEK/anatolium
```

`--allow-test-key` **vermeyin**: üretim anahtarında buna gerek yok; bir gün
yanlışlıkla test anahtarı kullanılırsa betik çalışmayı reddeder.

## 3. Depoyu yayına koyma

`python3 packaging/repo.py export-static --basedir repo --out repo/static`
çıktısındaki `dists/` + `pool/` klasörünü sunucuya kopyalayın. HTTPS kullanın:
anahtar paketi `https://` adresine işaret eder ve apt imzayı indirdikten sonra
doğrular (imza doğruysa aradaki kanalın güvenli olması şart değildir, ama
kullanıcı gizliliği için HTTPS önerilir).

## 4. Anahtar değişimi (rotation) — kısa yönerge

Anahtar süresi dolmadan ya da ele geçirilme şüphesi varsa:

1. **Yeni anahtarı üret** (§1) ve parmak izini yaz.
2. **Geçiş keyring'i yayınla:** yeni keyring paketinde **iki** genel anahtar
   bulunsun (eski + yeni). Bunun için `anatolium-archive-keyring.gpg` dosyası
   iki anahtarın birleşimi olmalı:
   ```bash
   gpg --export ESKI_FPR > /tmp/eski.gpg
   gpg --export YENI_FPR > /tmp/yeni.gpg
   cat /tmp/eski.gpg /tmp/yeni.gpg > /tmp/birlesik.gpg
   # keyring.py'ye bu birleşik dosyayı verin:
   ANATOLIUM_ARCHIVE_PUBKEY=/tmp/birlesik.gpg python3 packaging/keyring.py --uri …
   ```
   Bu paketi yayınlayın; kullanıcılar `apt update` yaptıklarında yeni anahtarı
   da tanır. **Bu adım atlanırsa** eski anahtarla imzalanmış depo, yeni
   anahtara geçildiği anda "Missing key" hatası verir.
3. **Depoyu yeni anahtarla imzala:** `repo.py`'yi yeni `GNUPGHOME`/`--key` ile
   çalıştırın. Geçiş süresince iki anahtarla imzalamak gerekmez; apt, keyring
   paketinde iki anahtar olduğu için yeni imzayı doğrular.
4. **Eski anahtarı kaldır:** bir sonraki keyring paketinde yalnızca yeni
   anahtar bulunsun. Eski anahtarla imzalanmış indeksler kalmadığından emin olun.
5. Eski anahtar sızdıysa **iptal sertifikasını** yayımlayın ve kullanıcıları
   duyurun; iptal edilmiş anahtarla imzalanmış depo apt tarafından reddedilir.

## 5. Süre uzatma (aynı anahtar, yeni son tarih)

```bash
gpg --quick-set-expire PARMAK_IZI 3y
```
Yeni son tarihli genel anahtarı keyring paketine koyup yayınlayın. Kullanıcı
tarafında ek iş yoktur.

## 6. Yapılmaması gerekenler

* Anahtarı depoya, zip'e, pakete koymayın (yalnızca **genel** anahtar keyring
  paketinde olur).
* `TEST-ONLY` adlı anahtarı üretim deposunda kullanmayın (betikler reddeder).
* Parolayı ve gizli anahtarı e-posta/sohbet ile paylaşmayın.
* Aynı anahtarı hem depo imzası hem paket imzası (`.changes`) için kullanmak
  zorunlu değildir; ayrı anahtar kullanmak hasar alanını küçültür.
