# Anatolium — Yayın rehberi (sade Türkçe)

Bu belge, **Anatolium tarayıcısının yeni sürümünü çıkarma** işini adım adım anlatır.
Kod bilmeyen bir ekip üyesi bu belgeyi takip ederek yayın yapabilir.
Bilgisayar terimleri en az düzeyde tutuldu; her adımda "ne olacak, ne göreceksin" yazıyor.

> **Bu belgedeki bilgilerin ne kadarı gerçekten denendi?**
> Yayın hattının tamamı yerelde, **sahte (taklit) Mozilla sunucusuyla** ve
> **test imza anahtarıyla** çalıştırıldı. Gerçek Mozilla sunucusuna, gerçek depoya
> veya GitHub'a **hiçbir şey yüklenmedi**. Denenmeyen yerler §9'da tek tek yazılı.

---

## 1. Kısa özet: bir sürüm nasıl çıkıyor?

```
Mozilla yeni ESR yayınlar
        │
        ▼
[1] Sürüm izleme  ──►  aynı ana sürüm mü, yüksek mi?        (otomatik, günde 1)
        │                 • yüksek ve aynı ana sürüm  → devam
        │                 • farklı ana sürüm (153 → 154) → DUR + e-posta
        │                 • düşük sürüm                → yok say
        ▼
[2] Doğrulama     ──►  indirilen dosyanın imzası Mozilla anahtarına uyuyor mu?
        │                 • uymuyorsa → DUR + e-posta
        ▼
[3] Kapılar       ──►  10 kontrol (duman testi, kilit kontrolü, codec, yükseltme…)
        │                 • biri bile geçmezse → YAYIN YOK + e-posta
        ▼
[4] Beta derleme  ──►  paket hazırlanır, **beta** deposuna konur (kimse görmez)
        │                 • kararlı (stable) depo DEĞİŞMEZ
        ▼
[5] Onay          ──►  bir insan "yayınla" der (GitHub'da tek düğme, onaylı ortam)
        ▼
[6] Kararlı depo  ──►  paket **stable**'a taşınır, imzalanır, yayına girer
        │                 • sıra: havuz → by-hash → EN SON imza dosyası
        ▼
[7] Bekçiler      ──►  24 saat içinde kararlı depoya girmezse uyarı e-postası
                          60 gün yeni sürüm çıkmazsa "hat çalışıyor mu?" e-postası
```

Yani: **insan onayı olmadan hiçbir sürüm kullanıcıya ulaşmaz.** Otomatik olan kısım
"hazırla ve beta'ya koy"tur. Kullanıcıya açılan kapı (stable) her zaman elle açılır.

---

## 2. Sürüm numarası nasıl okunur?

```
0.4.1 - 0.5~faz3b
└─┬──┘  └──┬────┘
  │        └─ paket yapı numarası (her yeni derlemede artar)
  └────────── ürün sürümü (kullanıcıya gösterilir)
```

- `~faz3b` gibi ekler **deneme** sürümüdür; alfabetik olarak `0.6`'dan **önce** gelir,
  yani deneme paketi gerçek sürümün önüne geçmez. (Bu sıralama 8 örnekle doğrulandı.)
- Aynı ürün sürümüyle düzeltme çıkarmak normaldir: `0.5~faz3b` → `0.6~faz3b`
  gibi **yapı numarası** artırılır. Sürüm numarasını **asla geriye** çekme (§7.3).

---

## 3. Sürüm izleme (her gün kendiliğinden)

`freshness.yml` iş akışı günde bir kez çalışır ve şu üç soruyu yanıtlar:

1. **Mozilla'da yeni sürüm var mı?** `firefox_versions.json` okunur, **yalnız kararlı
   (stable) ESR** sürümüyle karşılaştırılır (`beta`, `nightly` yok sayılır).
2. **Aynı ana sürüm mü?** `153.7.0esr` → `153.8.0esr` ise otomatik devam.
   `153` → `154` ise **durur** ve e-posta atar: ana sürüm atlaması elle incelenmeli.
3. **Kararlı depo taze mi?** Beta'da hazır bekleyen bir sürüm varsa **ayrı** bir
   uyarı e-postası gider ("beta'da yayın bekliyor").

Elle çalıştırmak istersen:

```bash
python3 tools/freshness.py --json /tmp/tazelik.json            # durumu yazdır
python3 tools/freshness.py --now 2026-11-15T12:00:00Z          # saati ileri al (deneme)
python3 tools/freshness.py --github-output                     # iş akışı için
```

Üç durum vardır: `taze` (24 saat içinde kararlı depo tazelendi),
`terfi-bekliyor` (beta hazır, onay bekliyor), `stable-eksik` (hiç yayın yok).

**Hat sessizce ölürse:** 60 gün boyunca hiçbir hareket olmazsa `tools/keepalive.py`
"hat çalışıyor mu?" e-postası atar. Elle kontrol:

```bash
python3 tools/keepalive.py --check              # son harekete bak, uyarı üret
python3 tools/keepalive.py --poke               # "hat canlı" damgası vur
python3 tools/keepalive.py --check-disabled     # iş akışı kapatıldıysa uyar
```

---

## 4. Doğrulama: indirdiğimiz dosya gerçekten Mozilla'nın mı?

Her indirmede üç dosya birlikte iner:

| Dosya | Ne işe yarar |
|---|---|
| `firefox-153.7.0esr.tar.xz` | tarayıcının kendisi |
| `SHA512SUMS` | dosyanın özeti (parmak izi) |
| `SHA512SUMS.asc` | yukarıdaki listenin **imzası** |

Kurallar (uygulandı ve ölçüldü):

1. **Özet listesi asla imzasız bir yerden kabul edilmez.** Önce `.asc` imzası
   doğrulanır, sonra özet okunur, sonra tar dosyası özetle karşılaştırılır.
2. İmza, **Mozilla'nın imza alt anahtarına** karşı doğrulanır. Parmak izi
   `packaging/engine_fetch.py` içinde **sabit yazılıdır** (pinli); değişirse iş
   durur. Ana anahtar ve alt anahtar bilgisi `docs/ANAHTAR.md`'de.
3. Yalnız `tr/linux-x86_64` yolu kullanılır.
4. Üçünden biri tutmazsa: **DUR**, e-posta, yayın yok.

---

## 5. Kapılar: yayından önce çalışan 10 kontrol

| # | Kapı | Ne sorar | Geçmezse |
|---|---|---|---|
| 1 | Duman testi (`tests/smoke.py`) | Tarayıcı açılıyor, arayüz çalışıyor mu? | Yayın yok |
| 2 | Kilit kontrolü (`tests/lock_test.py`) | Kilitli ayarlar kilitli mi, varsayılanlar doğru mu? | Yayın yok |
| 3 | Başlatıcı (`tests/launcher.py`) | İkinci açılış yeni pencere mi açıyor, devrediyor mu? | Yayın yok |
| 4 | Yeniden başlatma (`restart_persistence.py`) | Kapat-aç sonrası ayarlar duruyor mu? | Yayın yok |
| 5 | Oturum geri yükleme (`session_restore_production.py`) | Çökme sonrası sekmeler geri geliyor mu? | Yayın yok |
| 6 | Codec (`codec_test.py`) | Ses/video açılıyor mu? | Yayın yok |
| 7 | Yükseltme (`tests/upgrade_gate.py`) | Eski sürümden `apt upgrade` sorunsuz mu, kullanıcı verisi duruyor mu? | Yayın yok |
| 8 | Lintian | Paket biçim hatası **arttı mı?** (E sayısı eski sürümden fazlaysa) | Yayın yok |
| 9 | Ağ farkı | Yeni bir alan adına bağlantı eklendi mi? | Yayın yok |
| 10 | Ayar farkı | Yeni/ayrılan ayarlar listelenir, hassas isimli pref var mı? | Rapor (dur durmaz) |

Kapı listesi `packaging/gates.py` içinde tek yerde tanımlıdır; çıktısı
`pipeline.py --json` ile makine okunur biçimde alınır.

---

## 6. Yayınlama: beta → onay → kararlı

### 6.1 Beta derlemesi (otomatik)

`build-and-publish.yml` iş akışı, kapılar geçtikten sonra paketi derer ve **yalnız
beta deposuna** koyar. Kararlı depo değişmez; kullanıcılar etkilenmez.

### 6.2 Onay ve kararlı depoya taşıma (elle)

`promote.yml` iş akışını aç, **"Run workflow"** düğmesine bas. Bu iş:

1. **korumalı ortam** (`production`) üzerinde çalışır → GitHub ayarlarında tanımlı
   onaycı(lar) izin vermeden başlamaz;
2. ana dalda çalışır (`refs/heads/main`), yani yayınlanmamış dal kodu yayına çıkamaz;
3. beta → stable taşımasını yapar.

**Sıra önemlidir ve kodda zorlanmıştır:**

```
önce paketler (havuz)  →  sonra by-hash kopyaları  →  EN SON imza dosyası (InRelease)
```

Neden? Bir kullanıcı tam o sırada güncelleme yaparsa, imza dosyasını gördüğünde
paketler **zaten yerinde** olur. Ters sırada olsaydı kullanıcı "imza var ama paket
yok" hatası alırdı. Bu sıra senaryo **S10** ile sınandı (yükleme ortasında kesinti →
istemci bozulmadı).

### 6.3 Acil bayrak

Olağanüstü durumda (güvenlik açığı, kullanıcıyı bozan hata) beta aşamasını
atlayıp doğrudan kararlı depoya çıkmak için iş akışında **`acil: evet`** seçeneği
vardır. Bu durumda bile:

- kapılar **yine çalışır** (atlanmaz),
- onay **yine istenir** (korumalı ortam),
- mesaj konusu `[ACİL]` ile başlar, böylece kim yayınladıysa kayıtta görünür.

### 6.4 Eski paketleri budama

Depoda **son 3 sürüm** tutulur; daha eskiler otomatik silinir. Budama
**kararlı depo yazıldıktan sonra** yapılır; yarıda kalırsa istemci etkilenmez
(eski sürümler zaten `pool/` içinde kalır, imza dosyası onları göstermez).

---

## 7. Acil durum rehberi

### 7.1 Hatalı paket yayınlandı (kullanıcılar bozuluyor)

1. **Panik yapma, sürümü geri çekme.** Depodan paket silmek, o sürümü kurmuş
   kullanıcıları "bulunamayan sürüm" durumunda bırakır.
2. Düzeltmeyi yap ve **daha yüksek yapı numarasıyla** yayınla:
   `0.5~faz3b` → `0.6~faz3b`. (Geri alma = daha yüksek revizyonlu düzeltme.)
3. `acil: evet` ile stable'a çık. Kapılar yine çalışır.
4. Kullanıcıya duyuru metni hazırla; "hangi sürümde, ne bozuldu, ne yapmalı".

Ne **yapılmaz**: paketi depodan elle silmek, sürüm numarasını düşürmek,
imza anahtarını değiştirmek (parmak izi pinli olduğu için tüm istemciler durur).

### 7.2 İmza anahtarı sızdı (veya sızdığından şüpheleniliyor)

1. **Derhal** yeni bir imza alt anahtarı üret; ana anahtar çevrimdışı kalır.
2. Yeni alt anahtarla depoyu yeniden imzala. **Eski imzalar geçersiz sayılır.**
3. Kullanıcıların yeni anahtarı alması gerekir: anahtar paketi (`anatolium-archive-keyring`)
   yeni sürümle dağıtılır; geçiş döneminde **iki anahtar birlikte** yayınlanır.
4. `[ACİL]` etiketiyle duyuru; hangi tarihte hangi anahtarın geçerli olduğu yazılır.
5. Sızıntı sonrası ilk iş: **eski anahtarla imzalanmış her şeyi** gözden geçir.

Ayrıntı: `docs/ANAHTAR.md`. Ana anahtar **hiçbir zaman** CI'ya konmaz; CI'da yalnız
imza alt anahtarı, geçici bir anahtarlık dizininde (`GNUPGHOME`) durur.

### 7.3 Hat çalışmıyor (günlerdir yeni sürüm yok)

1. `python3 tools/keepalive.py --check` → son hareket ne zaman?
2. `freshness.yml` iş akışının son koşusuna bak: kırmızı mı, hiç koşmamış mı?
   GitHub, 60 gün hareket olmayan depolarda zamanlanmış işleri **kendiliğinden
   kapatır** — `--check-disabled` bunu yakalar.
3. Mozilla'da gerçekten yeni sürüm var mı? `firefox_versions.json` → `FIREFOX_ESR`.
4. Sürüm var ama hat durduysa: `pipeline.py` çıktısındaki **karar** satırına bak
   (`auto`, `stop_major`, `reject`, `noop`). Durma nedeni oradadır.
5. Hat dururken **elle yayın yapma**; önce neden durduğunu yaz, sonra düzelt.

### 7.4 Yükleme yarıda kaldı

Merak etme: sıra sayesinde (§6.2) istemci ya eski sürümü görür ya yeni sürümü;
"yarım" bir durumu görmez. Yeniden çalıştırmak güvenlidir — betik aynı dosyaları
yeniden yükler, imza dosyasını en sona bırakır.

---

## 8. Depoyu yayına koyma (deploy)

```bash
# Deneme (hiçbir şey yüklemez, ne yapacağını yazar)
python3 packaging/deploy.py --target local-dir --dest /var/www/anatolium --dry-run
python3 packaging/deploy.py --target s3 --bucket ornek --dry-run

# Gerçek yükleme (kimlik bilgisi gerekir; bu ortamda YOK, denenmedi)
python3 packaging/deploy.py --target local-dir --dest /var/www/anatolium
python3 packaging/deploy.py --target s3 --bucket <kova>
```

`--interrupt-after <n>` ile "n dosya sonra bağlantı kopsun" senaryosu kurulabilir
(S10 bu yolu kullanır). `s3` hedefi `aws` komutunu çağırır; bu ortamda `aws` yok,
bu yüzden **denenmedi** (§9).

---

## 9. Neyin denendiği, neyin denenmediği

**Denendi ve ölçüldü (yerelde, sahte Mozilla sunucusu + test anahtarı):**

- Sürüm kararı (aynı ana sürüm / farklı ana sürüm / düşük / aynı) — 4 durum
- İmza doğrulama zinciri ve üç ayrı bozma senaryosu (bozuk imza, bozuk özet, bozuk dosya)
- Kapılar ve bir kapı bozukken yayının durması
- Beta → stable ayrımı, terfi sonrası stable'da görünme
- Yükleme sırası ve yarıda kesilme (istemci bozulmadı)
- Yeni alan adı çıkarsa durma
- `apt upgrade` ile yükseltmede kullanıcı verisinin korunması

**Denenmedi (nedeniyle birlikte):**

- **gerçek** Mozilla sunucusuna karşı tam koşu (dış trafik istenmedi; indirme
  yalnız doğrulama için bir kez yapıldı),
- **gerçek** GitHub Actions koşusu (bu ortamda `gh` ve depo bağlantısı yok;
  iş akışı dosyaları `workflow_lint.py` ile denetlendi, 3/3 temiz),
- **gerçek** S3/nesne depoya yükleme (`aws` komutu yok),
- gerçek imza anahtarıyla imzalama (yalnız test anahtarı kullanıldı, sonra silindi).

Ayrıntılı kanıt: `docs/FAZ3B-RAPORU.md` ve `docs/FAZ3B-SENARYOLAR.md`.
