# Anatolium kurulumu — Debian / Ubuntu

Bu sayfadaki komutlar **Debian 13 (trixie) ve üstü** ile **Ubuntu 24.04 ve
üstü** için geçerlidir. Komutları tek tek kopyalayıp uçbirime (terminal)
yapıştırın. `sudo` şifrenizi sorar; şifre yazarken ekranda hiçbir şey görünmez,
bu normaldir.

> `https://REPO.ORNEK` **yer tutucudur**; gerçek depo adresi yayın gününde
> duyurulacak. Adres değiştiğinde bu sayfa güncellenir.

---

## 1. Debian / Ubuntu — 4 adım

### Adım 1: Anahtarı indir

```bash
sudo install -d -m 0755 /etc/apt/keyrings
curl -fsSL https://REPO.ORNEK/anatolium-archive-keyring.gpg \
  | sudo tee /etc/apt/keyrings/anatolium-archive-keyring.gpg > /dev/null
```

Bu dosya **genel** anahtardır; bir şeyi şifrelemez, yalnızca "bu depodan gelen
imzayı tanı" demeye yarar.

### Adım 2: Depoyu tanıt

```bash
sudo tee /etc/apt/sources.list.d/anatolium.sources > /dev/null <<'EOF'
Types: deb
URIs: https://REPO.ORNEK
Suites: stable
Components: main
Architectures: amd64
Signed-By: /etc/apt/keyrings/anatolium-archive-keyring.gpg
EOF
```

### Adım 3: Listeyi güncelle

```bash
sudo apt update
```

Hata yoksa devam edin. `NO_PUBKEY`, `Unable to locate package` gibi bir mesaj
görürseniz `docs/DEPO.md` §10'daki tabloya bakın.

### Adım 4: Kur

```bash
sudo apt install anatolium
```

Kurulum bittikten sonra uygulamalar menüsünde **Anatolium**'u bulabilirsiniz.
Tarayıcı kendini varsayılan yapmaz; isterseniz
`sudo update-alternatives --config x-www-browser` ile seçebilirsiniz.

**Güncellemeler** aynı kanaldan gelir: `sudo apt update && sudo apt upgrade`.
Otomatik güncelleme istenirse `docs/DEPO.md` §11'deki
`unattended-upgrades` ayarı eklenir; yalnızca `Origin "Anatolia Labs"` ve
`stable` kanalı otomatik kurulur.

---

## 2. Daha kolay yol: keyring paketi

Depo, anahtarı ve `.sources` dosyasını kendisi kuran küçük bir paket de
yayınlar: **`anatolium-archive-keyring`**. Indirip kurun:

```bash
curl -fLO https://REPO.ORNEK/pool/main/a/anatolium-archive-keyring/anatolium-archive-keyring_2026.11.14_all.deb
sudo apt install ./anatolium-archive-keyring_2026.11.14_all.deb
sudo apt update
sudo apt install anatolium
```

`/etc/apt/sources.list.d/anatolium.sources` dosyası bu pakete aittir ve
**conffile**'dır: paket güncellense bile sizin değişiklikleriniz korunur
(örneğin beta kanalına geçmek için `Suites: stable` satırını
`Suites: beta` yapabilirsiniz).

---

## 3. anatol-x kullanıcısı

**Hiçbir şey yapmanız gerekmiyor.** anatol-x, `anatolium-archive-keyring`
paketi ve depo tanımı **önceden kurulu** olarak gelir. Yalnızca:

```bash
sudo apt install anatolium
```

Yeterlidir. Depo adresi ISO'ya gömülü olduğundan ek adım yoktur.

---

## 4. Kanal seçimi (stable / beta)

| Kanal | Kim için | Ne gelir |
|---|---|---|
| `stable` | Herkes (varsayılan) | Test edilmiş sürümler |
| `beta` | Denemek isteyenler | Yayın öncesi derlemeler; hata olabilir |

Beta'ya geçmek için `.sources` dosyasındaki satırı değiştirin:

```bash
sudo sed -i 's/^Suites: stable$/Suites: beta/' /etc/apt/sources.list.d/anatolium.sources
sudo apt update && sudo apt upgrade
```

Geri dönmek için `beta` → `stable` yapın ve
`sudo apt install anatolium/stable` ile stable sürümüne inin.

---

## 5. Kaldırma

```bash
sudo apt remove anatolium     # program gider, yer imleri/geçmiş KALIR
sudo apt purge anatolium      # program gider, yer imleri/geçmiş YİNE KALIR
```

Kullanıcı verisi `~/.local/share/anatolium` ve `~/.mozilla/anatolium`
dizinlerindedir; paket bunlara **hiçbir zaman** dokunmaz. Tamamen silmek
isterseniz o dizinleri kendiniz silmeniz gerekir.
