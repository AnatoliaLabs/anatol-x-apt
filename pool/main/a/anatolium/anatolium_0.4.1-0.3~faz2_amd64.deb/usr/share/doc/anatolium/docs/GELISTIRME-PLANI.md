# Anatolium 0.4.1 geliştirme adayı

Bu klasör, önceki 0.4.0 adayından ayrılmış 0.4.1 geliştirme çalışmasıdır. Paket sürümü `0.4.1-0.1.dev` olarak ayrılmıştır; 0.4.0 ile aynı NEVRA kullanılmaz. Kullanıcı profiline, önceki kaynaklara ve yayınlanmış paketlere bu geliştirme sırasında dokunulmamıştır.

## Bu adayın kapsamı

- Kütüphanede tek ziyaret, bir adresin tüm ziyaretleri, seçili ziyaretler ve gün/tarih aralığı için geçmiş temizleme; yerleşik geçmiş panelinin temizleme eylemini kapsamı açık kütüphane paneline yönlendirme. Milisaniye düzeyinde belirsiz ziyaret kimliklerinde işlem tahmin edilmez; hata gösterilir. Birden çok öğede hata olduğunda bazı öğeler işlenmiş olabilir.
- Kütüphanede yer imleri, ziyaretler ve tamamlanmış indirme kayıtları için arama ve tüm sonuçları seçme; indirilen dosyayı silmeden kayıt kaldırma. Gün bazında temizleme arama filtresiyle sınırlı değildir, onayda belirtilir.
- Sürekli yerleşik kenar çubuğu, kenar çubuğunda kütüphane/kişiselleştirme/menü, dikey sekmelerde yatay şeridi gizleme, iki satırlı varsayılan ve isteğe bağlı tek satırlı yerleşim.
- Komut paneli filtreleri ve kapatma düğmesi; hareket düzeyi ve sistemin azaltılmış hareket tercihine uygun panel animasyonları.
- Başlangıç sayfası, yerel duvar kâğıdı seçimi ve Anatolium Mobil yakında sunumu. Üç görsel yapay zekâ ile oluşturulmuş manzaralardır, gerçek fotoğraf değildir. Üçüncü taraf Firefox temalarının desteklenen başlık rengi/görseli korunur; her temanın her yüzeyde aynı görünmesi garanti değildir.
- Görünür menüde Son kapatılanlar bölümü kaldırılmıştır; oturum dosyaları bu nedenle silinmez. Mozilla motoru ve üçüncü taraflara ilişkin uygun atıflar korunur.

## Yapılmış izole testler

> **Düzeltme (2026-11-14, faz 1b):** Bu bölümdeki "45/45" ifadesi faz 1
> turunda doğru değildi; o turda ölçülen sonuç **41/45** idi (4 kontrol
> düşüyordu). Faz 1b'de dört kontrolün kök nedeni bulunup düzeltildi ve
> **2026-11-14** tarihli ölçümde sonuç **45/45** oldu. Ölçüm ortamı: Firefox
> ESR 153.6.0esr, Xvfb 1366x768x24 + openbox, geçici/izole profil,
> Marionette. Güncel tablo: `docs/DURUM-VE-TEST.md`, ayrıntı:
> `docs/FAZ1B-RAPORU.md`.

- Firefox ESR 153.6.0esr üzerinde temiz, geçici profille ana tarayıcı denemesi: **45/45** (2026-11-14 ölçümü). Duvar kâğıdının yeniden yükleme sonrası kalması, üçüncü taraf tema başlık rengi, gün aralığının sınırı, yer imi koruması ve ürün alanı kapsam içindedir.
- Yerleşik geçmiş panelinde gerçek satır eylemi, Delete tuşu, çoklu seçim, onayı iptal ve temizleme paneline yönlendirme denendi. Aynı adresin diğer ziyaretinin, yer iminin, örnek çerezin, örnek parolanın ve indirme dosyasının korunması izole profilde doğrulandı.
- Normal pencere kapatma sonrasında önceki sekmelerin açılması ve izole tarayıcı işleminin zorla sonlandırılması sonrası otomatik oturum kurtarma denendi. Bu, gerçek makinede elektrik kesintisini veya tüm olası oturum hatalarını ispatlamaz; kullanıcının önceki kurtarma ekranının kesin nedeni tespit edilmemiştir.
- Testler gerçek kullanıcı profiline karşı silme uygulamadı. Kullanıcının önceki geçmiş temizleme arızası birebir yeniden üretilemedi; bu nedenle her profil veya her hata senaryosunun çözüldüğü iddia edilmez. Eşzamanlı ziyaret yazımı ve çok büyük geçmiş üzerinde performansın fiziksel eski donanımda doğrulanması gerekir.

## Bilinçli olarak sonraki iterasyona bırakılanlar

Tam çoklu dil desteği ve gerçek Anatolium destek sitesi/bağlantısı, kullanıcının kararı doğrultusunda sonraya bırakılmıştır. Mevcut destek bağlantısı hâlâ Firefox desteğine gidebilir.

## Dağıtım güvenliği

Resmî paketler mevcut yayıncı anahtarıyla imzalanmalıdır. Özel anahtar, parola, profil ve kişisel veriler kaynak veya paket arşivine eklenmez. Geliştirme RPM'i kararlı sürüm olarak sunulmadan önce gerçek Fedora cihazda ayrıca denenmeli; profil yedeği korunmalıdır. Güncelleme motoru tarayıcının içinden değil imzalı RPM üzerinden dağıtılır.
