# Anatolium 0.4.1 — Faz 2 Raporu: doğrudan Debian paketi (.deb)

Tarih: 14 Kasım 2026 · Sürüm: **0.4.1** (yalnızca paket yapısı değişti: `0.4.1-0.3~faz2`) ·
Paket **imzasızdır** (anahtar istenmedi, kullanılmadı; `anatolium-imza-yedek.7z` açılmadı).

---

## A. Özet (5 satır)

1. `.deb` artık RPM'den dönüştürülmeden, doğrudan aynı sahnelenmiş dizinden üretiliyor: `packaging/deb.py` + `build.py --target rpm|deb|both`.
2. Güvenli Gezinme artık **açık ve kilitsiz**: `malware` ve `phishing` pref'leri `true`, kilit yok; kullanıcı kapatabilir. Kilitli pref sayısı 37 → **35 kilitli / 2 kilitsiz**.
3. Paket temiz Debian testing (forky) sisteminde `apt install ./anatolium.deb` ile kuruldu; smoke **45/45**, lock **37/37**, launcher **2/2**, restart **2/2**, session restore **2/2**.
4. Yükseltme (`0.4.1-0.1.dev` → `0.4.1-0.3~faz2`) yer imi/geçmiş/temayı korudu; `remove` ve `purge` kullanıcı profilini **silmedi**.
5. `libavcodec` ölçüm sonucu **Recommends**'a alındı (onsuz temel gezinti ve VP9/Opus çalışıyor, H.264/AAC çalışmıyor); lintian 77 E / 1 W / 8 I — hepsi gerekçeli.

---

## B. Görev görev değişiklikler, komutlar ve çıktılar

### §0 — Güvenli Gezinme kilidinin kaldırılması

**Ne yapıldı**

| Dosya | Değişiklik |
|---|---|
| `src/config/anatolium.cfg` | `lockPref("browser.safebrowsing.malware.enabled", true)` → `defaultPref(...)`; `phishing` satırı aynı şekilde. Yanına Türkçe gerekçe yorumu. |
| `src/config/policies.json` | İki girdi `{"Value": true, "Status": "default"}`. |
| `src/config/anatolium.js` | `pref("browser.safebrowsing.malware.enabled", false)` **çelişkisi düzeltildi** → `true`; eksik olan `phishing` satırı da `true` olarak eklendi. |
| `src/frontend/support.xhtml` | "kilitlidir" / "güvenli gezinme kilitli" metinleri "açık gelir, kullanıcı kapatabilir" olarak düzeltildi. |
| `tests/lock_test.py` | `parse_cfg` artık `lockPref`/`defaultPref`/`pref` ayrımını taşıyor; tabloya "beklenen kilit" kolonu eklendi; ölçüt "değer eşit **ve** kilit durumu beklentiye eşit". Ayrıca Marionette'ın test pref listesi kapatıldı (aşağıya bakın). |
| `tests/pref_snapshot.py` | **Yeni.** Çalışan tarayıcıdan gerçek pref değerlerini okur (kanıt aracı). |

**Bu işte bulunan iki tuzak (ikisi de ölçümü yanıltıyordu)**

1. **Marionette kirlenmesi.** Firefox, Marionette açıkken kendi
   `RecommendedPreferences` listesini uyguluyor ve
   `chrome/remote/content/shared/RecommendedPreferences.sys.mjs` satır 154-155'te
   `browser.safebrowsing.malware.enabled` ile `phishing.enabled` değerlerini
   **kullanıcı değeri olarak `false`** yapıyor. Yani kilit testi paketi değil,
   Marionette'ı ölçüyordu. Çözüm: teste `user_pref("remote.prefs.recommended", false)`
   satırı eklendi (Firefox'un kendi kodu bu pref'in `false` olması hâlinde listeyi
   uygulamıyor). Bu satır `lock_test.py`, `pref_snapshot.py`, `codec_test.py` ve
   `upgrade_profile.py` içinde var.
2. **`defaults/pref/anatolium.js` çelişkisi.** Bu dosya `anatolium.cfg`'den önce
   yükleniyor ve orada `false` yazıyordu. AutoConfig en son çalıştığı için sonuç
   doğruydu, ama iki dosya birbirini eziyordu; hangisi kazanacağı yükleme sırasına
   bağlıydı. İkisi de `true` yapıldı.

**Kanıt — çalışan tarayıcıdan (Marionette test listesi kapalı)**

```bash
python3 tests/pref_snapshot.py /opt/anatolium
```
```json
{
  "before": { "malware": true,  "malwareLocked": false,
              "phishing": true, "phishingLocked": false },
  "afterUserOff": { "malware": false, "locked": false }
}
```
Üçüncü satır, kullanıcının değeri **değiştirebildiğini** gösteriyor (kilit yok).

**Kanıt — kilit tablosu**

```bash
python3 tests/lock_test.py /opt/anatolium --pristine /var/tmp/ana/firefox
```
```
37/37 pref beklendiği gibi (değer doğru, kilit durumu doğru). Kilitli olması beklenen: 35, kilitli olmaması beklenen: 2.
browser.safebrowsing.malware.enabled   true  true  true  HAYIR  HAYIR
browser.safebrowsing.phishing.enabled  true  true  true  HAYIR  HAYIR
```
(Kolonlar: gerçek değer · motor varsayılanı · beklenen değer · kilitli mi · beklenen kilit)

**Not:** Ayarlar arayüzündeki onay kutusu bu turda otomatik doğrulanamadı
(ayarlar sayfası lit/shadow DOM ile geç çiziliyor, seçici bulunamadı);
değer `about:config` düzeyinde ölçüldü. Bu, "ÇALIŞTIRILAMADI" olarak
`docs/DURUM-VE-TEST.md`'de de yazılı.

### §1 — Deb üretimi (RPM'e bağımlı olmadan)

**Yeni dosya:** `packaging/deb.py` (~340 satır). **Değişen:** `packaging/build.py`
artık `--target rpm|deb|both` alıyor (varsayılan `both`) ve sahnelemeyi **bir kez**
yapıp iki paketi aynı ağaçtan üretiyor.

```bash
python3 packaging/build.py --target deb     # yalnızca .deb
python3 packaging/build.py                  # rpm + deb
```

**Alien / dönüştürme yok:** paket, `dist/anatolium/` ağacının kopyasına
`DEBIAN/` dizini yazılıp `dpkg-deb --root-owner-group -Zxz --build` çağrılarak
üretiliyor. Hiçbir yerde `alien`, `rpm2cpio` veya RPM→deb dönüşümü yok.

**Sürüm kanıtı** (build sırasında otomatik yazdırılıyor):

```
0.4.1-0.3~faz2 lt 0.4.2-1        → DOĞRU
0.4.1-0.1.dev  lt 0.4.1-0.3~faz2 → DOĞRU
```

**Dosya listesi karşılaştırması (RPM ↔ deb)**

| Ölçüm | Sonuç |
|---|---|
| Ortak dosya | **91** |
| Yalnız RPM'de olan | **0** |
| Yalnız deb'de olan | 2 — `usr/share/doc/anatolium/copyright`, `usr/share/doc/anatolium/changelog.gz` (Debian'ın zorunlu metadata dosyaları) |
| Boyut/mod/link farkı | **0** |

Yani iki paket birebir aynı dosyaları taşıyor; tek fark Debian'ın istediği iki
belge dosyası.

### §2 — Metadata

`dpkg-deb -f dist/anatolium_0.4.1-0.3~faz2_amd64.deb`:

```
Package: anatolium
Version: 0.4.1-0.3~faz2
Section: web
Priority: optional
Architecture: amd64
Maintainer: Anatolia Labs <anatoliaosf@proton.me>
Installed-Size: 359506
Homepage: https://github.com/AnatoliaLabs
Depends: fontconfig, hicolor-icon-theme, libasound2t64, libatk-bridge2.0-0t64,
 libatk1.0-0t64, libc6, libcairo-gobject2, libcairo2, libdbus-1-3, libdrm2,
 libfontconfig1, libfreetype6, libgbm1, libgcc-s1, libgdk-pixbuf-2.0-0,
 libglib2.0-0t64, libgtk-3-0t64, libpango-1.0-0, libpangocairo-1.0-0,
 libstdc++6, libwayland-client0, libwayland-egl1, libx11-6, libx11-xcb1,
 libxcb-shm0, libxcb1, libxcomposite1, libxcursor1, libxdamage1, libxext6,
 libxfixes3, libxi6, libxrandr2, libxrender1, libxshmfence1, zlib1g
Recommends: libavcodec63 | libavcodec62 | libavcodec61
Provides: www-browser, gnome-www-browser
Description: Anatolia Labs web browser based on Firefox ESR
 (Türkçe 5 satır + İngilizce 3 satır açıklama)
```

- **Installed-Size doğrulaması:** bildirilen 359 506 KiB; kurulumdan sonra
  `du -sk` toplamı 359 741 KiB (du 4 KiB blok yuvarlaması yapar). Tutarlı.
- **postinst:** `update-desktop-database`, `gtk-update-icon-cache` (RPM post
  betiğiyle aynı adımlar) + `update-alternatives --install ... **40**` (x-www-browser
  ve gnome-www-browser).
- **prerm:** `update-alternatives --remove` (iki grup).
- **postrm (purge):** yalnızca `/var/lib/anatolium` (varsa) silinir; betikte
  kullanıcı ev dizinine giden **tek bir komut yok**. `~/.local/share/anatolium`
  ve `~/.mozilla/anatolium` asla silinmez — FORKY-A testinde purge sonrası 52 MB'lık
  profil yerinde durdu.
- **`/usr/share/doc/anatolium/`:** Debian makine-okunur `copyright` (DEP-5 biçimi;
  MPL-2.0 + motorun kendi lisans dosyalarına işaret eder, hukuki yorum içermez),
  `changelog.gz`, `README.md`, `LICENSE`, `docs/`.
- **conffile DEĞİL:** `policies.json` ve `anatolium.cfg` `/opt/anatolium` altında
  normal dosya olarak kurulur; `DEBIAN/conffiles` dosyası **yoktur** (paket
  yükseltmesinde üzerine yazılır, kullanıcıya soru sorulmaz).

### §3 — Bağımlılıklar ve libavcodec matrisi

**Yöntem:** `alien`/elle liste değil; sahnelenmiş ağaçtaki tüm ELF dosyalarının
`NEEDED` kayıtları `objdump` ile okundu, her kütüphane `dpkg -S` ile pakete
eşlendi. Çapraz kontrol için `dpkg-shlibdeps` de çalıştırıldı ve **aynı 27 paketi**
(üstelik sürüm kısıtlarıyla) verdi:

```
shlibs:Depends=libasound2t64 (>= 1.0.16), libatk1.0-0t64 (>= 1.12.4), libc6 (>= 2.34), ...
```

**Eşleşmeyen (unresolved) 14 soname** — hepsi motorun **kendi** kütüphaneleri,
paket içinde geliyor: `libgkcodecs.so, liblgpllibs.so, libmozavutil.so, libmozgtk.so,
libmozsandbox.so, libmozsqlite3.so, libmozwayland.so, libnspr4.so, libnss3.so,
libnssutil3.so, libplc4.so, libplds4.so, libsmime3.so, libssl3.so`.

**Elle eklenen 10 paket (ELF listesinde görünmez, çalışma anında `dlopen` ile
yüklenir):** `libatk-bridge2.0-0t64`, `libgbm1`, `libdrm2`, `libxshmfence1`,
`libwayland-client0`, `libwayland-egl1`, `zlib1g`, `fontconfig`,
`hicolor-icon-theme`. Ölçümde forky bu paketlerin hepsini zaten dolaylı olarak
kurdu; açıkça yazılmasının nedeni daha yalın sistemler.

**Eski elle yazılmış listeyle karşılaştırma** (`0.4.1-0.1.dev`, 39 satır):

| Kategori | Paketler |
|---|---|
| **Fazlalık (bizde var, eskide yok)** | yok |
| **Çıkarılan 1** | `libdbus-glib-1-2` — forky chroot'unda **kurulmadan** tarayıcı, video ve tüm testler çalıştı; Firefox ESR 153 bu kütüphaneyi kullanmıyor |
| **Çıkarılan 2** | `util-linux` — Essential paket; lintian `E: depends-on-essential-package-without-using-version` veriyordu, her sistemde zaten kurulu |
| **Depends'ten Recommends'a taşınan** | `libavcodec63\|62\|61\|60\|59` → `libavcodec63 \| libavcodec62 \| libavcodec61` |
| **Aynen korunan** | kalan 27 paket + `libatk-bridge2.0-0t64`, `libgbm1`, `libdrm2`, `libxshmfence1`, `libwayland-client0`, `libwayland-egl1`, `zlib1g`, `fontconfig`, `hicolor-icon-theme` |

**libavcodec matrisi — ölçüm**

| Senaryo | Temel gezinti | H.264/AAC (mp4) | VP9/Opus (webm) |
|---|---|---|---|
| **libavcodec YOK** | ✅ sayfa açıldı, başlık okundu | ❌ `play(): NotSupportedError`, `videoWidth=0` | ✅ oynadı (`currentTime=2.98`, 320 px) |
| **libavcodec63 VAR** | ✅ | ✅ oynadı (`currentTime=2.99`, 320 px) | ✅ oynadı |

`canPlayType` çıktısı da aynı tabloyu doğruluyor: yokken
`"video/mp4; codecs=avc1..."` → `""`, varken → `"probably"`.

**Karar:** Temel gezinti libavcodec olmadan çalıştığı için paket **Depends
değil Recommends**'a alındı. `apt install` varsayılan olarak Recommends'ları da
kurar (FORKY-B testinde `libavcodec63` otomatik geldi); yalnızca
`--no-install-recommends` kullanan yalın sistemlerde mp4 oynamaz — bu bilinçli
bir tercih ve burada yazılı.

### §4 — lintian

```bash
lintian --info --display-info dist/anatolium_0.4.1-0.3~faz2_amd64.deb
```

| Etiket | Seviye | Sayı | Karar |
|---|---|---|---|
| `dir-or-file-in-opt` | E | 70 | **Bırakıldı.** Tüm çalışma zamanı `/opt/anatolium` altında; bu mimari karar (motor tarball'ı olduğu gibi kuruluyor, RPM paketi de aynı yolu kullanıyor). `/usr/lib`'e taşımak motoru yeniden derlemeyi gerektirir — bu fazın kapsamı dışı. |
| `embedded-library` (freetype, libavutil, libjpeg, libjsoncpp, nspr, nss) | E | 6 | **Bırakıldı.** Motorun içinde gelen kütüphaneler; Mozilla'nın resmî ikilisi değiştirilmiyor. Ayrı paketlere ayırmak Firefox'u kaynaktan derlemek demek. |
| `relative-library-search-path` (`libonnxruntime.so`, RUNPATH `$`) | E | 1 | **Bırakıldı.** Mozilla'nın ikilisinin kendi RUNPATH'i; `patchelf` ile değiştirmek "değiştirilmemiş motor" ilkesini bozar ve güncelleme paketinde geri gelir. |
| `hardening-no-pie` (`/opt/anatolium/firefox`) | W | 1 | **Bırakıldı.** Mozilla'nın önceden derlenmiş ikilisi; bizim derlemediğimiz kod. |
| `hardening-no-fortify-functions` (5 dosya) | I | 5 | **Bırakıldı.** Aynı gerekçe (motor ikilileri). |
| `font-in-non-font-package`, `font-outside-font-dir` (Twemoji) | I | 2 | **Bırakıldı.** Emoji fontu motorun paketiyle geliyor. |
| `extra-license-file` (`LICENSE`) | I | 1 | **Bırakıldı.** `copyright` dosyası zaten var; `LICENSE` motorun kendi lisans metni olarak belgelerde duruyor (RPM ile aynı dosya listesi). |

**Bu turda düzeltilenler (önce/sonra):**

| Önce | Düzeltme |
|---|---|
| `E: shared-library-is-executable` ×21 | Sahnelemede `*.so` dosyalarının çalıştırma biti kaldırıldı (0644), hem RPM hem deb için |
| `E: uncompressed-manual-page` | Man sayfası `gzip -9n` ile sıkıştırıldı |
| `W: bad-whatis-entry` | Man sayfasında `.SH NAME` bölümü tek satıra alındı |
| `W: appstream-metadata-validation-failed` | Metainfo dosyasına `<developer>` eklendi; dosya adı component id ile eşitlendi (`io.github.anatolialabs.Anatolium.metainfo.xml`) |
| `W: no-manual-page` | `src/launcher/anatolium.1` yazıldı, paketle birlikte kuruluyor |
| `E: depends-on-essential-package-without-using-version` | `util-linux` Depends'ten çıkarıldı |
| `W: file-missing-in-md5sums` ×18 | `md5sums` yolları `./` öneki olmadan yazılıyor |

Kalan `E:` sayısı **77**; hepsi yukarıdaki tabloda gerekçeli. Gerekçesiz `E:` yok.

### §5 — Temiz Debian testing testleri

Ortam: `debootstrap --variant=minbase forky` (bugün Debian testing = forky),
yeni kullanıcı `deneme`, temiz `HOME`, gerçek kullanıcı profiline dokunulmadı.

**a) Bağımlılık çözümü (FORKY-B, tamamen temiz sistem)**

```
apt update            → rc=0
kurulu paket sayısı   → 77 (minbase)
apt install -y /root/paket.deb
kurulum               → rc=0, kurulu paket sayısı 305 (228 paket bağımlılıkla geldi)
libavcodec63          → Recommends olduğu için otomatik kuruldu
```

**b) Kurulu paket üzerinde testler** — `docs/DURUM-VE-TEST.md` Faz 2 tablosu,
satır 3-8: smoke 45/45, lock 37/37, launcher 2/2 (D-Bus'lu), restart 2/2,
session restore 2/2.

> `smoke.py` ilk çalıştırmada 44/45 verdi: eksik olan tek kontrol ImageMagick'in
> `import` komutuydu (ekran görüntüsü adımı). `imagemagick` kurulduktan sonra
> 45/45. Bu bir ortam eksiğiydi, ürün hatası değil.
> `launcher.py` D-Bus oturum veri yolu olmayan kabukta 1/2 verdi; `dbus-run-session`
> ile 2/2. Gerçek masaüstü oturumlarında D-Bus vardır.

**c) Yükseltme** `0.4.1-0.1.dev` → `0.4.1-0.3~faz2`

```
eski paket kuruldu (0.4.1-0.1.dev)
→ profil: yer imi GUID -5Luh2a_5EeB, geçmiş kaydı, anatolium.theme.mode = dark
apt install ./yeni.deb → "1 upgraded, 0 newly installed ... (21.5 kB disk kazancı)"
→ doğrulama: bookmark aynı GUID ile duruyor, geçmiş duruyor, tema "dark" duruyor
```
Tarayıcı yükseltmeden sonra normal açıldı (Marionette ile okundu).

**d) remove → purge → yeniden kurulum**

```
apt remove  → /opt/anatolium YOK, /usr/bin/anatolium YOK, profil 52 MB DURUYOR
apt purge   → profil yine DURUYOR, x-www-browser alternatifi kaydı silindi
yeniden kurulum → profil yerinde, tarayıcı açılıyor
```

**e) update-alternatives**

```
kurulum öncesi varsayılan: /usr/local/bin/dummy-browser (öncelik 100)
kurulum sonrası  : /usr/local/bin/dummy-browser   ← DEĞİŞMEDİ (Anatolium öncelik 40)
--display        : /usr/bin/anatolium - priority 40
--set x-www-browser /usr/bin/anatolium → /usr/bin/anatolium (elle seçim çalışıyor)
```
Boş sistemde (başka tarayıcı yokken) Anatolium otomatik seçilir; bu beklenen
davranış, çünkü grubu sağlayan tek paket odur.

**f) Çalışan tarayıcı varken yükseltme — yalnızca gözlem**

```
yükseltme öncesi: PID 46441, sekmeler: [file:///opt/testler/medya/test.html]
apt install --reinstall ./yeni.deb  (Unpacking + Setting up tamamlandı)
yükseltme sonrası: PID 46441 (aynı), sekmeler korundu, yeni sekme açılabildi,
                   AnatoliumShell çalışıyor, çökme yok
```
Gözlem: açık tarayıcı paket değişiminden etkilenmedi ve kapanmadı. Bu senaryonun
**düzeltmesi bu fazda ele alınmadı** (istenen buydu); Faz 5'e not düşüldü.

### §6 — Belgeler

- `docs/YEREL-BUILD.md`: deb üretimi, gereken araçlar, lintian denetimi,
  `debootstrap` ile temiz sistemde deneme, Faz 2 test betikleri.
- `docs/DURUM-VE-TEST.md`: Faz 2 test tabloları (ortam + sonuç +
  "ÇALIŞTIRILAMADI" maddeleri).
- Bu dosya (`docs/FAZ2-RAPORU.md`).

### §7 — Teslim edilen dosyalar

`dist/` içinde:

| Dosya | Boyut | sha256 |
|---|---|---|
| `anatolium_0.4.1-0.3~faz2_amd64.deb` | 97 998 144 B | `cafbe099d6a14af51116209d8067c6628e37df4f8e4f83e7388dc29dc5bfdeb2` |
| `anatolium-0.4.1-0.3~faz2.x86_64.rpm` | 97 199 721 B | `236b6fb4a97a6495f77142bd1cec0395d754d84f2b64c613f02cdc539a55f50f` |
| `anatolium-0.4.1-frontend.tar.xz` (RPM kaynağı) | 3 613 044 B | — |
| `SHA256SUMS.txt` | — | yukarıdaki iki paketin özetleri |

Kaynak arşivi (bu çalışma alanının kökünde):
`anatolium-0.4.1-faz2.zip` (`dist/` ve `.git/` arşive dahil değildir; 100 dosya).
Arşivin sha256 özeti teslim mesajındadır — arşiv bu raporu da içerdiği için
özeti raporun içine yazmak kendi kendini doğrulamayan bir döngü olurdu.

---

## C. Değişen dosyalar

| Dosya | Tür | Ne değişti |
|---|---|---|
| `packaging/deb.py` | **yeni** | Doğrudan .deb üretici (control, postinst/prerm/postrm, copyright, changelog, md5sums, bağımlılık üretimi) |
| `packaging/build.py` | değişti | `--target rpm\|deb\|both`; sahneleme tek kez; `normalize_library_modes()`; man sayfası; metainfo adı; sürüm değişkenleri |
| `packaging/anatolium.spec` | değişti | `%{anatolium_version}` makrosu, Release `0.3~faz2`, man sayfası ve yeni metainfo adı dosya listesinde |
| `packaging/apply_frontend.py` | değişti | Manifest metni: "signed RPMs" → "yeni test edilmiş paket (RPM veya deb)" |
| `src/config/anatolium.cfg` | değişti | İki safebrowsing satırı `lockPref` → `defaultPref` |
| `src/config/anatolium.js` | değişti | malware `false` → `true`, phishing satırı eklendi |
| `src/config/policies.json` | değişti | İki girdi `Status: default` |
| `src/frontend/support.xhtml` | değişti | Kilit iddiası taşıyan iki paragraf |
| `src/launcher/anatolium.metainfo.xml` | değişti | `<developer>` eklendi |
| `src/launcher/anatolium.1` | **yeni** | Türkçe man sayfası |
| `tests/lock_test.py` | değişti | Kilit beklentisi kolonu, Marionette test pref listesi kapalı |
| `tests/pref_snapshot.py` | **yeni** | Çalışan tarayıcıdan pref kanıtı |
| `tests/codec_test.py` | **yeni** | Kodek/oynatma matrisi |
| `tests/upgrade_profile.py` | **yeni** | Yükseltme sonrası profil (yer imi/geçmiş/tema) doğrulaması |
| `docs/YEREL-BUILD.md` | değişti | Deb bölümü |
| `docs/DURUM-VE-TEST.md` | değişti | Faz 2 test tabloları |
| `docs/FAZ2-RAPORU.md` | **yeni** | Bu rapor |

---

## D. Test tabloları

Tam tablo: `docs/DURUM-VE-TEST.md` → "Faz 2 — Debian paketi testleri".
Özet: 19 satır; 15 BAŞARILI, 1 GÖZLEM (istenen), 2 KISMİ (ikisi de ortam kaynaklı
ve gerekçeli), 1 bilgi satırı (lintian). Ayrıntılı liste ve "ÇALIŞTIRILAMADI"
maddeleri orada.

---

## E. Açık sorular ve riskler (hukuki yorum yok)

1. **Paket imzasız.** Depoya konup `apt update` ile kullanılacaksa imza
   gerekecek; anahtar/parola istenmedi, kullanılmadı.
2. **`/opt` yerleşimi.** lintian'ın 70 `E:` kaydı buradan geliyor. Debian
   politikası `/opt`'u üçüncü taraf yazılıma ayırır; bizim durumumuzda tüm
   çalışma zamanı orada. `/usr/lib/anatolium`'a taşımak motoru yeniden
   derlemeyi (veya en azından göreli yolları yeniden yazmayı) gerektirir.
3. **libavcodec Recommends.** `--no-install-recommends` ile kuran kullanıcıda
   mp4 (H.264/AAC) oynamaz, webm oynar. Depo politikası bunu Depends'e almayı
   gerektiriyorsa tek satırlık değişiklikle alınabilir
   (`ANATOLIUM_LIBAVCODEC=depends`).
4. **`libdbus-glib-1-2` çıkarıldı.** Bu ortamda onsuz her şey çalıştı; çok eski
   ya da farklı masaüstü yapılandırmalarında yeniden gerekebilir.
5. **Marionette ile ölçüm tuzağı.** Testlerde `remote.prefs.recommended=false`
   satırı olmadan safebrowsing ölçümü yanlış çıkar; yeni test yazan herkesin
   bilmesi gerekiyor (dokümanlara yazıldı).
6. **Çalışırken yükseltme.** Bu turda yalnızca gözlendi; çökme görülmedi ama
   garanti değil. Gerçek kullanıcı verisi riski Faz 5'te ele alınmalı.
7. **Wayland / GPU / ses** ölçülmedi (ortamda yok).
8. **forky sürüm kayması.** Paket bugünkü forky'de test edildi; forky
   değiştikçe bağımlılık adları (`libasound2t64`, `libgtk-3-0t64` gibi `t64`
   ekleri) değişebilir; depo güncellemesinde yeniden üretilmeli.
9. **AppStream / metainfo** dosyası Türkçe özet içermiyor (İngilizce). Mağaza
   görünürlüğü için istenirse eklenebilir.

---

## F. Yapmadıklarım

1. **Paketi imzalamadım** (istenmedi; anahtar/parola yok, `anatolium-imza-yedek.7z`
   açılmadı ve kullanılmadı).
2. **RPM'i kurup test etmedim.** RPM yalnızca dosya listesi karşılaştırması için
   üretildi; Fedora üzerinde kurulum/yükseltme bu fazın kapsamı değil.
3. **`/opt` yerleşimini değiştirmedim.** lintian'ın `dir-or-file-in-opt`
   kayıtları gerekçesiyle bırakıldı.
4. **Motoru yeniden derlemedim.** Firefox ESR 153.6.0 ikilisi SHA-512 doğrulanmış
   hâliyle kullanıldı; `embedded-library` ve `hardening-*` uyarıları bu yüzden
   gerekçeli bırakıldı.
5. **Ayarlar arayüzündeki onay kutusunu otomatik doğrulamadım** (seçici
   bulunamadı); değer `about:config` düzeyinde kanıtlandı.
6. **Wayland, GPU hızlandırma ve ses çıkışını ölçmedim** (ortamda yok).
7. **Çalışırken yükseltme için çözüm üretmedim** — istenen buydu, yalnızca
   gözlem yaptım.
8. **Sürüm numarasını artırmadım.** 0.4.1 sabit kaldı; artırma en sonda yapılacak.
9. **Ayrı bir `debian/` dizini (dpkg-buildpackage) kurmadım.** Paket doğrudan
   `dpkg-deb` ile üretiliyor; `dpkg-buildpackage`/`sbuild`/`pbuilder` akışı
   istenirse Faz 3 için ayrı iş.
10. **`lintian` gerekçelerini paket içine override olarak koymadım** — RPM ile deb
    dosya listesi eşitliği bozulmasın diye; gerekçeler bu raporda.
