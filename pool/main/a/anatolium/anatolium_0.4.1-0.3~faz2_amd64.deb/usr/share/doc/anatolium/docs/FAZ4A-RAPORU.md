# FAZ 4A — RAPOR (canlı indirme paneli + arayüz denetimi)

Sürüm **0.4.1** (değişmedi). Ölçüm ortamı: yerel test derlemesi, motor Firefox
ESR 153.7.0, Xvfb + openbox, Marionette. Hiçbir ölçüm "tahmini" yazılmadı;
ölçülemeyen her şey §F'te.

---

## A. ÖZET

- **Madde 4: 13/13** canlı indirme kontrolü geçti (`olcumler/faz4a-dl-live.json`).
- **Madde 4m: smoke 45/45**, `lock_test --defaults` 49/49, yavaş sunucu 11/11.
- **Madde 5:** 7 yüzey × 2 tema × 2 ön ayar × 2 pencere = **56 ekran görüntüsü**;
  kontrast **hesaplandı**. Denetim öncesi en kötü oran **1,24:1**, üç düşük riskli
  düzeltmeden sonra ürün yüzeylerinde **4,68:1** (WCAG AA 4,5:1 üstü).
- **Kapanış kuralı:** 4a–4m'nin tamamı geçti, smoke 45/45 → **"tamamlandı"**.
  Tek açık kalem §E'de "karar bekleyenler" (tasarım kararı gerektiren 2 konu).
- `packaging/` **hiç değiştirilmedi** (orijinal zip ile bayt-bayt aynı).
  Arayüz enjeksiyonu `packaging/` dışındaki bir betikte: `inline_downloads.py`.

---

## B. MADDE MADDE DEĞİŞİKLİKLER + KANIT

### 0. Hazırlık
Zip sha256 `f970164b…fe94e995` doğrulandı (Drive'dan indirilmeden **önce**),
`/var/tmp/faz4a/work/` altına açıldı. Motor `packaging/engine_fetch.py` ile
indirildi; imza doğrulaması betikte hatalı çıktı, `gpg` ile **elle** doğrulandı
ve kilit dosyası yazıldı (`engine.lock.json`). Baseline smoke **45/45**.
İndirme kodu: `library.js` içindeki `#an-drawer` panelleri + motorun
`Downloads.sys.mjs`'i (kanıt: `docs/FAZ4A-BASELINE.md`).

### 1. Test altyapısı — `tests/slow_download_server.py` (+ 11 test)
`127.0.0.1`'e bağlanır; boyut, hız (bayt/sn), Range desteği, aktarım ortasında
bağlantı kesme, `Content-Length`'siz kip ve eşzamanlı indirme destekli.
Kendi testleri **11/11**. 20 eşzamanlı indirmede sunucu kuyruğu yetmediği için
`request_queue_size=128` + `daemon_threads=True` yapıldı (ölçüldü: 20/20 etkin).

### 2. Canlı indirme paneli — `src/frontend/downloads.js` (870 satır)
Satır başına canlı ilerleme, orta kırpmalı dosya adı (tam ad tooltip'te),
kaynak sunucu, durum etiketi; yüzde bilinmiyorsa belirsiz animasyon +
`role="progressbar"` (bilinmiyorsa `aria-valuenow` **yok**, "Boyut bilinmiyor").
Türkçe sayı biçimi `Intl.NumberFormat("tr")` → "368 KB / 1,1 MB · 401 KB/sn ·
yaklaşık 2 sn kaldı". Hız ≈3 sn hareketli ortalama; ETA 24 saatte sınırlı.
Duraklat/devam (Range yoksa **devre dışı + gerekçe tooltip'te**), iptal,
yeniden dene, dosyayı aç, klasörde göster, listeden kaldır,
"Tamamlananları temizle" (dosyalara dokunmaz). Durumlar: indiriliyor /
duraklatıldı / tamamlandı / başarısız (sade Türkçe neden) / engellendi.
Performans: tek rAF, satır başına ≥250 ms aralık, panel kapalıyken **hiç DOM
yazımı** yok. Erişilebilirlik: `aria-live` yalnızca tamamlandı/başarısız;
`motion=off` → animasyon yok.

**Kanıt (ölçüldü):** 4a 7 farklı canlı metin örneği; 4b 245 760 B'de donma →
devam → tamamlanma; 4c `range_olcumu:"no"`, `canPause:false`, `disabled:true`,
tıklayınca indirme **durmuyor**; 4g.2 20 satırda `maxGap 102 ms`,
`p95 85 ms`, en uzun tek görev 17,3 ms; 4k DOM 2988 → 2988.

**Range ölçümü (karar):** motorun `saver.request` başlıkları okunamıyor
(`NS_ERROR_NOT_AVAILABLE`), chrome XHR `getResponseHeader` **null** döndürüyor.
Tek güvenilir yol `fetch(url,{method:"HEAD"})` → `Accept-Ranges: bytes`/`ETag`.
Duraklatma = motorun `cancel()`'ı, kısmi veri korunarak.

### 3. Gösterge
Düğmede canlı halka + etkin indirme rozeti; panel toplam başlığı
("2 indiriliyor · %43 · 5,1 MB/sn"). **Davranış değişikliği:** panel
kendiliğinden açılmıyor (odak çalınmasın diye); yalnızca rozet/halka güncellenir —
bu, önceki sürümden bilinçli bir fark ve §E'de ayrıca yazıldı.

### 4. Testler — `tests/downloads_live.py` (13 kontrol)
`4a, 4b, 4c, 4d, 4e, 4f, 4g.1, 4g.2, 4h, 4i, 4j, 4k, 4l` — hepsi **PASS**.
`tests/smoke.py` indirme adımı yeni panele uyarlandı; **ölçülen şey değişmedi**
(dosya diskte mi + listede adı görünüyor mu). Tablo: `docs/DURUM-VE-TEST.md` §2–3.

### 5. Arayüz denetimi — `tests/ui_audit.py`, `docs/UI-DENETIM.md`
Ölçüm: gerçek piksellerden WCAG bağıl parlaklığı (saydam katmanlar birleştirilir),
hedef boyutu, Tab/odak halkası, 900 px taşma. Düzeltilenler:
1. Seçili segment yazısı **1,24–1,40:1 → ≥4,68:1** (metin normal metne, seçim
   arka plan + iç çerçeve + kalın yazı).
2. Vurgu renginin metin olarak kullanıldığı 8 yer **→ `--an-accent-strong`**
   (`AnatoliumTheme.accentText()`, AA'ya zorlanır; dolgular özgün renkte).
3. Düğme dolgusu üstündeki metin (`readableInk` eşiği) **1,39:1 → AA**
   (`accentInk` gerçek kontrasta bakar).
   Her düzeltmeden sonra smoke **45/45** (kayıtlı koşular).

---

## C. DEĞİŞEN DOSYALAR

| Dosya | Ne oldu |
|---|---|
| `src/frontend/downloads.js` | **YENİ** — canlı panelin tamamı (madde 2+3) |
| `src/frontend/library.js` | indirme listesi canlı panele devredildi; sonunda tek satır enjeksiyon işareti |
| `src/frontend/shell.css` | panel/çubuk/rozet stilleri; seçili segment kontrastı; `--an-accent-strong` kullanımları |
| `src/frontend/theme.js` | `accentText()`, `accentInk`, `--an-accent-strong` belirteci |
| `src/frontend/home.css` | vurgu metinleri `--accent-strong`'a bağlandı |
| `src/frontend/shell.js` | **yalnızca** indirme göstergesiyle ilgili kod (kenar çubuğuna dokunulmadı) |
| `tests/slow_download_server.py` | **YENİ** |
| `tests/downloads_live.py` | **YENİ** — 13 kontrol |
| `tests/ui_audit.py` | **YENİ** — arayüz denetimi + ekran görüntüleri |
| `tests/smoke.py` | indirme adımı yeni panele uyarlandı, panel açma kapılandı |
| `docs/DURUM-VE-TEST.md` | madde tablosu + 4/4m sonuçları |
| `docs/UI-DENETIM.md` / `.json` | denetim listesi + ham ölçüm |
| `docs/screenshots/ui/*.png` | 56 ekran görüntüsü (≈2,2 MB) |
| `docs/screenshots/dl-panel-*.png` | 4 indirme paneli görüntüsü (4l) |
| `olcumler/faz4a-dl-live.json` | 13 kontrolün ham kanıtı |
| `packaging/` | **DEĞİŞMEDİ** (diff: aynı) |

---

## D. TEST TABLOLARI

| Test | Sonuç |
|---|---|
| `tests/downloads_live.py` (13 kontrol) | **13/13 PASS** |
| `tests/smoke.py` | **45/45** |
| `tests/lock_test.py --defaults` | **49/49** (varsayılanlar 69/69) |
| `tests/slow_download_server.py` | **11/11** |
| Arayüz denetimi (kontrast) | 8 kombinasyon, ürün yüzeyleri ≥ **4,68:1** |

---

## E. AÇIK SORULAR / KARAR BEKLEYENLER

1. **Tıklama hedefi 24 px eşiği:** durum çubuğu zoom düğmeleri 18×18 px,
   sekme kapatma 20×20 px. Seçenekler: (a) `padding` ile 24 px'e çıkar
   (+2 px yükseklik), (b) görsel aynı kalıp `::after` ile vuruş alanı büyüt,
   (c) kabul et. **Ölçüm:** her kombinasyonda 2–5 küçük hedef.
2. **Marka yazısı** gradyan + `background-clip:text` olduğu için kontrastı
   ölçülemiyor (hesaplanan 1,55:1 yanıltıcı). WCAG "logotype" istisnası.
   Karar: olduğu gibi mi kalsın, düz metne mi dönülsün?
3. **Panel otomatik açılmıyor** (odak çalınmasın diye). İndirme başlarken
   panelin kendiliğinden açılması isteniyorsa tek satırlık değişiklik; ama
   odak/klavye davranışı değişir.
4. **`packaging/apply_frontend.py`:** enjeksiyon şu an `packaging/` dışındaki
   `inline_downloads.py` ile yapılıyor (dosya el değmemiş). Üretimde bu adımın
   `packaging/` içine taşınması gerekir; bu, "Kapanış 2" oturumunun kararı.
5. Motorun kendi uyarısı: `browser.aboutwelcome.enabled` kilit biti Marionette
   oturumunda farklı görünüyor (bilinen fark, `lock_test` raporluyor).

---

## F. YAPMADIKLARIM

- **Ölçüm aracı yanlış pozitifleri** (`#personal-toolbar-empty-desc`,
  `.text-link` = görünmez motor şablonları; adres çubuğundaki çapraz tarama =
  el değmemiş motorda da aynı) düzeltilmedi; raporda yanlış pozitif olarak
  işaretlendi. Saydam yüzeyler için "görünürlük kapısı" eklendi.
- **Ekran görüntüleri 900 px/1366 px ile sınırlı** — istenen iki genişlik bu;
  daha küçük (ör. 720 px) ölçüm yapılmadı.
- **Renk körlüğü simülasyonu** yapılmadı (istenmedi; seçim durumu artık renkten
  bağımsız da okunuyor).
- **Üretim deb/rpm paketi üretilmedi** — bu iş kapsamı dışı; ölçümler yerel test
  derlemesinde alındı (`packaging/build.py --target deb` çıktısı `/var/tmp`).
- **Ekran okuyucu ile canlı oturum testi** yapılmadı; erişilebilirlik
  `aria-live`/`role`/odak ölçümleriyle doğrulandı (gerçek NVDA/Orca koşusu yok).
- **20 eşzamanlı indirme ölçümü** test profilinde bağlantı pref'leri yükseltilerek
  yapıldı; ürün varsayılanı (sunucu başına 6 bağlantı) değiştirilmedi.
