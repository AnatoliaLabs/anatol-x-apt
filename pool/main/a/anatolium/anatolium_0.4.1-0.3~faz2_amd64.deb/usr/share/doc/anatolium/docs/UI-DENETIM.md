# ARAYÜZ DENETİMİ — Faz 4A-düzeltme, madde 4

Ölçüm betiği: `tests/ui_audit.py` · ham veri: `docs/UI-DENETIM.json` ·
ekran görüntüleri: `docs/screenshots/ui/` (56 PNG).

**Bu turda değişenler (hepsi ölçüm aracının kendi hatalarıydı; düzeltildi):**

1. **Pencere öne alınıyor.** `shot()` her karede `xdotool windowactivate --sync`
   (yoksa `wmctrl -a`) çalıştırır. xdotool/wmctrl yoksa betik **durur**
   (`SystemExit`) — sessizce yanlış kanıt üretmez.
2. **Her görüntü tekil (md5 kapısı).** Aynı md5 ikinci kez görülürse betik
   `AYNI GÖRÜNTÜ` hatasıyla çıkar. Bu turda ilk koşu tam olarak bunu yakaladı:
   `chrome-kehribar-light-1366x768.png == home-kehribar-light-1366x768.png`.
   Sebep: `WebDriver:TakeScreenshot` TÜM pencereyi veriyordu. Artık
   `chrome-*` üst şeride (sekme şeridi + adres çubuğu = 46 px),
   `home-*` o şeridin altındaki içerik alanına (697 px) kırpılıyor.
3. **Renk ayrıştırıcı düzeltildi.** Motor `oklch()` üretiyor; eski ayrıştırıcı
   yalnız `rgba()` okuyordu. Okunamayan renk "şeffaf" sayılıp zemin beyaza
   düşüyor, **sahte ihlal** üretiyordu (koyu temada `#date` 1,67:1 gibi).
   Renkler artık tuval üzerinde normalize edilip çözülüyor.
4. **Taban zemin artık beyaz değil**, pencerenin gerçek tuval rengi.
   (Eski hâlde koyu temada `.text-link` 3,77:1 "ihlal" görünüyordu.)
5. **HER öğe taranıyor.** Eskiden yalnız 7 seçicilik bir liste + metin
   düğümleri taranıyordu (bir yüzeyde 7 örnek). Şimdi yüzeydeki tüm görünür
   öğeler — `::before/::after` içeriği, `input/textarea` değerleri dahil.
   Bir yüzeyde örnek sayısı 7 → 66'ya çıktı.

**Gerçek (ürün) kusurları da bulundu ve düzeltildi:**

- Koyu temada `#PersonalToolbar` **beyaz** kalıyordu (`shell.css` yalnız
  `#navigator-toolbox`'ı boyuyordu) → yer imleri bağlantıları 3,77:1.
  Kabuk artık bu çubuğun zeminini de yönetiyor.
- Vurgu metni rengi sabit bir zemine göre hesaplanıyordu (`#ffffff` / `#2b2b30`);
  gerçek zemin `oklch(26%)` olunca `.an-palette-sub` 4,42:1 ve `#date` 4,12:1
  kalıyordu. `theme.js::accentText` artık **en kötü iki gerçek zeminin**
  ikisine de uyan tonu seçiyor.
- Koyu temada ikincil metin (`--an-muted`) seçili satır zemininde 4,42:1
  kalıyordu → `oklch(72%)` → `oklch(75%)`.

**Ölçülemeyen (piksel örneklemesi gerekir, renk hesabıyla ölçülemez):**
degrade metin (`background-clip:text`) **160 öğe**, degrade/foto zemin üzerinde
metin **144 öğe**. Bunlar "ihlal" sayılmadı, ayrı listelendi — raporda
"yapmadıklarım" bölümünde.

---


## A. Düzeltilen sorunlar (düşük riskli, uygulandı)

### A1 — Seçili segment yazısı okunmuyor · **yüksek** · `personalisation-*-light-*.png`, `library-*-light-*.png`
- Ölçüm: `.an-segment-item[aria-pressed="true"]` → Kehribar **1,40:1**,
  Turkuaz **1,24:1** (metin `#fbbf24` / `#5eead4`, zemin beyaz).
- Neden: seçim durumu metin rengiyle anlatılmış; açık temada vurgu rengi
  metin için fazla açık.
- Düzeltme: metin `var(--an-text)`, seçim `background` + `inset` çerçeve +
  `font-weight:700` ile anlatılıyor. Renk körlüğü için de daha güvenli.
- Sonuç: tüm yüzeylerde ≥ 4,68:1 (ölçüldü).

### A2 — Vurgu renginin metin olarak kullanıldığı yerler · **orta**
`home-*-light-*.png` (gün tarihi, sayaç çipleri, "ANATOLIA LABS · YAKINDA"),
`chrome-*` (özel pencere rozeti), `statusbar-*` (zoom düğmesi), `palette-*` (↵).
- Ölçüm: `.chip` **1,67:1**, `#date` **1,67:1**, `.mobile-kicker` **1,67:1**
  (Kehribar açık); Turkuaz açıkta **1,48:1**.
- Düzeltme: `AnatoliumTheme.accentText()` aynı tondan AA'yı tutturan bir
  "metin vurgusu" üretir (`--an-accent-strong`). Dolgular (düğme zemini,
  ilerleme çubuğu, rozet zemini) özgün vurgu renginde bırakıldı.
- Sonuç: başlangıç sayfası en kötü oran **5,16:1** (Kehribar) / **4,68:1** (Turkuaz).

### A3 — Düğme dolgusu üstündeki metin · **orta** · `personalisation-*-dark-*.png`
- Ölçüm: `.an-btn` "Bitti" → **1,39:1** (metin `#08131a`, zemin `#2e2e32`).
- Neden: `readableInk()` yalnızca parlaklık eşiğine (0,45) bakıyordu, AA'ya
  bakmıyordu; koyu temada düğme zemini accent yerine `--an-active` olunca
  metin zemine yaklaşıyordu.
- Düzeltme: `accentInk` artık gerçek kontrastı ölçüp 4,5:1'in altındaysa
  siyah/beyaz arasında doğru olanı seçer.

---

## B. Düzeltilmeyen, ölçülmüş konular (karar bekliyor)

| # | Konu | Önem | Kanıt / ölçüm | Seçenekler |
|---|---|---|---|---|
| B1 | Durum çubuğu zoom düğmeleri **18×18 px**, sekme kapatma **20×20 px** — 24 px eşiğinin altında | orta | `ui_audit` `smallTargets` (her kombinasyonda 2–5 öğe) | (a) düğme görseli aynı kalıp tıklama alanı `padding` ile 24 px'e çıkarılır (+2 px yükseklik), (b) dokunma/pointer hedefi `::after` ile büyütülür (görsel değişmez), (c) kabul edilir: fare ile 20 px hâlâ kullanılabilir |
| B2 | Marka yazısı `#an-brand-name` renkli gradyan + `background-clip:text` | düşük | hesaplanan `color` saydam → oran 1,55:1 görünüyor; gerçekte gradyan dolu | WCAG'de "logotype" istisnası; (a) olduğu gibi bırakılır, (b) düz metin rengine çevrilir (marka kimliği değişir) |
| B3 | Ölçüm aracı yanlış pozitifleri: `#personal-toolbar-empty-desc` (görünmez, motor şablonu), `.text-link` (görünmez CFR bildirimi) | — | ölçüm betiği artık `opacity/visibility` zincirini eliyor; kalan iki öğe de görünmez şablon | ölçüm betiğine "görünürlük" kapısı eklendi; rapora yanlış pozitif olarak yazıldı |
| B4 | Adres çubuğu bölgesindeki çapraz tarama (bkz. `chrome-*.png`) | — | **Ürünle ilgili değil:** aynı tarama el değmemiş motorda (`build-work/firefox`) da var; metin/düğme değil, sanat yapıtı (yer imi yer tutucusu). Ürünün hiçbir CSS'i bu bölgeye dokunmuyor. | yok — motorun kendi görseli |

---

## C. Klavye ve odak

- `Tab` ile odaklanabilir öğe sayısı yüzey başına 6–27 (ölçüldü).
- Odak halkası: `#an-header button`, `.an-tab`, `#an-drawer button`,
  `.an-segment-item` → `outline: 2px solid var(--an-accent)`, `outline-offset: 2px`
  (ölçüldü `visible:true`).
- **İstisna:** durum çubuğu zoom düğmeleri motordan miras `1px auto` çizgi
  kullanıyor (ürün CSS'i onlara odak kuralı yazmıyor) → B1 ile birlikte ele
  alınmalı.

## D. Taşma ve yerleşim

- 900×700'de tüm yüzeylerde `documentElement.scrollWidth - clientWidth = 0`
  (ölçüldü, 8 kombinasyonun tamamı). Tek satır/iki satır sekme düzeni ve
  dikey sekme kipi 4l testinde ayrıca ölçüldü (`rowOverflow` tüm satırlarda 0).

## E. Türkçe metin

- Panellerde, indirme satırlarında ve durum çubuğunda kısaltma/çeviri hatası
  görülmedi; indirme nedenleri sade Türkçe ("Sunucuya ulaşılamadı…",
  "Güvenlik denetimi bu dosyayı engelledi.").
- Tek not: motorun kendi arayüzünde (ayarlar sayfası) "Aynı ayarlar, yeni
  görünüm!" tanıtım kutusu ürün diline karışıyor — bu **motorun** metni,
  ürün katmanı onu yeniden yazmıyor (dokunulmaz).


---

## E. Bu turun sonuç tablosu (ölçüldü)

| Ön ayar / tema / boyut | Ölçülen öğe | İhlal | En düşük kontrast |
|---|---|---|---|
| Kehribar açık 1366×768 | 206 | 0 | 5,07:1 |
| Kehribar açık 900×700 | 214 | 0 | 5,07:1 |
| Kehribar koyu 1366×768 | 222 | 0 | 4,9:1 |
| Kehribar koyu 900×700 | 230 | 0 | 4,9:1 |
| Turkuaz açık 1366×768 | 238 | 0 | 5,07:1 |
| Turkuaz açık 900×700 | 246 | 0 | 5,07:1 |
| Turkuaz koyu 1366×768 | 254 | 0 | 4,79:1 |
| Turkuaz koyu 900×700 | 262 | 0 | 4,79:1 |
| **Toplam** | **1872** | **0** | **4,79:1** |

Eşikler: normal metin 4,5:1, büyük metin 3:1. Ekran görüntüsü: 56 PNG,
5 farklı piksel boyutu (`1364×46`, `1364×697`, `898×46`, `898×629`, tam kare);
`chrome-*` ile `home-*` hiçbir koşuda aynı değil (md5 kapısı).

## F. Yapmadıklarım (bu belgede ölçülmedi)

- Degrade metin ve degrade/foto zemin üzerindeki metnin kontrastı **piksel
  örneklemesiyle** ölçülmedi (160 + 144 öğe). Yöntem: ekran görüntüsünden
  metin piksellerini örnekleyip zemin tonuyla karşılaştırmak.
- Gerçek ekran okuyucu (NVDA/Orca) ile gezinme sınanmadı; yalnız odaklanabilir
  öğe sayısı ve 24 px hedef boyutu sayıldı.
- 900 px'in altındaki genişlikler (mobil) ölçülmedi.
