# Faz 3B — S1–S10 senaryo raporu

**Tarih:** 2026-11-14 · **Sürüm:** `0.4.1-5~faz3b` (faz 3b hattı) · **Paket:** 97.3 MB deb

## Bu raporda "sahte" olan ne?

- **Sahte Mozilla sunucusu:** `tests/stub_mozilla.py`, `http://127.0.0.1:8137`.
  Sürüm bilgisi (`firefox_versions.json`), `SHA512SUMS`, `SHA512SUMS.asc`, `KEY`
  ve tarball bu sunucudan geliyor. **Gerçek Mozilla sunucusuna hiçbir istek
  atılmadı** (indirme yalnız motor doğrulaması için bir kez yapıldı).
- **Test imza anahtarı:** `Anatolium Test Archive Signing Key (TEST-ONLY, faz3b)`,
  parmak izi `76113E91799C33229871AF52AF4F4CCCECCE5241`, imza alt anahtarı
  `2B44F227133705E37355415358DAA8A7166D4AC9`. Teslimden sonra **silinir**.
- **Sahte yeni sürüm:** `153.8.0esr` (gerçek Mozilla'da böyle bir sürüm yok;
  153.7.0esr ağacından üretildi, `BuildID=20261113120000`).

**Sahte olmayan:** karar mantığı (`packaging/version_policy.py`), imza/hash
doğrulama zinciri (`packaging/engine_fetch.py`), derleme (`packaging/build.py`,
`deb.py`), kapılar (`packaging/gates.py`), depo işlemleri (`packaging/repo.py`),
yükleme sırası (`packaging/deploy.py`), durum dosyası (`state/published.json`).
Yani **veri kaynağı sahte, kod üretimdeki kodun aynısı.**

Her senaryo için ham çıktı: `docs/FAZ3B-SENARYOLAR.json`.

---

## Özet tablo

| # | Senaryo | Beklenen | Sonuç | Karar / çıkış kodu |
|---|---|---|---|---|
| S1 | Yeni sürüm yok (153.8.0 sunuldu, stable'da 153.8.0) | hiçbir şey olmaz | **GEÇTİ** | `d / noop`, rc=0 |
| S2 | Aynı ana sürümde yeni sürüm | beta'da paket, stable'da YOK; terfi sonrası stable'da | **GEÇTİ** | `a / auto`, rc=0 → yayın beta |
| S3 | Farklı ana sürüm (154.0) | DUR + bildirim | **GEÇTİ** | `b / stop_major`, rc=10 |
| S4 | `SHA512SUMS` imzası bozuk | DUR | **GEÇTİ** | doğrulama hatası, rc=11 |
| S5 | Tarball hash uyuşmuyor | DUR | **GEÇTİ** | "özet UYUŞMUYOR", rc=11 |
| S6 | Kapı testi bozuk (kilitli pref ters) | yayın YOK | **GEÇTİ** | kapı rc=12, `lock_defaults` KALDI |
| S7 | Mevcut sürümden düşük sürüm (153.6.0) | RED | **GEÇTİ** | `c / reject`, rc=10 |
| S8 | `apply_frontend` yama hedefi yok | DUR | **GEÇTİ** | derleme rc=1, yayın yok |
| S9 | Yeni alan adı görülürse | DUR (insan onayı) | **GEÇTİ** (sabit örnek) | `new_hosts` dolu → pass=False |
| S10 | Yükleme yarıda kesilir | istemci bozulmaz | **GEÇTİ** | deploy rc=3, `InRelease` yüklenmedi |

---

## S1 — Yeni sürüm yok

```bash
python3 packaging/pipeline.py check \
  --product-details http://127.0.0.1:8137/1.0/firefox_versions.json
```

Günlük (gerçek çıktı):

```
sunulan: 153.8.0esr | stable'da: 153.8.0esr → d / noop
gerekçe: Sunulan sürüm yayınlanmış sürümle aynı (153.8.0esr); yapılacak iş yok.
```

Karar: **hiçbir şey yapılmaz** (ne derleme, ne yayın, ne bildirim). rc=0.

## S2 — Aynı ana sürümde yeni sürüm (tam hat)

```bash
python3 packaging/pipeline.py run \
  --product-details http://127.0.0.1:8137/1.0/firefox_versions.json \
  --release-base http://127.0.0.1:8137/releases/153.8.0esr \
  --key-url http://127.0.0.1:8137/KEY \
  --pin 2B44F227133705E37355415358DAA8A7166D4AC9 \
  --primary-pin 76113E91799C33229871AF52AF4F4CCCECCE5241 \
  --allow-test-key --gates smoke,lock_defaults,lintian
```

Süre: **418 saniye**. Hattın yaptıkları (günlük):

```
=== 1) SÜRÜM İZLEME ===   → a / auto
=== 2) DOĞRULAMA ZİNCİRİ ===   doğrulandı: 153.8.0esr → sha512 e9aaa99fea39d9fe…
                               (imzalayan 2B44F227133705E37355415358DAA8A7166D4AC9)
=== 3) ÜRETİM ===          DEB + RPM derlendi (motor 153.8.0esr)
=== 4) KAPILAR ===         smoke 45/45, lock_defaults 48/48 (varsayılanlar 69/69),
                           lintian E=25 (kısmi çıktı; tam ölçüm sonrası E=77 = temel)
=== 5) YAYIN (beta) ===    beta: 1 paket, by-hash kopyası 3, imzalandı
                           yayınlandı → beta: 0.4.1-5~faz3b
TAMAM: 0.4.1-5~faz3b beta kanalında. stable'a terfi İNSAN ONAYI bekliyor.
```

Durum dosyası bu noktada: `beta.engine = 153.8.0esr`, **`stable` boş** → istenen
davranış: *beta'ya gider, stable'a gitmez.*

Terfi (elle, onay bayrağıyla):

```bash
python3 packaging/pipeline.py promote --allow-test-key --confirm --by "faz3b senaryo"
# → terfi beta → stable: anatolium=0.4.1-5~faz3b
# → stable: 1 paket, by-hash kopyası 3, imzalandı
```

Terfi sonrası `dists/stable/main/binary-amd64/Packages` içinde **1 paket** var
(`grep -c '^Package:'` → 1) ve bu paket `0.4.1-5~faz3b`.

## S3 — Farklı ana sürüm

```
sunulan: 154.0esr | stable'da: 153.8.0esr → b / stop_major
gerekçe: Ana sürüm değişiyor (153 → 154). Yeni ESR dalı: arayüz yamaları
(apply_frontend.py) bozulabilir. Otomatik yayın YOK; insan incelemesi gerekiyor.
```

rc=**10** (dur), bildirim gönderilir (`minor`/`major-stop` konusu). Otomatik
yayın yok.

## S4 — Bozuk imza

Sunucu, imzayı imzalandıktan **sonra** bozar (`tamper=asc`), yani özet listesi
"doğru" görünür ama imza tutmaz.

```
rc=11
hata: [GNUPG:] FAILURE gpg-exit 33554433
      gpg: [don't know]: invalid packet (ctb=34)
DUR: SHA512SUMS imzası DOĞRULANAMADI (gpg: geçerli imza yok).
```

Karar: **DUR**, tarball hiç indirilmez.

## S5 — Hash uyuşmazlığı

İmza **geçerli**, ama tarball'ın son baytı bozulmuş (sunucu bozar). Zincir
imzayı geçer, hash kontrolünde durur:

```
rc=11
  beklenen: e9aaa99fea39d9fe93130a0e793fde5a82e96eed32b8396aaf6e4865d881057065458d5823a17e5efa9751c02ed27c43b6f10449eca990c9816ec87f892dd04f
  ölçülen:  59c188a5729308ef897b7ffa4d138f8aed57ab02bcc462e5895bacad70af09b142f3dea341c1419cb870492b15c599ff0ade6ee96d1e7c614434ff89a67aee7a
```

Not: bu senaryo ilk koşuda **yanlış sonuç** verdi çünkü tarball önbellekte
duruyordu; senaryo artık kendi önbellek dizinini kullanıyor
(`ANATOLIUM_CACHE`). Bu düzeltme senaryo kodunda, ürün kodunda değil.

## S6 — Kapı testi bozuk

`/var/tmp/rt-broken` = kasıtlı bozulmuş kurulum (kilitli pref değeri ters).

```bash
python3 packaging/pipeline.py gates --runtime /var/tmp/rt-broken \
  --deb /var/tmp/dist3b/anatolium_0.4.1-0.5~faz3b_amd64.deb --gates lock_defaults
# [kapı] lock_defaults: KALDI — 40/48 pref doğru; varsayılanlar: 59/69 eşleşti
# KAPI SONUCU: KALDI — lock_defaults      rc=12
```

Karar: **yayın yok** (hat `KAPILAR GEÇMEDİ — YAYIN YOK` yazar ve rc=12 döner).

## S7 — Düşük sürüm

```
sunulan: 153.6.0esr | stable'da: 153.8.0esr → c / reject
gerekçe: Sunulan sürüm (153.6.0esr) yayınlanmış sürümden (153.8.0esr) DÜŞÜK.
Geri alma (rollback) saldırısı olabilir; reddedildi.
```

rc=10. Bu, "sürüm düşürme saldırısı"na karşı korumadır: imza geçerli olsa bile
eski sürüm yayınlanmaz.

## S8 — Yama hedefi yok

`ANATOLIUM_BREAK_PATCH=1` ile `apply_frontend.py` var olmayan bir yama noktası
arar:

```bash
ANATOLIUM_BREAK_PATCH=1 python3 packaging/build.py --target deb
# + tar -xJf …   → motor açıldı
# + apply_frontend.py … → rc=1
# Derleme DURDU
```

Karar: **sessizce devam etmez**, derleme durur → yayın yok. Bu, yeni ESR
sürümünde arayüz yamalarının kayması durumunda ürünü korur (S3 ile birlikte
çalışır: ana sürüm değişiminde insan incelemesi istenir).

## S9 — Yeni alan adı

**Bu senaryoda sınanan şey kapının karar mantığıdır, gerçek bir sızıntı değil.**
Ağ denetimi ayrıca bir kez gerçekten koşturuldu (90 saniyelik açılış, 8 alan adı:
`aus5.mozilla.org`, `ciscobinary.openh264.org`, `content-signature-2.cdn.mozilla.net`,
`firefox-settings-attachments.cdn.mozilla.net`, `firefox.settings.services.mozilla.com`,
`safebrowsing.googleapis.com`, `services.addons.mozilla.org`, `update.googleapis.com`);
temel liste `packaging/network-baseline.json`, ham kayıt `docs/network-audit-faz3b.json`.
Bu koşuda dışarıya **veri yüklenmedi**, yalnız Mozilla/Google uç noktalarına
bağlantı denemesi oldu. S9'un kendisi ise şu sabit örnekle sınandı:

```json
{"hosts": ["yeni.ornek-alan.test", "aus5.mozilla.org"],
 "new_hosts": ["yeni.ornek-alan.test"], "pass": false}
```

Kapı, temel listede (`packaging/network-baseline.json`) olmayan bir alan adı
görürse `pass=False` → yayın durur ve insan onayı istenir. Kapının kendisi
`packaging/gates.py` içinde `gate_network_diff`. **SAHTE VERİ** ile sınandı.

## S10 — Yükleme yarıda kesilir

```bash
python3 packaging/deploy.py --repo repo --target local-dir --dest /var/tmp/yayin-yarim \
  --interrupt-after 2
# rc=3 (yarım yükleme)
# yüklenen: pool/ içinde 1 paket; InRelease: 0 dosya
```

Karar: sıra **havuz → by-hash → Packages/Release → EN SON InRelease** olduğu
için yarıda kalan depoda imza dosyası yoktur; istemci `apt update` yaptığında
ya eski indeksi görür ya hiç görmez, **bozuk bir duruma düşmez**. Yeniden
çalıştırmak güvenlidir.

---

## Senaryo koşularının sınırları

1. **S9** gerçek bir yeni alan adı sızıntısı değil, karar mantığı sınamasıdır
   (temel liste gerçek ölçümden geliyor: `packaging/network-baseline.json`).
2. **S2** kapı setinden `session_restore`, `codec`, `upgrade`, `network_diff`
   muaf tutuldu (`--allow-unverified`), çünkü bunlar tam koşuda saatler alıyor.
   Bunlar ayrı ayrı elle ölçüldü (bkz. `FAZ3B-RAPORU.md`, Bölüm D).
3. Tüm senaryolar **tek makinede, tek kullanıcıyla, yerel** çalıştı. GitHub
   Actions üzerinde koşulmadı (`gh` yok, depo bağlantısı yok).
4. Senaryolar arasında durum dosyası (`state/published.json`) **gerçek** akıştaki
   gibi kullanıldı; S2'den sonra S1/S3/S7 "yayınlanmış sürüm var" varsayımıyla
   koştu. Senaryoların bu sıraya bağımlılığı raporun sonunda yazılı.
5. S4/S5'te bozma **sunucu tarafında** yapıldı; ürün kodu bozulmadı.
