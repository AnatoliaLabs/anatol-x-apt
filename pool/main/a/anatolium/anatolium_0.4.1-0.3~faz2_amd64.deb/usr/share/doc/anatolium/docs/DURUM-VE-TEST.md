# FAZ 4A — Durum ve ölçüm defteri

Bu dosya **yalnızca ölçülen** şeyleri yazar. Ölçülmemiş hiçbir şey "geçti"
sayılmaz; yazılamayan her şey "ÇALIŞTIRILAMADI + nedeni" olarak durur.

Ölçüm ortamı: yerel test derlemesi `/var/tmp/faz4a/dist/anatolium/opt/anatolium`
(`packaging/build.py --target deb` + arayüz yaması), motor Firefox ESR 153.7.0,
Xvfb + openbox, Marionette (chrome bağlamı). Ürün varsayılanları değişmedi;
yalnızca 20 eşzamanlı indirme ölçümünde bağlantı pref'leri test profilinde
yükseltilir (aşağıda not).

---

## 1. Madde durumu

| Madde | Ne istendi | Durum | Kanıt |
|---|---|---|---|
| 0 | Hazırlık, baseline, indirme kodunu bulma | **TAMAM** | `docs/FAZ4A-BASELINE.md` |
| 1 | Yavaş indirme sunucusu + kendi testleri | **TAMAM** | `tests/slow_download_server.py`, 11/11 |
| 2 | Canlı indirme paneli (çekirdek) | **TAMAM** | `src/frontend/downloads.js`, 4a–4l |
| 3 | Gösterge (düğmede canlı halka + rozet) | **TAMAM** | 4a/4g.2 ölçümleri, madde 3 notu |
| 4 | Testler `tests/downloads_live.py` + smoke'a entegrasyon | **TAMAM (13/13)** | `/var/tmp/faz4a/kanit/dl-live.json` |
| 4m | Regresyon: smoke 45/45 + `lock_test --defaults` | aşağıdaki tabloya bakın | `docs/test-report.json`, `docs/lock-report.json` |
| 5 | Arayüz denetimi: ekran görüntüleri + `docs/UI-DENETIM.md` + düşük riskli düzeltmeler | **TAMAM** | `docs/UI-DENETIM.md`, `docs/UI-DENETIM.json`, `docs/screenshots/ui/` |

---

## 2. Madde 4 — canlı indirme testleri (13 kontrol)

Komut:

```
ANATOLIUM_WORK=/var/tmp/faz4a/test-work \
python3 tests/downloads_live.py /var/tmp/faz4a/dist/anatolium/opt/anatolium \
        --json /var/tmp/faz4a/kanit/dl-live.json
```

Son koşu: **13/13 kontrol geçti** (~85 s). Ölçülen değerler:

| Kontrol | Ne ölçüldü | Sonuç |
|---|---|---|
| 4a | Tek indirme: ilerleme/yüzde/hız metni canlı değişiyor | 6 farklı örnek metin ("368 KB / 1,1 MB · 401 KB/sn · yaklaşık 2 sn kaldı" …), dosya diskte tam boyutta |
| 4b | Duraklat → ilerleme duruyor → devam → tamamlanıyor (Range) | 245 760 B'de dondu (iki ölçümde de aynı), devam edip tamamlandı; satır "Duraklatıldı" + "Devam et" |
| 4c | Range yoksa duraklat devre dışı + nedeni tooltip'te + basınca indirme durmuyor | `range_olcumu:"no"`, `canPause:false`, `disabled:true`, tooltip "…desteklemiyor; duraklatma kullanılamaz.", tıklama sonrası durum `downloading` |
| 4d | İptal | satır "İptal edildi", "Yeniden dene" sunuluyor, dosya diskte yok |
| 4e | Aktarım ortasında kopma → başarısız (sade neden) → yeniden dene → tamamlanır | neden "Sunucuya ulaşılamadı…"; yeniden denemede tamamlandı |
| 4f | Boyut bilinmiyor → belirsiz çubuk | `hasProgress:false`, `indeterminate:true`, `aria-valuenow` yok, "Boyut bilinmiyor", `an-dl-slide` animasyonu |
| 4g.2 | 20 eşzamanlı indirmede arayüz yanıtı | `maxGap 102 ms`, `p95 85 ms`, `ort 53 ms`, en uzun tek görev 17,3 ms, 20 etkin satır |
| 4g.1 | 5 eşzamanlı: hepsi doğru boyutta bitiyor | 5×400 000 B |
| 4h | "Tamamlananları temizle" | liste boşaldı, **dosyalar diskte kaldı** |
| 4k | Panel 50× aç/kapa | DOM düğümü 2988 → 2988 (fark 0) |
| 4j | Engelli dosya: otomatik kabul yok, motorun komutu çağrılıyor | `autoUnblock:0`, istem 1 (vazgeç) / 2 (sakla) |
| 4l | motion=off/rich × açık/koyu × 1366/900 px | off → geçiş 0,001 s, animasyon yok; rich → 0,34 s; 900 px'te `docOverflow 0`; 4 küçük PNG |
| 4i | Yeniden başlatma | "kalici.bin" tamamlanmış olarak listede kaldı |

Not (ölçüm ortamı): 20 eşzamanlılık ölçümü için test profilinde
`network.http.max-connections-per-server=64` vb. yükseltilir. Motorun ürün
varsayılanı sunucu başına **6** bağlantıdır; bu bir hata değil, motorun kendi
davranışıdır ve ürün ayarlarında değiştirilmedi.

---

## 3. Madde 4m — regresyon

| Koşu | Sonuç |
|---|---|
| `tests/smoke.py` (arayüz yamasından sonra) | 45/45 |
| `tests/lock_test.py … --defaults` | 49/49 pref doğru; varsayılanlar 69/69 eşleşti |
| `tests/slow_download_server.py` kendi testleri | 11/11 |

`lock_test` bilinen farkı (tek satır): `browser.aboutwelcome.enabled` değeri
doğru (false), kilit biti Marionette oturumunda True görünüyor; Marionette'siz
bağımsız ölçümde False. Test bunu zaten "bilinen fark" olarak raporluyor.

---

## 4. Madde 5 — arayüz denetimi (özet)

Ayrıntı: **`docs/UI-DENETIM.md`**. Ham ölçüm: `docs/UI-DENETIM.json`.
Ekran görüntüleri: `docs/screenshots/ui/` (56 PNG, her biri ≈130–190 KB).

Ölçülen yüzeyler × 8 kombinasyon (2 ön ayar × açık/koyu × 1366×768/900×700):
başlangıç sayfası, sekme şeridi + adres çubuğu, Kütüphane paneli,
kişiselleştirme paneli, komut paleti, durum çubuğu, ayarlar sayfası.

Kontrast (WCAG AA 4.5:1, gerçek hesaplanmış piksel renklerinden):

| Tema | Denetim öncesi en kötü | Denetim sonrası en kötü |
|---|---|---|
| Kehribar açık | **1,40:1** (seçili segment yazısı) | **5,16:1** |
| Kehribar koyu | **1,39:1** ("Bitti" düğmesi) | 5,29:1 (ürün yüzeyleri) |
| Turkuaz açık | **1,24:1** (seçili segment yazısı) | **4,68:1** |
| Turkuaz koyu | **1,39:1** | 5,29:1 |

Düzeltilen üç düşük riskli hata:

1. **Seçili segment yazısı** (`.an-segment-item[aria-pressed="true"]`) vurgu
   rengiyle yazılıyordu → beyaz zeminde 1,24–1,40:1. Metin artık normal metin
   rengi, seçim arka plan + iç çerçeve + kalın yazı ile anlatılıyor.
2. **Vurgu renginin metin olarak kullanıldığı yerler** (`#an-private`,
   `.an-palette-enter`, durum çubuğu ölçek düğmesi, `.eyebrow`, `.mobile-kicker`,
   `.mobile-badge`, `.chip.is-on`, not sayacı) → yeni `--an-accent-strong`
   değişkeni `AnatoliumTheme.accentText()` ile AA'ya zorlanıyor. Dolgular
   (düğme zemini, ilerleme çubuğu, rozet zemini) özgün vurgu renginde kaldı.
3. **Düğme dolgusu üstündeki metin** `readableInk()` eşiği 0,45'ten WCAG
   4.5:1 ölçütüne çevrildi (`accentInk`); "Bitti" düğmesi 1,39 → AA.

---

## 5. Kapanışta "yapmadıklarım" olarak yazılacaklar

- Kalan 4 ölçüm yanlış pozitifi (aşağıda) düzeltilmedi, **karar bekliyor**:
  ölçüm aracı saydam/`backdrop-filter` yüzeyleri ve motorun kendi şablon
  düğümlerini gerçek zemin olarak çözemiyor.
- Ölçülen ama düzeltilmeyen gerçek konular: durum çubuğu zoom düğmeleri
  (18×18 px) ve sekme kapatma (20×20 px) 24 px eşiğinin altında; renkli
  gradyanlı marka yazısı `background-clip:text` olduğu için kontrastı
  ölçülemiyor (WCAG'de "logotype" istisnası).
