# Anatolium 0.4.1 — FAZ 1b RAPORU

Tarih: 2026-11-14 · Çalışma kopyası: `anatolium-0.4.1-faz1/` · Sürüm: **0.4.1**
(değişmedi) · Paket: **`Anatolium-0.4.1-faz1b-kaynak.zip`** (içindeki klasör
`anatolium-0.4.1-faz1b/`; faz 2 bunun üzerinden başlar).

Ölçüm ortamı: Mozilla Firefox ESR **153.6.0esr** (değiştirilmemiş ikili),
Linux konteyner, **Xvfb 1366x768x24 + openbox**, Marionette, her test için
geçici ve izole profil. Gerçek kullanıcı profiline dokunulmadı; imza anahtarı
ve parola istenmedi/kullanılmadı.

---

## A. Özet

Faz 1'den devredilen **4 düşen smoke kontrolü** kapatıldı; hepsinin kök nedeni
ölçümle bulundu ve sınıflandırıldı. Sonuç: **45/45**.

- **İki kontrol gerçek eksikti:** `an-status` durum çubuğu kodda hiç yoktu
  (`buildStatus()` hiç yazılmamış, `shell.js` var olmayan `this.statusTabs`'a
  yazıyordu). Durum çubuğu yazıldı, tek satır düzende gizleniyor.
- **İki kontrol geçersiz testti:** biri üründen bilerek kaldırılan "Son
  kapatılanlar" panelini arıyordu, diğeri tarih aralığı test verisini saat
  12:00'den önce "gelecek tarih" olarak yazıp Places tarafından reddediliyordu
  (o yüzden hiç ziyaret oluşmuyordu). İkisi de gerçek kullanıcı davranışını
  ölçecek şekilde yeniden yazıldı; **üretim kodundaki sınır koruması doğru
  çıktı**, değiştirilmedi.

Ayrıca **gerçek bir güvenlik hatası** bulundu ve düzeltildi:
`browser.safebrowsing.malware.enabled` **`false` kilitliydi** (zararlı yazılım
koruması kullanıcıya kapalı geliyordu). Artık `malware` ve `phishing` ikisi de
`true` ve kilitli; 37 kilitli pref canlı tarayıcıdan okunarak doğrulandı.

Gizlilik metni yerel destek sayfasına eklendi; bağlantı hedefleri canlı
tarayıcıda ölçüldü. Yeni `tests/lock_test.py` her ESR güncellemesinden sonra
çalıştırılabilir.

| Test | Sonuç |
|---|---|
| `tests/smoke.py` | **45/45** |
| `tests/lock_test.py` (yeni) | **37/37** |
| `tests/launcher.py` | **2/2** |
| `tests/restart_persistence.py` | **2/2** |
| `tests/session_restore_integration.py` | **2/2** |

---

## B. Görev görev: ne değişti, kanıtı ne

### 1) Düşen 4 smoke kontrolü

**1.1 "Single-row chrome (tabs + address bar)" — sınıf (c) gerçek eksik**

- Kanıt (ölçüm): test `getComputedStyle(document.getElementById('an-status'))`
  okuyordu; tarayıcıda `an-status` düğümü **yok**, test `TypeError` ile
  düşüyordu. `shell.js` içindeki `updateLayout()` var olmayan `this.statusTabs`
  alanına yazıyordu; `buildStatus()` fonksiyonu hiç yazılmamıştı.
- Yerleşim ölçümleri zaten doğruydu: `headerHeight=46`, `navParent=an-nav-host`,
  `navTop=3`, `tabsTop=0`, `tabsWidth=624`.
- Düzeltme: `shell.js` içine durum çubuğu eklendi (bağlantı hedefi solda;
  yakınlaştırma, sekme sayısı, motor sürümü sağda). `shell.css`'e 24 px'lik alt
  şerit; `:root[anatolium-single] #an-status { display:none }`; tam ekran ve
  özelleştirme modunda gizleme (mevcut kural zaten vardı).
- Kanıt (yeni ölçüm): `status:"none"` tek satırda, `status:"flex"` iki satırda.
  Durum çubuğu yüksekliği 24 px, `tabboxBottom` 749 → 725 (sayfa alanı
  gerçekten küçülüyor, üstüne binmiyor). Bağlantı üzerine gelindiğinde
  `an-status-text` "https://example.com/ornek-baglanti" gösteriyor; yakınlaştırma
  düğmeleri `%100 → %110` çalışıyor.
- Not: Firefox'un kendi `#statuspanel` paneli yalnızca kendi kancamız başarıyla
  kurulduysa gizleniyor (`:root[anatolium-statusbar="true"]`), böylece bir
  hâdise kullanıcıyı durum göstergesiz bırakmıyor.

**1.2 "Narrow window falls back to two rows" — sınıf (c) gerçek eksik**

- Aynı eksik öğe (`narrow.status != "none"` koşulu). 1.1 düzeltmesiyle geçti:
  `narrow: {single:false, navParent:"navigator-toolbox", status:"flex"}`,
  `wide: {single:true, navParent:"an-nav-host"}`.

**1.3 "Recently closed tab restore" — sınıf (b) geçersiz test**

- Kanıt: test `AnatoliumShell.toggleDrawer('closed')` çağırıp
  `#an-drawer-list .an-row` arıyordu. Üründe `closed` diye bir panel **yok**;
  "Son kapatılanlar" bölümü `README.md` ve `docs/GELISTIRME-PLANI.md`'de
  **bilerek kaldırılmış** olarak yazılı. Hata birebir:
  `TypeError: can't access property "click", document.querySelector(...) is null`.
- İkinci kök neden: test, kapatılan sekmeyi Anatolium başlangıç sekmesiyle
  açıyordu. Firefox **hiç gezilmemiş/boş sekmeyi** geri açılabilir listesine
  yazmaz (ölçüm: `SessionStore.getClosedTabCount(window) == 0`), bu yüzden geri
  açma hiçbir zaman mümkün olmuyordu.
- Düzeltme: test gerçek kullanıcı yoluna çevrildi — sekme şeridi sağ tık menüsü
  → **"Kapatılan sekme geri aç"**; kapatılan sekme önce yerel bir sayfaya
  (`http://127.0.0.1:8765/page`, test sunucusu) götürülüyor.
- Kanıt: `before:5 → opened:6 → afterClose:5`, `closedInSessionStore:1`,
  menü satırı bulundu, geri açıldı: `restoredTabs:6`, `restoredUrlBack:true`.
- Yan bulgu (küçük temizlik): `toggleDrawer()` içinde ölü `kind !== "closed"`
  koşulu vardı, kaldırıldı.

**1.4 "History interval protects boundary and bookmarks" — sınıf (b) geçersiz test**

- Kanıt (adım adım ölçüm, tahmin değil): test verisi üç ziyaret yazıyordu:
  `bugün-1ms`, `bugün 00:00` ve **`bugün 12:00`**. Tur saat **07:15** iken
  12:00 gelecekte kalıyor; `PlacesUtils.history.insert` bu durumda **tüm diziyi**
  reddediyor ve hata veriyor:
  `Error: PageInfo: Invalid value for property 'visits': [...]`.
  Sonuç: hiç ziyaret oluşmuyor, sonraki bütün kontroller boş veriyle düşüyordu.
- Düzeltme: üçüncü ziyaret "bugün içinde **ve** geçmişte" olacak şekilde
  hesaplanıyor: `max(bugün+1ms, şimdi-1sa)`. Üretim kodu değişmedi.
- Kanıt (düzeltilmiş veriyle adım adım): 3 ziyaret yazıldı (`before=3`), alt
  milisaniye çakışması kuruldu, `clearVisitInterval(dün, bugün)` **"Ambiguous
  boundary visit"** ile reddetti ve ziyaretlerin hiçbiri silinmedi
  (`keptOnRefusal=true`), çakışma çözülünce yalnızca dünün ziyareti silindi
  (`after=1`, kalan ziyaret bugünkü ziyaret), yer imi korundu
  (`bookmarkSurvives=true`), `historyLocalRange('today'/'week')` doğru.
- Yani **veri silme güvenliği gerçekten çalışıyor**; hata testteydi.

### 2) Belge gerçeği

- `docs/DURUM-VE-TEST.md`: test bölümü yeniden yazıldı — ölçüm tarihi/ortamı
  yazıldı, tablo gerçek sonuçlarla (45/45 · 37/37 · 2/2 · 2/2 · 2/2) güncellendi,
  faz 1'in 41/45'i tarihsel kayıt olarak korundu, düşen 4 kontrol için
  kök neden + sınıf tablosu eklendi.
- Faz 1 metinlerindeki **"RPM imzası doğrulandı"** ifadesi yanlıştı; "özet
  değerleri tutarlı, **imza yok**" olarak düzeltildi.
- **ÇALIŞTIRILAMADI tablosu** eklendi: minidump/çökme kaydı, `.deb`, imzalı
  kurulum, gerçek Fedora cihazında kurulum, 120 sn ağ trafiği denetiminin
  yeniden koşulmaması, `www.google.com` kaynağı.
- `docs/GELISTIRME-PLANI.md`: "45/45" ifadesi faz 1 turunda **yanlıştı** (o tur
  41/45); düzeltme notu ve güncel ölçüm eklendi.
- `docs/FAZ1-RAPORU.md`: tarihsel kayıt olduğu belirtildi, güncel sonuç için
  işaretçi eklendi.
- `README.md`: gizlilik bölümünün yeri ve `lock_test.py` kullanımı eklendi.
- `docs/test-report.json` ve `docs/restart-persistence-report.json` bu turda
  yeniden üretildi; sayılar yeni ölçümle aynı (45/45, 2/2). Ham çıktılar:
  `docs/smoke-output-faz1b.txt`, `docs/lock-output-faz1b.txt`.

### 3) Güvenli Gezinme kilidi

**Bulunan hata:** `browser.safebrowsing.malware.enabled` hem `anatolium.cfg`
hem `policies.json` içinde **`false`** kilitliydi; `phishing` hiç kilitli
değildi. Yani zararlı yazılım koruması kullanıcıya kapalı geliyordu.

**Düzeltme:** ikisi de `true` + `locked`. Canlı tarayıcıdan `Services.prefs`
okundu (`tests/lock_test.py`, 37/37): `malware=true`, `phishing=true`, ikisi de
kilitli, motor varsayılanı zaten `true`.

**Kilitli pref tablosu** (değerler çalışan tarayıcıdan; "motor varsayılanı"
sütunu **temiz, yapılandırılmamış** ESR 153.6.0 kurulumundan ayrıca okundu):

| Pref | Kilitli değer | Motor varsayılanı | Kilitli mi? |
|---|---|---|---|
| `app.feedback.baseURL` | chrome://browser/content/anatolium/support.xhtml# | https://ideas.mozilla.org/ | evet |
| `app.normandy.enabled` | false | true | evet |
| `app.releaseNotesURL` | chrome://browser/content/anatolium/support.xhtml# | https://www.firefox.com/%LOCALE%/firefox/%VERSION%/releasen… | evet |
| `app.releaseNotesURL.aboutDialog` | chrome://browser/content/anatolium/support.xhtml# | https://www.firefox.com/%LOCALE%/firefox/%VERSION%/releasen… | evet |
| `app.releaseNotesURL.prompt` | chrome://browser/content/anatolium/support.xhtml# | https://www.firefox.com/%LOCALE%/firefox/%VERSION%/releasen… | evet |
| `app.shield.optoutstudies.enabled` | false | true | evet |
| `app.support.baseURL` | chrome://browser/content/anatolium/support.xhtml# | https://support.mozilla.org/1/firefox/%VERSION%/%OS%/%LOCALE%/ | evet |
| `app.support.vendor` | Anatolia Labs | (yok) | evet |
| `app.update.auto` | false | true | evet |
| `app.update.enabled` | false | (yok) | evet |
| `app.update.url.details` | chrome://browser/content/anatolium/support.xhtml#guncelleme | https://www.mozilla.org/%LOCALE%/firefox/organizations/notes | evet |
| `app.update.url.manual` | chrome://browser/content/anatolium/support.xhtml#guncelleme | https://www.mozilla.org/%LOCALE%/firefox/enterprise?reason=… | evet |
| `breakpad.reportURL` | (boş) | https://crash-stats.mozilla.org/report/index/ | evet |
| `browser.crashReports.unsubmittedCheck.autoSubmit2` | false | false | evet |
| `browser.crashReports.unsubmittedCheck.enabled` | false | false | evet |
| `browser.discovery.enabled` | false | true | evet |
| `browser.newtabpage.activity-stream.feeds.section.topstories` | false | true | evet |
| `browser.newtabpage.activity-stream.feeds.system.topstories` | false | false | evet |
| `browser.newtabpage.activity-stream.showSponsored` | false | true | evet |
| `browser.newtabpage.activity-stream.showSponsoredTopSites` | false | true | evet |
| `browser.region.network.url` | (boş) | https://location.services.mozilla.com/v1/country?key=%MOZIL… | evet |
| `browser.region.update.enabled` | false | true | evet |
| `browser.safebrowsing.malware.enabled` | true | true | evet |
| `browser.safebrowsing.phishing.enabled` | true | true | evet |
| `browser.shell.checkDefaultBrowser` | false | true | evet |
| `browser.tabs.crashReporting.sendReport` | false | true | evet |
| `browser.uitour.enabled` | false | true | evet |
| `datareporting.policy.dataSubmissionEnabled` | false | true | evet |
| `datareporting.policy.firstRunURL` | (boş) | https://www.mozilla.org/privacy/firefox/ | evet |
| `dom.push.enabled` | false | true | evet |
| `extensions.pocket.enabled` | false | (yok) | evet |
| `network.captive-portal-service.enabled` | false | true | evet |
| `network.connectivity-service.enabled` | false | true | evet |
| `startup.homepage_override_url` | (boş) | (tanımsız) | evet |
| `startup.homepage_welcome_url` | (boş) | about:welcome | evet |
| `startup.homepage_welcome_url.additional` | (boş) | (tanımsız) | evet |
| `toolkit.telemetry.unified` | false | true | evet |


Tam makine okunabilir kayıt: `docs/lock-report.json` (her satırda
`locked`, `actual`, `engine_default`, `pass`).

### 4) Gizlilik metni

`src/frontend/support.xhtml` içine **"Ağ bağlantıları ve gizlilik"** bölümü
eklendi (11 madde). Ölçülmüş gerçeklere dayanıyor, abartı yok:

- **Kapalı:** telemetri, deneyler, Pocket/sponsorlu içerik, konum tahmini, push,
  çökme bildirimi, captive portal yoklaması. Captive portal için dürüst sonuç
  da yazıldı ("halka açık ağlarda giriş sayfasını kendiniz açmanız gerekebilir").
- **Bilerek açık** (adres + ne sağladığı): Güvenli Gezinme →
  `safebrowsing.googleapis.com` (Google); Remote Settings →
  `firefox.settings.services.mozilla.com`, `firefox-settings-attachments.cdn.mozilla.net`,
  `content-signature-2.cdn.mozilla.net`; uzantı mağazası/güncellemeleri →
  `services.addons.mozilla.org`; OpenH264/Widevine → `aus5.mozilla.org`,
  `update.googleapis.com`, `edgedl.me.gvt1.com`, `ciscobinary.openh264.org`.
- **Firefox Hesabı** ayrı not olarak eklendi: "Giriş yap"/"Başka bir cihaz bağla"
  düğmeleri `accounts.firefox.com` adresine gider, basılmadıkça bağlantı yok.
  (Bu iki adres `about:preferences` canlı taramasında görüldü.)
- **`www.google.com` notu kullanıcı sayfasına yazılmadı**; `docs/DURUM-VE-TEST.md`
  içindeki *Açık sorular → Geliştirici notu* bölümünde duruyor.

Sayfa ayrıca "Sık istenen konular" bölümü kazandı: motorun bağlantı verdiği
çapa adresleri (`#server-not-found-connection-problem`,
`#managed-browser-firefox`, `#profile-management`, `#firefox-backup`) artık
gerçek başlıklar; `#guncelleme` ve `#ag-baglantilari` de var. Ölçüm: altı çapa
da `document.getElementById` ile bulundu.

### 5) Küçük boşluklar

**5.1 "Daha fazla bilgi" bağlantıları nereye gidiyor (canlı ölçüm):**

| Nerede | Bağlantı metni | Gittiği adres |
|---|---|---|
| Ağ hatası sayfası (`about:neterror`, `dnsNotFound`) | "Daha fazla bilgi al…" | `chrome://browser/content/anatolium/support.xhtml#server-not-found-connection-problem` — **yerel**, Mozilla'ya gitmiyor |
| `about:preferences` — yönetilen tarayıcı bildirimi | "Daha fazla bilgi al" | `…/support.xhtml#managed-browser-firefox` (yerel) |
| `about:preferences` — profiller | "Daha fazla bilgi al" | `…/support.xhtml#profile-management` (yerel) |
| `about:preferences` — yedekleme | "Daha fazla bilgi alın", "Neler yedeklenecek?" | `…/support.xhtml#firefox-backup` (yerel) |
| `about:preferences` — hesap | "Hesabı yönet" / "Başka bir cihaz bağla" | `https://accounts.firefox.com/settings`, `https://accounts.firefox.com/pair` — **Mozilla** (yalnızca tıklanınca) |

`about:preferences` taramasında toplam 18 bağlantı çıktı: 9'u yerel `chrome://`
(hepsi Anatolium destek sayfası), 2'si `about:`, 1'i `ms-settings:`, 4'ü boş,
2'si yukarıdaki `accounts.firefox.com`. **Başka Mozilla adresi yok.**

Kod okumasıyla ek not: motorun bazı hata sayfaları (HTTPS-Only, COOP/COEP)
`developer.mozilla.org` adresine bağlantı üretiyor
(`omni.ja → chrome/toolkit/content/global/errors/net-errors.mjs`). Bu sayfalar
varsayılan ayarlarda açılmadığı için **ölçülmedi**; HTTPS-Only kullanıcı
tarafından açılırsa o bağlantılar Mozilla'ya gider.

**5.2 `tests/lock_test.py` (yeni):** `anatolium.cfg`'deki `lockPref` satırlarını
ve `policies.json → Preferences` girdilerini okur, tarayıcıyı izole profille
açıp her pref için *gerçek değer*, *kilit durumu* ve (isteğe bağlı
`--pristine` ile) *temiz motor varsayılanı* karşılaştırır. Fark varsa çıkış
kodu 1. Kullanım:

```
python3 tests/lock_test.py <sahnelenmiş-dizin> [--pristine <temiz-firefox>] --json docs/lock-report.json
```

### 6) Teslim

- **Ek doğrulama:** zip'ten çıkarılan kaynak yeniden sahnelendi
  (`/var/tmp/ana/stageH`) ve `tests/smoke.py` onda da **45/45** verdi.
  Yani teslim edilen arşiv, ölçülen sonucu üretiyor.
- Kaynak zip: **`Anatolium-0.4.1-faz1b-kaynak.zip`** (4,7 MB, 94 dosya; içinde
  `docs/`, `tests/lock_test.py`, ham test çıktıları ve `docs/lock-report.json`
  var; `.git` ve `__pycache__` dışarıda). Sürüm **0.4.1** kaldı, yapı numarası
  verilmedi.

---

## C. Değişen dosyalar

| Dosya | Ne değişti |
|---|---|
| `src/frontend/shell.js` | `buildStatus()`, `setStatusText()`, `zoom()`, `updateZoom()` eklendi; `TabSelect` ile durum çubuğu güncelleniyor; ölü `kind !== "closed"` koşulu kaldırıldı |
| `src/frontend/shell.css` | Durum çubuğu stilleri; tek satırda gizleme; `#statuspanel` yalnızca kanca kurulduysa gizli |
| `src/frontend/support.xhtml` | "Ağ bağlantıları ve gizlilik" bölümü, "Sık istenen konular" çapaları, "Güncelleme" bölümü, hesap notu, `h3`/`code` stilleri |
| `src/config/anatolium.cfg` | `browser.safebrowsing.malware.enabled` **false → true**, `phishing.enabled` eklendi (true) + gerekçe yorumu |
| `src/config/policies.json` | Aynı iki pref politika tarafında da `true`/`locked` (anahtar sırası normalize edildi) |
| `tests/smoke.py` | "Recently closed tab restore" gerçek kullanıcı yoluna çevrildi; tarih aralığı verisi düzeltildi; test sunucusuna `/page` yolu eklendi |
| `tests/lock_test.py` | **yeni** kilit denetimi |
| `README.md` | Gizlilik/test bölümü |
| `docs/DURUM-VE-TEST.md` | Test tablosu, kök neden tablosu, imza düzeltmesi, ÇALIŞTIRILAMADI tablosu, geliştirici notu |
| `docs/GELISTIRME-PLANI.md` | "45/45" düzeltme notu |
| `docs/FAZ1-RAPORU.md` | Tarihsel kayıt notu |
| `docs/test-report.json`, `docs/restart-persistence-report.json`, `docs/screenshots/*` | Yeniden üretildi |
| `docs/lock-report.json`, `docs/smoke-output-faz1b.txt`, `docs/lock-output-faz1b.txt`, `docs/FAZ1B-RAPORU.md` | **yeni** kanıt dosyaları |

---

## D. Test sonuçları

| Test | Sonuç | Not |
|---|---|---|
| `tests/smoke.py` | **45/45** | Bu turda düşen yok |
| `tests/lock_test.py` | **37/37** | 33 `lockPref` + 13 politika = 37 benzersiz pref |
| `tests/launcher.py` | **2/2** | D-Bus devri + D-Bus yokken güvenli duruş |
| `tests/restart_persistence.py` | **2/2** | yer imi + geçmiş yeniden başlatmada korunuyor |
| `tests/session_restore_integration.py` | **2/2** | normal kapanma + SIGKILL sonrası sekmeler geri geliyor |

### `tests/smoke.py` tam çıktısı (45/45)

```
PASS Anatolium shell initialized {"ready": "true", "header": true, "strip": true, "sidebar": false, "tabs": 1, "app": "Firefox", "version": "153.6.0", "title": "Anatolium"}
PASS Places database healthy, no locked banner {"status": 1, "locked": 4, "notice": false}
PASS Window controls at top right {"native": true, "count": 3, "right": 1366, "winWidth": 1366, "close": true, "min": true, "hiddenTabsToolbar": true}
PASS Maximize / restore {"before": {"w": 1366, "state": 1}, "maximized": {"w": 1231, "state": 3, "attr": "normal"}, "restored": {"w": 1366, "state": 1}}
PASS Custom start page loads {"title": "Anatolium Başlangıç", "greeting": "Günaydın.", "shortcuts": 6, "search": true}
PASS Start page shortcut add/remove {"before": 6, "added": 7, "removed": 6}
PASS Start page search uses selected default engine {"expected": {"engine": "Google", "url": "https://www.google.com/search?client=firefox-b-e&channel=entpr&q=anatolium+arama"}, "actual": "https://www.google.com/search?client=firefox-b-e&channel=entpr&q=anatolium+arama", "hint": "Adres çubuğuyla aynı varsayılan arama motoru kullanılır."}
PASS 1366x768 home keeps shortcuts in view {"viewportHeight": 630, "shortcutsTop": 548, "deskHeight": 226}
PASS Web navigation works {"url": "https://example.com/", "title": "Example Domain"}
PASS History panel pushes page (no overlay) {"before": 1314, "open": {"pageWidth": 914, "pageRight": 1366, "pageLeft": 452, "panelLeft": 52, "panelRight": 452, "panelWidth": 400, "open": true, "rows": 2}, "closedWidth": 0}
PASS New tab uses Anatolium home {"url": "chrome://browser/content/anatolium/home.xhtml", "tabs": 4}
PASS Theme toggle works {"before": "dark", "after": "light"}
PASS Tab search jumps to tab {"found": {"rows": 1, "titles": ["Example Domain"]}, "selected": {"url": "https://example.com/", "closed": true}}
PASS Tabs rendered horizontally on top {"count": 4, "tabs": 4, "horizontal": true, "selected": 1}
PASS about:home / about:newtab show Anatolium {"about:home": {"title": "Anatolium Başlangıç", "hasHome": false}, "about:newtab": {"title": "Anatolium Başlangıç", "hasHome": false}}
PASS Tab context menu pin/unpin {"pinned": true, "unpinned": true}
PASS Tab context menu mute/unmute {"muted": true, "unmuted": true}
PASS Compact density preference {"headerHeight": 46, "compact": "true", "restored": "false"}
PASS Native star button opens visible bookmark panel and saves {"places": {"count": 1, "urls": ["https://example.com/", "https://www.turkiye.gov.tr/", "https://developer.mozilla.org/tr/", "https://github.com/AnatoliaLabs/Anatol-X", "https://github.com/AnatoliaLabs"]}, "drawerRows": 5}
PASS Native extensions button opens visible panel {"popup": {"state": "open", "width": 388.66668701171875, "height": 369, "display": "flex", "visibility": "visible"}}
PASS Download file and list it {"file": true, "rows": ["anatolium-test.txt"]}
PASS Recently closed tab restore {"before": 5, "opened": 6, "afterClose": 5, "closedInSessionStore": 1, "labels": ["Yeni sekme", "Yeni çalışma alanı", "Kapatılan sekme geri aç", "Tüm sekmeleri yeniden yükle"], "menuRow": true, "restoredTabs": 6, "restoredUrlBack": true, "url": "http://127.0.0.1:8765/page"}
PASS Menu and about dialog {"shown": true, "closed": true, "version": "0.4.1"}
PASS Single-row chrome (tabs + address bar) {"single": true, "navParent": "an-nav-host", "headerHeight": 46, "navTop": 3, "tabsTop": 0, "tabsWidth": 624, "status": "none"}
PASS Narrow window falls back to two rows {"narrow": {"single": false, "navParent": "navigator-toolbox", "status": "flex"}, "wide": {"single": true, "navParent": "an-nav-host"}}
PASS Theme presets, glass and radius apply live {"amber": {"accent": "#fbbf24", "blur": "26px", "radius": "18px", "glass": "full", "pref": "kehribar"}, "restored": "#5eead4"}
PASS Internal about: pages follow the theme {"sheet": {"registered": true}, "aboutPreferences": {"accent": "#5eead4", "canvas": "oklch(13% 0.012 190)"}}
PASS Command palette: Turkish fold + run {"turkishFold": {"open": true, "items": ["Kişiselleştirme", "Kayıtlı Şifreler", "Sekmeyi sabitle", "“kisile” için web araması"]}, "executed": {"closed": true, "panel": "open", "swatches": 10}}
PASS Command palette arithmetic {"first": "12*(3+4) = 84"}
PASS Personalisation panel live preview {"controls": {"swatches": 10, "switches": 5, "ranges": 1, "preview": true, "segments": 16}, "light": "light", "dark": "dark"}
PASS Workspaces: create, collapse, focus, ungroup {"created": {"groups": 1, "chip": true, "label": "Sınav", "grouped": 1}, "collapsed": {"attr": true, "visible": 1}, "focused": {"collapsed": false, "selectedInGroup": true}, "removed": {"groups": 0, "chips": 0}}
PASS Split view opens and separates {"split": {"wrappers": 1, "marked": 2}, "separated": 0}
PASS Tab hover preview {"hidden": false, "src": "moz-page-thumb://thumbnails/?url=https%3A%2F%2Fexample.com%2F&revision=1193", "title": "Example Domain", "width": 268}
PASS Start page notes persist across reload {"file": true, "afterReload": {"notes": "Anatolium kalıcılık testi"}}
PASS Start page focus timer {"before": "25:00", "running": {"time": "24:58", "state": "Odaklanılıyor"}, "reset": "25:00"}
PASS 0.4 distinct visits and duplicate bookmarks survive targeted deletion {"before": 2, "afterOne": 1, "afterAll": 0, "bookmarkBefore": true, "bookmarkOtherBefore": true, "deleted": false, "other": true}
PASS 0.4 bookmark search beyond 200 and selected delete in panel {"selectAllResults": true, "foundOld": 1, "before": 6, "selected": true, "remaining": 4, "actualRemaining": 4}
PASS History interval protects boundary and bookmarks {"refused": true, "before": 3, "after": 1, "remainingToday": true, "bookmark": true, "today": true, "week": true}
PASS Permanent sidebar actions and vertical tabs {"vertical": {"vertical": true, "strip": "none", "launcher": true, "actions": ["Kütüphane", "Kişiselleştir", "Menü"], "visibility": "always-show"}, "horizontal": {"vertical": false, "strip": "flex"}}
PASS Wallpaper selection persists and uses packaged image {"before": "forest", "after": "forest", "background": "linear-gradient(rgba(3, 11, 20, 0.62), rgba(3, 11, 20, 0.86)), url(\"chrome://browser/content/anatolium/wallpapers/forest.jpg\")"}
PASS Product area only advertises Anatolium Mobile coming soon {"url": "about:preferences#moreFromMozilla", "text": " Anatolium Mobil · Yakında", "html": "<!---->\n      <!--?lit$695295443$--><moz-promo xmlns=\"http://www.w3.org/1999/xhtml\" data-l10n-id=\"settings-redesign-promo\" class=\"settings-redesign-promo\" data-l10n-attrs=\"heading,message\" type=\"default\" imagealignment=\"start\" imagewidth=\"small\" imagedisplay=\"padded\" heading=\"Aynı ayarlar, yeni görünüm!\" message=\"Bu sayfada gezinmeyi ve keşfetmeyi kolaylaştırmak için sayfayı yeniden düzenledik. Kişisel ayarlarınız değişmedi ve her şey hâlâ burada. İpucu: Aradığınız şeyi anında bulmak için arama çubuğunu kullanabilirsiniz.\">\n      <moz-button slot=\"actions\" data-l10n-id=\"settings-redesign-promo-dismiss-button\" type=\"primary\" data-l10n-attrs=\"label,tooltiptext\" size=\"default\" iconposition=\"start\" menuid=\"\" label=\"Anladım\"></moz-button>\n    </moz-promo>\n      <section xmlns=\"http://www.w3.org/1999/xhtml\">\n        <moz-page-header data-l10n-id=\"more-from-moz-page-header\" data-l10n-attrs=\"heading,description\" heading=\"Diğer Anatolia Labs Ürünleri\"><!--?lit$695295443$--></moz-page-header>\n        <!--?lit$695295443$--><!----><setting-group groupid=\"moreFromMozillaPromo\"><!----><moz-card data-l10n-attrs=\"heading\" type=\"default\"><!--?lit$695295443$--><moz-fieldset data-l10n-attrs=\"label,description,arialabel\"><!--?lit$695295443$--><!----><setting-control id=\"setting-control-anatoliumMobileComing\"><!---->\n    <!--?lit$695295443$-->\n    <moz-fieldset id=\"anatoliumMobileComing\" data-l10n-id=\"anatolium-mobile-card\" data-l10n-attrs=\"label,description,arialabel\" label=\"Anatolium Mobil · Yakında\" description=\"Anatolium deneyimi gelecekte cebinizde. Mobil sürüm hazır olduğunda burada buluşalım.\" hasheading=\"\"><!--?lit$695295443$--></moz-fieldset></setting-control><!----></moz-fieldset></moz-card></setting-group><!----><!----><setting-group groupid=\"moreFromMozillaProducts\"><!----><moz-fieldset data-l10n-attrs=\"label,description,arialabel\"><!--?lit$695295443$--></moz-fieldset></setting-group><!---->\n      </section>\n    ", "qr": false, "links": []}
PASS Installed theme changes browser header {"lw": true, "background": "rgb(150, 50, 101)", "frame": "rgb(150, 50, 101)", "themeId": "anatolium-test-theme@example.test"}
PASS 0.4 note write failure and retry {"failed": {"state": "Kaydedilemedi", "retry": true}, "saved": {"state": "Kaydedildi · Bu cihazda", "retry": false}}
PASS 0.4 animation modes {"off": "off", "rich": "rich"}
PASS No Anatolium runtime errors []

45/45 checks passed; report: /home/user/anatolium-0.4.1-faz1/docs/test-report.json
```

Faz 1'de düşen 4 kontrol, düzeltmelerden sonraki satırları:

```
PASS Recently closed tab restore {... "closedInSessionStore": 1, "menuRow": true, "restoredTabs": 6, "restoredUrlBack": true, "url": "http://127.0.0.1:8765/page"}
PASS Single-row chrome (tabs + address bar) {"single": true, "navParent": "an-nav-host", "headerHeight": 46, "navTop": 3, "tabsTop": 0, "tabsWidth": 624, "status": "none"}
PASS Narrow window falls back to two rows {"narrow": {"single": false, "navParent": "navigator-toolbox", "status": "flex"}, "wide": {"single": true, "navParent": "an-nav-host"}}
PASS History interval protects boundary and bookmarks {"refused": true, "before": 3, "after": 1, "remainingToday": true, "bookmark": true, "today": true, "week": true}
```

---

## E. Açık sorular

1. **`www.google.com` kaynağı** hâlâ bulunamadı (faz 1'den devir). Kullanıcıya
   gösterilen metne yazılmadı. Kaynağı bulununca ya kapatılmalı ya da metne
   eklenmeli. Ölçüm: faz 1 ağ denetimi; bu turda yeniden koşulmadı.
2. **Firefox Hesabı / Sync açık.** `about:preferences` içinde "Giriş yap" ve
   "Başka bir cihaz bağla" düğmeleri `accounts.firefox.com` adresine gidiyor.
   Gizlilik metnine yazıldı, ama **kapatılsın mı?** Karar faz 2'ye bırakıldı
   (`DisableFirefoxAccounts` politikası `moreFromMozilla` panelini kaldırdığı
   için faz 1'de reddedilmişti; başka bir yol gerekiyor).
3. **Durum çubuğu tasarımı:** şu an 24 px ve tek satır yüksekliği sabit.
   Kullanıcı `about:config`'ten yüksekliği değiştiremez. Faz 2'de
   kişiselleştirme paneline taşınsın mı?
4. **`an-status` gizleme kuralı** tam ekranda ve özelleştirmede gizliyor; video
   tam ekranında da gizleniyor. Bu istenen davranış mı, doğrulanmadı.
5. **Güvenli Gezinme kilitli.** Kullanıcı korumayı kapatmak isterse
   `about:config`'ten kapatamaz (bilinçli). Bu kısıtlama ürün kararı olarak
   onaylanmalı.
6. Motorun HTTPS-Only / COOP / COEP hata sayfalarındaki
   `developer.mozilla.org` bağlantıları **ölçülmedi** (o sayfalar varsayılan
   ayarlarda açılmıyor). Kapatılması isteniyorsa ayrı iş.

---

## F. Yapmadıklarım (ve nedenleri)

| Yapılmayan | Neden |
|---|---|
| Minidump / çökme kaydı kanıtı | Bu konteynerde içerik süreci SIGSEGV ile sonlandığında minidump yazılmıyor; `MOZ_CRASHREPORTER_FORCE=1` de işe yaramadı. Kanıt olarak kullanılamaz. |
| `.deb` paketi | `packaging/build.py` içinde deb hedefi yok. |
| İmzalı paket / imza doğrulaması | İmza anahtarı projede yok; kullanıcı talimatı gereği istenmedi. Paket imzasız kalıyor. |
| RPM'i yeniden derleme | Bu turda paket üretimi yapılmadı (Faz 1 RPM'i `0.2.dev2` olarak kayıtlı); sürüm numarası da değiştirilmedi. |
| Gerçek Fedora cihazında kurulum/yükseltme | Ortamda Fedora yok. |
| 120 saniyelik ağ trafiği denetimini tekrarlama | Faz 1 kaydı korunuyor; bu turun ağ kanıtı `lock_test.py` pref değerleriyle sınırlı. |
| `fedora_smoke.py`, `fallback.py`, `native_sidebar_*`, `preferences_probe.py` koşumu | Bu turda çalıştırılmadı; sonuçları Faz 1 raporundaki hâliyle duruyor, "geçti" sayılmadı. |
| Sürüm numarasını yükseltme | Kullanıcı talimatı: 0.4.1 sabit. |
