"""Anatol-X karşılama penceresi; mevcut sayfaların ve işlevlerin görsel kabuğu."""
from pathlib import Path
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QColor, QLinearGradient, QPainter, QPixmap
from PyQt6.QtWidgets import (QApplication, QCheckBox, QFrame, QHBoxLayout, QLabel,
    QMainWindow, QPushButton, QStackedWidget, QVBoxLayout, QWidget)
from welcome_app.config import set_show_on_startup, should_show_on_startup
from welcome_app.constants import DATA_DIR, WINDOW_MIN_HEIGHT, WINDOW_MIN_WIDTH
from welcome_app.pages import AppsPage, CommunityPage, PostInstallPage, SystemInfoPage

STYLE = '''
QWidget {font-family:"Noto Sans", "DejaVu Sans", sans-serif; font-size:13px; color:#eaf4f0;}
QWidget#root {background:#061211;}
QFrame#side {background:#071312; border-right:1px solid #2a423b;}
QLabel#brand {font-size:23px; font-weight:800; letter-spacing:2px;}
QLabel#slogan {font-size:10px; color:#9cafa8;}
QPushButton#nav {border:0; border-radius:10px; text-align:left; padding:13px 17px; color:#c2d1cb; background:transparent; font-size:14px;}
QPushButton#nav:hover {background:#16362c; color:white;}
QPushButton#nav[selected="true"] {background:#17694f; color:white; font-weight:700; border-left:4px solid #73f7bc;}
QWidget#home, QStackedWidget#pages {background:transparent;}
QLabel#hero {font-size:46px;font-weight:800;}
QLabel#heroGreen {font-size:46px;font-weight:800;color:#43e1a3;}
QLabel#intro {font-size:15px;color:#e0efea;}
QFrame#glass {background:rgba(5,25,24,220);border:1px solid #46655c;border-radius:16px;}
QFrame#glass QLabel {background:transparent;border:0;}
QLabel#feature {font-size:12px;color:#8affc8;font-weight:700;}
QLabel#homeCardTitle {font-size:17px;font-weight:700;}
QLabel#homeCardText {font-size:12px;color:#bed1ca;}
QFrame#footer {background:#081817;border-top:1px solid #28403a;}
QLabel#dots {color:#48dca4;font-size:16px;}
QPushButton#primaryButton {background:#35d99b;color:#07261c;border:0;border-radius:13px;padding:11px 18px;font-weight:700;}
QPushButton#primaryButton:hover {background:#69efb9;}
QPushButton#installButton, QPushButton#fullscreenButton {background:#122b26;border:1px solid #456059;border-radius:8px;padding:9px 14px;color:#edf7f3;}
QPushButton#installButton:hover, QPushButton#fullscreenButton:hover {background:#1d493b;}
QCheckBox {color:#c6d7d0;spacing:8px;}
QFrame[class="card"] {background:#112622;border:1px solid #3c5a50;border-radius:10px;}
QLabel[class="pageTitle"] {font-size:23px;font-weight:800;color:#5de3aa;}
QLabel[class="pageSubtitle"], QLabel[class="cardDescription"] {color:#bfd0c9;}
QLabel[class="cardTitle"] {font-weight:700;font-size:14px;}
QScrollArea {background:transparent;border:0;}
QScrollArea > QWidget > QWidget {background:#081a18;}
QTextEdit {background:#071714;border:1px solid #456059;border-radius:7px;color:#e2eee8;}
'''

class Background(QWidget):
    def __init__(self):
        super().__init__(); self.img=QPixmap(str(Path(DATA_DIR)/'background.png'))
    def paintEvent(self,event):
        p=QPainter(self); p.fillRect(self.rect(),QColor('#061413'))
        if not self.img.isNull():
            img=self.img.scaled(self.size(),Qt.AspectRatioMode.KeepAspectRatioByExpanding,Qt.TransformationMode.SmoothTransformation)
            p.drawPixmap((self.width()-img.width())//2,(self.height()-img.height())//2,img)
        g=QLinearGradient(0,0,self.width(),0); g.setColorAt(0,QColor(2,14,14,245)); g.setColorAt(.5,QColor(2,14,14,200)); g.setColorAt(1,QColor(2,14,14,125)); p.fillRect(self.rect(),g)
        g=QLinearGradient(0,0,0,self.height()); g.setColorAt(0,QColor(0,0,0,15)); g.setColorAt(1,QColor(2,15,14,215)); p.fillRect(self.rect(),g)

class MainWindow(QMainWindow):
    """Yeni tasarım, mevcut sistem, güncelleme, uygulama ve topluluk sayfaları."""
    def __init__(self):
        super().__init__(); self.setWindowTitle('Anatol-X Hoş Geldiniz'); self.setMinimumSize(WINDOW_MIN_WIDTH,WINDOW_MIN_HEIGHT); self.resize(1280,760)
        self.setStyleSheet(STYLE)
        root=QWidget(); root.setObjectName('root'); self.setCentralWidget(root); outer=QVBoxLayout(root); outer.setContentsMargins(0,0,0,0); outer.setSpacing(0)
        body=QHBoxLayout(); body.setSpacing(0); outer.addLayout(body,1)
        side=QFrame(); side.setObjectName('side'); side.setFixedWidth(230); sl=QVBoxLayout(side); sl.setContentsMargins(16,32,16,25)
        logo=QLabel(); logo.setAlignment(Qt.AlignmentFlag.AlignCenter); logo.setPixmap(QPixmap(str(Path(DATA_DIR)/'logo.png')).scaled(115,100,Qt.AspectRatioMode.KeepAspectRatio,Qt.TransformationMode.SmoothTransformation)); sl.addWidget(logo)
        brand=QLabel('ANATOL-X'); brand.setObjectName('brand'); brand.setAlignment(Qt.AlignmentFlag.AlignCenter); sl.addWidget(brand)
        slogan=QLabel('Daha Fazlası, Daha Özgür Bir Sistem'); slogan.setObjectName('slogan'); slogan.setAlignment(Qt.AlignmentFlag.AlignCenter); sl.addWidget(slogan); sl.addSpacing(45)
        self.nav=[]
        for i,label in enumerate(['⌂   Hoş Geldiniz','▣   Sistem Bilgisi','↻   Güncellemeler','◇   Uygulamalar','ⓘ   Topluluk ve Destek']):
            b=QPushButton(label); b.setObjectName('nav'); b.setCursor(Qt.CursorShape.PointingHandCursor); b.clicked.connect(lambda checked=False,index=i:self._navigate(index)); sl.addWidget(b); self.nav.append(b)
        sl.addStretch(); signature=QLabel('✧\nAnatol-X\nDaima Daha İleriye'); signature.setObjectName('slogan'); signature.setAlignment(Qt.AlignmentFlag.AlignCenter); sl.addWidget(signature); body.addWidget(side)
        bg=Background(); bl=QVBoxLayout(bg); bl.setContentsMargins(38,20,35,28)
        top=QHBoxLayout(); top.addStretch(); fullscreen=QPushButton('Tam ekran / pencere'); fullscreen.setObjectName('fullscreenButton'); fullscreen.clicked.connect(self._toggle_fullscreen); top.addWidget(fullscreen); bl.addLayout(top)
        self.stack=QStackedWidget(); self.stack.setObjectName('pages'); bl.addWidget(self.stack,1); body.addWidget(bg,1)
        self.pages=[self._make_home(),SystemInfoPage(),PostInstallPage(),AppsPage(),CommunityPage()]
        for page in self.pages:self.stack.addWidget(page)
        footer=QFrame(); footer.setObjectName('footer'); fl=QHBoxLayout(footer); fl.setContentsMargins(22,13,22,13)
        self.show_on_startup_checkbox=QCheckBox('Bu pencereyi açılışta gösterme'); self.show_on_startup_checkbox.setChecked(not should_show_on_startup()); self.show_on_startup_checkbox.toggled.connect(self._on_show_on_startup_toggled); fl.addWidget(self.show_on_startup_checkbox); fl.addStretch()
        self.dots=QLabel(); self.dots.setObjectName('dots'); fl.addWidget(self.dots); fl.addStretch()
        self.back_button=QPushButton('Geri'); self.back_button.setObjectName('installButton'); self.back_button.clicked.connect(self._go_back); fl.addWidget(self.back_button)
        self.next_button=QPushButton('İleri'); self.next_button.setObjectName('primaryButton'); self.next_button.clicked.connect(self._go_next); fl.addWidget(self.next_button)
        self.close_button=QPushButton('Kapat'); self.close_button.setObjectName('installButton'); self.close_button.clicked.connect(self.close); fl.addWidget(self.close_button); outer.addWidget(footer)
        self._current_index=0; self._update_navigation()
    def _make_home(self):
        home=QWidget(); home.setObjectName('home'); v=QVBoxLayout(home); v.setContentsMargins(0,0,0,0); v.addStretch(2)
        a=QLabel('Anatol-X’e'); a.setObjectName('hero'); v.addWidget(a); b=QLabel('Hoş Geldiniz!'); b.setObjectName('heroGreen'); v.addWidget(b)
        intro=QLabel('Modern, hızlı ve özgür bir Linux deneyimi için doğru yerdesiniz. Anatol-X ile bilgisayarınız artık daha güçlü, daha özgür ve daha size özel.'); intro.setObjectName('intro'); intro.setWordWrap(True); intro.setMaximumWidth(570); v.addSpacing(15); v.addWidget(intro); v.addSpacing(22)
        card=QFrame(); card.setObjectName('glass'); hl=QHBoxLayout(card); hl.setContentsMargins(16,20,16,20)
        for text in ['◆\nGüvenli Sistem','⚡\nYüksek Performans','●\nModern Tasarım','◇\nUygulama Desteği']:
            t=QLabel(text); t.setObjectName('feature'); t.setWordWrap(True); t.setAlignment(Qt.AlignmentFlag.AlignCenter); hl.addWidget(t,1)
        card.setMaximumWidth(680); v.addWidget(card); v.addStretch(3)
        start=QFrame(); start.setObjectName('glass'); row=QHBoxLayout(start); row.setContentsMargins(22,18,22,18); col=QVBoxLayout(); title=QLabel('✧  Başlarken'); title.setObjectName('homeCardTitle'); col.addWidget(title); text=QLabel('Anatol-X’in sunduğu deneyimi keşfetmeye hazır mısınız?'); text.setObjectName('homeCardText'); text.setWordWrap(True); col.addWidget(text); row.addLayout(col,1)
        button=QPushButton('Hemen Başlayalım  ➜'); button.setObjectName('primaryButton'); button.clicked.connect(self._go_next); row.addWidget(button); v.addWidget(start); return home
    def _update_navigation(self):
        self.stack.setCurrentIndex(self._current_index); self.back_button.setVisible(self._current_index>0); self.next_button.setVisible(self._current_index<len(self.pages)-1)
        self.dots.setText('   '.join('●' if i==self._current_index else '○' for i in range(len(self.pages))))
        for i,b in enumerate(self.nav):
            b.setProperty('selected',i==self._current_index); b.style().unpolish(b); b.style().polish(b)
    def _navigate(self,index):self._current_index=index; self._update_navigation()
    def _go_next(self):self._navigate(min(self._current_index+1,len(self.pages)-1))
    def _go_back(self):self._navigate(max(self._current_index-1,0))
    def _toggle_fullscreen(self):self.showNormal() if self.isFullScreen() else self.showFullScreen()
    def _on_show_on_startup_toggled(self,dont_show):set_show_on_startup(not dont_show)
