#!/bin/sh
# Existing installations need a fresh grub.cfg. Live ISO builds have no
# installed GRUB config yet; Calamares generates it during installation.
set -e
if [ -s /boot/grub/grub.cfg ] && command -v update-grub >/dev/null 2>&1; then
    update-grub
fi
