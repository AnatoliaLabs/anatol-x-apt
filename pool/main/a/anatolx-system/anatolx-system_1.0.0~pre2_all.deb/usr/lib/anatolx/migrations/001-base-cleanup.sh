#!/bin/sh
# Göç 001: KDE plasma-welcome kalıntılarını temizle ve Anatolium varsayılan tarayıcı kaydını doğrula.
set -e

rm -f /etc/xdg/autostart/*plasma-welcome* \
      /usr/share/applications/org.kde.plasma-welcome.desktop \
      /usr/share/metainfo/org.kde.plasma-welcome.appdata.xml \
      /usr/bin/plasma-welcome \
      /usr/lib/*/qt6/plugins/kf6/kded/kded_plasma-welcome.so || true

if [ -x /usr/bin/anatolium ] && command -v update-alternatives >/dev/null 2>&1; then
    update-alternatives --install /usr/bin/x-www-browser x-www-browser /usr/bin/anatolium 200 || true
    update-alternatives --set x-www-browser /usr/bin/anatolium || true
    update-alternatives --install /usr/bin/gnome-www-browser gnome-www-browser /usr/bin/anatolium 200 || true
    update-alternatives --set gnome-www-browser /usr/bin/anatolium || true
fi

exit 0
