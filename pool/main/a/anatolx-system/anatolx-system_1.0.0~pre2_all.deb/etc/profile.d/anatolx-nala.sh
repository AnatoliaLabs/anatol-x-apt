# Anatol-X Nala Entegrasyonu (yalnizca etkilesimli kabuklarda aktif)
case $- in
    *i*)
        if command -v nala >/dev/null 2>&1; then
            alias apt='nala'
            alias sudo='sudo '
        fi
        ;;
esac
