# AX-Center

> sürüm **0.6.1** · 77 test · `make verify` · "konsept" arayüzü (v0.6)

Anatol-X'in tek denetim masası. Bu depo, plandaki **3 → 2 → 1** sırasıyla
kurulmuş ilk çalışan iskeleti içerir:

| Adım | Durum |
|---|---|
| **3. Calamares `mount.conf` düzeltmesi** | ✅ `calamares/mount.conf` — `btrfsSubvolumes` artık `mount.conf` içinde, `@` ve `@home` üretiliyor |
| **2. `anatol-helper` + `anatol-context` v0.2** | ✅ polkit'li yardımcı, dar verb listesi, intel_pstate/EPP farkındalığı, `anatol-snapshot` CLI |
| **1. Repo iskeleti** | ✅ PyQt6 ana pencere, sol menü, tema, 8 sayfa, demo modu, `.deb` paketleme |

![Genel Bakış](docs/screens/overview.png)

> Sevkiyat durumu: **[docs/SEVKIYAT.md](docs/SEVKIYAT.md)** — ne kanıtlandı, ne kanıtlanmadı.

> **Tıklanabilir tanıtım: [docs/ax-center-onizleme.html](docs/ax-center-onizleme.html)** — 8 sayfa, koyu/açık tema, klavyeyle gezinme.
> Tüm ekranlar: [docs/screens](docs/screens) · galeri: [docs/preview.html](docs/preview.html). Görüntüler 2x (HiDPI) üretilir.

---

## Neden bu mimari

Arayüz **yetkisiz** çalışır. Root gereken her iş, `/usr/libexec/anatol-helper`
adlı küçük bir yardımcıya `pkexec` ile devredilir. Yardımcının yapabildiği
şeyler sabit bir listedir; serbest komut çalıştırma yeteneği yoktur.

```
ax-center (GUI, kullanıcı)  ─┐
anatol-context (CLI, kullanıcı) ─┼─► pkexec ─► anatol-helper (root, 14 verb)
anatol-snapshot (CLI)       ─┘                    │
                                                  ├─ power.py      (PPD / cpufreq / EPP)
                                                  ├─ services.py   (systemd, korumalı liste)
                                                  ├─ snapshots.py  (Timeshift, APT kancası)
                                                  └─ config-set…   (/etc/anatol/anatol.toml)
```

Kullanıcı tarafında kalanlar — Rahatsız Etme, `flatpak --user` izinleri, KWin
compositor — **yardımcıya hiç uğramaz**. Sebebi net: root'un `$HOME` içine
yazması er ya da geç root sahipli config dosyaları ve bozuk bir oturum demek.

`anatol-helper` çıktısı her zaman stdout'ta tek bir JSON nesnesidir. GUI,
CLI ve APT kancası aynı sözleşmeyi kullanır; hiçbir yerde metin kazınmaz.

### Plandan bilinçli sapmalar

1. **D-Bus servisi yerine tek seferlik pkexec çağrısı.** Mod değiştirmenin
   tamamı (güç + servisler) tek bir `mode-apply` çağrısıdır, yani tek parola
   istemi. Ayrı ayrı `power` + `service` çağrıları üç parola sorardı. D-Bus
   daemon'a geçmek 1.x için hâlâ mümkün; yardımcının verb listesi aynı kalır.
2. **Okuma işlemleri yardımcıdan geçmez.** `/proc`, `/sys`, `systemctl
   is-active`, snapshot dizinleri kullanıcı olarak okunabilir. Böylece
   gezinmek parola sormaz; yalnızca yazan işlemler sorar.
3. **Sürücü *kurulumu* v1.1'e bırakıldı.** NVIDIA + Secure Boot MOK kaydı
   yanlış giderse sistem açılmaz. Alpha'da yalnızca tespit ve öneri var,
   sayfa bunu açıkça yazıyor.

---

## Kurulum

### Depodan çalıştırma (geliştirme)

```sh
python3 -m pip install PyQt6          # PyQt6 zaten Anatol-X'te var
make test                             # 35 test
make run                              # DEMO modu, gerçek sisteme dokunmaz
make screens                          # docs/screens/*.png üretir
```

CLI'leri kurulu sisteme dokunmadan denemek için:

```sh
export PYTHONPATH=$PWD
export ANATOL_CONTEXT_DIR=$PWD/etc/contexts.d
python3 cli/anatol-context list
python3 cli/anatol-context apply game --dry-run --no-root
python3 cli/anatol-snapshot status
```

### Gerçek sistem (.deb)

```sh
make deb                              # ax-center_0.3.0_all.deb
sudo apt install ./ax-center_0.3.0_all.deb
ax-center
```

Paket şunları yerleştirir:

```
/usr/bin/ax-center                      /etc/anatol/anatol.toml
/usr/bin/anatol-context                 /etc/anatol/contexts.d/*.toml
/usr/bin/anatol-snapshot                /etc/apt/apt.conf.d/80-anatol-snapshot
/usr/libexec/anatol-helper              /usr/share/polkit-1/actions/org.anatol.helper.policy
/usr/lib/python3/dist-packages/{anatol,axcenter}
```

---

## Ne çalışıyor, ne çalışmıyor

| Sayfa | Durum |
|---|---|
| **Genel Bakış** | ✅ mod, son snapshot, güncelleme sayısı, RAM/ZRAM/disk, hızlı eylemler |
| **Modlar** | ✅ 5 profil, tek tıkla uygulama, adım adım sonuç raporu, `--dry-run` |
| **Yedekler** | ✅ liste / oluştur / geri yükle / sil, GRUB-btrfs durumu, otomatik snapshot anahtarı |
| **Sürücüler** | ✅ tespit + öneri + snapshot'lı kurulum + MOK yönlendirmesi (ADM v0.4) |
| **Yazılım** | ◐ apt/Flatpak sayımı; güncelleme çalıştırma v1.1 |
| **Sistem** | ◐ ZRAM/oturum/çekirdek/Btrfs görünümü; servis yöneticisi v1.1 |
| **Gizlilik** | ◐ telemetri denetimi gerçek (`dpkg-query`), ufw v1.1 |
| **Hakkında** | ✅ sürüm + log paketleme (`/var/log/anatol` + ev dizinine kopya) |

### Sürücüler (ADM) — 0.4'ün ana işi

`anatol/drivers.py` donanımı **okur**, tahmin etmez: `lspci -nnk` ile PCI
kimlikleri ve çekirdek sürücüsü, `nvidia-detect` ile NVIDIA önerisi,
`mokutil --sb-state` ile Secure Boot, `dkms status` ile modül durumu.
Öneri üretici başına sabit tablodan gelir (NVIDIA / AMD / Intel / Broadcom /
Realtek / Atheros / MediaTek) ve her öneri bir **risk seviyesi** taşır:

| Risk | Ne zaman |
|---|---|
| düşük | `firmware-*`, `mesa-vulkan-drivers`, `intel-media-va-driver` |
| orta | DKMS paketleri (`nvidia-driver`, `broadcom-sta-dkms`), Secure Boot kapalı |
| yüksek | aynı DKMS paketleri + **Secure Boot açık** → MOK kaydı şart |

Kurulumun sırası koddadır, değiştirilemez:

```
paket adı beyaz listesi → canlı oturum kontrolü → snapshot → apt (nala varsa) → DKMS/MOK denetimi
```

- Paket adları `PACKAGE_PATTERNS` ile denetlenir; `nvidia-driver; reboot` gibi
  bir girdi yardımcıya ulaşmadan reddedilir (test edildi).
- Snapshot alınamazsa **kurulum durur**, "yine de kur" seçeneği yalnızca açık
  bayrakla (`--allow-no-snapshot`) vardır ve GUI bunu kullanmaz.
- Secure Boot açıksa kurulum sonrası sertifika aranır ve tam komut verilir
  (`sudo mokutil --import /var/lib/shim-signed/mok/MOK.der`), GUI'de tek
  tuşla panoya kopyalanır.
- `DPkg::Lock::Timeout=120`: PackageKit açıkken kilit hatası yerine bekler.

Arayüz `ax-center` hiçbir yardımcı bulamazsa **DEMO moduna** düşer ve sağ
altta kırmızı `DEMO` rozeti gösterir. `AX_CENTER_DEMO=1` ile zorlanabilir;
tasarım üzerinde çalışırken işe yarıyor.

---

## Mod profilleri

Modlar kodun içine gömülü değildir. `/etc/anatol/contexts.d/*.toml`:

```toml
id = "game"
name = "Oyun / Performans"
power_profile = "performance"
epp = "performance"                       # intel_pstate varsa
stop_services = ["bluetooth.service", "cups.service"]
dnd = true
compositor = "auto"                       # auto | on | off (X11)

[[flatpak_rules]]
app = "com.discordapp.Discord"
network = false
```

Kendi modunuzu yazmak için bu dizine bir dosya bırakın; GUI ve CLI bir
sonraki açılışta görür. Bozuk bir profil sistemi kilitlemez: liste içinde
"bozuk profil" olarak görünür ve nedeni yazılır (`ContextError`).

Doğrulama kuralları (testlerle sabitlenmiş): kimlik `^[a-z0-9][a-z0-9_-]{0,31}$`,
servis adı `….(service|socket|timer|target|mount)`, düz `power_profile`,
`epp` ve `compositor` değerleri, ve aynı servisin hem durdurulan hem
başlatılan listede olmaması.

### Güç: intel_pstate tuzağı

Eski `anatol-context` iki hata yapıyordu; ikisi de düzeltildi ve test edildi:

1. Governor'ı root olmadan yazmaya çalışıp sessizce başarısız oluyordu.
   Artık yazma yalnızca yardımcıda.
2. `intel_pstate` altında `schedutil` **yoktur**. `power.py` önce CPU'nun
   gerçekten sunduğu `scaling_available_governors` listesine bakar:
   `schedutil` varsa onu, yoksa `powersave`/`performance` + EPP'yi kullanır.
   `power-profiles-daemon` çalışıyorsa cpufreq'e hiç dokunulmaz — servis
   zaten governor ve EPP'yi yönetiyor; kavga eden iki yönetici en kötü sonuç.

`anatol-context status` bu tabloyu tek ekranda verir.

### APT kancası, düzgün hali

Eski tek satırlık `DPkg::Pre-Invoke` her dpkg çağrısında Timeshift'i
çalıştırıyordu — canlı oturumda bile. Artık:

```sh
# /etc/apt/apt.conf.d/80-anatol-snapshot
DPkg::Pre-Invoke { "/usr/bin/anatol-snapshot ensure-pre-update || true"; };
```

`ensure-pre-update` şu sırayla karar verir ve **her zaman 0 ile çıkar**:
ayar kapalı mı → canlı oturum mu (`/run/live`, overlay kök) → Timeshift var mı
→ Btrfs modunda `@`/`@home` var mı → son snapshot 15 dakikadan yeni mi →
kilit başka bir snapshot'ta mı. Hepsi test edildi.

---

## Btrfs / Calamares

Yedekler sayfası Timeshift'in Btrfs moduna dayanır ve o mod `@` + `@home`
alt hacimlerini arar. `btrfsSubvolumes` **`partition.conf` değil,
`mount.conf`** anahtarıdır. Doğru dosya `calamares/mount.conf` içinde;
ISO'ya kopyalama ve kurulum sonrası doğrulama adımları
`calamares/README.md`'de.

Düzeltilmemiş bir ISO ile kurulmuş sistemde sayfa boş kalmaz: kırmızı bir
şerit çıkar ve nedenini söyler (`@ / @home alt hacimleri yok`). Sessiz
başarısızlık, bu tür bir hatanın en kötü biçimi.

---

## Testler

```sh
make test        # 69 test, ~4 sn
make verify      # 15 kontrol: lint, test, .deb doğrulama, CLI/yardımcı, arayüz
```

Kapsam: profil doğrulama (yol aşımı ve komut enjeksiyonu denemeleri dahil),
governor seçimi (intel_pstate / acpi-cpufreq / PPD), snapshot listeleme ve
`ensure-pre-update` karar ağacı, yardımcı sözleşmesi (bilinmeyen verb,
root kontrolü, `shell=True`/`eval` yasağı), **sürücü ayrıştırma + öneri +
paket beyaz listesi + snapshot başarısızlığında durma**, ve arayüz duman
testleri (8 sayfa kuruluyor, çiziliyor, mod değişimi ve ADM planı çalışıyor).

Ek olarak `make verify` (scripts/verify.sh) tek komutta şunları koşar: ruff,
compileall, testler, `.deb` üretimi + md5sums/kritik dosya/polkit XML doğrulaması,
paketi açıp kurulu düzeni taklit ederek CLI ve **15 yardımcı verb'ünün** JSON
sözleşmesi, sürüm tutarlılığı (kod = changelog) ve 8 sayfanın offscreen render'ı.

CI: `.github/workflows/ci.yml` — Python 3.11 ve 3.13'te testler, offscreen
ekran görüntüsü üretimi ve `.deb` artifact'i.

---

## Sıradaki işler

1. **Gerçek donanımda sürücü kurulumu provası** — NVIDIA + Secure Boot'lu bir
   makinede MOK adımı baştan sona yürünmeli. Kod hazır, saha verisi yok.
2. Yazılım: `nala upgrade` + zorunlu ön-snapshot, kilit yönetimi.
3. Sistem: servis yöneticisi, SDDM oturum seçimi, ZRAM boyutu.
4. Gerçek donanımda mod değişimi + snapshot geri yükleme provası (hafta 7).
5. 1.x: otomatik mod geçişi (fiş/oyun algılama), sistem tepsisi simgesi,
   Flatseal benzeri izin görüntüleyici, Gizlilik sayfasında ufw.

Ayrıntılı haftalık plan ve kapsam kararları için: `docs/DURUM.md`.
