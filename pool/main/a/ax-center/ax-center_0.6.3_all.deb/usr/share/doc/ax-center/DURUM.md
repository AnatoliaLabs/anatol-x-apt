# Durum ve yol haritası

Son güncelleme: 13 Kasım 2026 · sürüm 0.6.3

## Ön koşullar (planın §4'ü)

| # | Ön koşul | Durum | Nerede |
|---|---|---|---|
| 1 | Calamares Btrfs alt hacimleri | ✅ düzeltildi | `calamares/mount.conf`, `calamares/README.md` |
| 2 | APT snapshot kancası | ✅ yeniden yazıldı | `etc/apt.conf.d/80-anatol-snapshot`, `anatol/snapshots.py::ensure_pre_update` |
| 3 | `anatol-context` betiği | ✅ v0.2 | `cli/anatol-context`, `anatol/power.py`, `anatol/services.py` |

Üçü de donanımda **henüz koşulmadı**; kod ve testler hazır, gerçek makinede
doğrulama hafta 7 işi. Doğrulama komutları aşağıda.

## 8 haftalık plana göre

| Hafta | Plan | Durum |
|---|---|---|
| 1-2 | `anatol-helper` + polkit, `anatol-context` yeniden yazımı, `anatol-snapshot` CLI | ✅ bitti |
| 3-4 | GUI iskeleti (sol menü, tema), Genel Bakış + Modlar (3 mod) | ✅ bitti, 5 mod |
| 5 | Yedekler sayfası (liste/oluştur/geri yükle) | ✅ bitti (+ sil, GRUB durumu, otomatik anahtar) |
| 6 | Sürücüler (NVIDIA tespit + kurulum), Güncellemeler | ✅ ADM bitti (0.4) · güncelleme akışı sırada |
| 7 | Donanımda test, hata düzeltme, .deb paketleme | ◐ paketleme + CI hazır, donanım testi sırada |
| 8 | Cilalama, Hakkında/log paketleme, Beta duyurusu | ◐ log paketleme bitti |

Yani takvim kabaca **5. haftanın sonunda**. Fazlalık: 5 mod (plandaki 3 değil),
snapshot silme, `--dry-run`, `anatol-context status` teşhis ekranı, demo modu
ve ekran görüntüsü üreteci.

## Bu oturumda yazılanlar

```
anatol/                ortak kütüphane (stdlib, Qt yok)
  util.py              run/Step/TOML/atomik yazma/log
  contexts.py          TOML profil ayrıştırma + doğrulama
  drivers.py           ADM: lspci -nnk, nvidia-detect, mokutil, öneri, kurulum
  power.py             PPD / cpufreq / intel_pstate / EPP
  services.py          systemd + korumalı servis listesi
  userenv.py           DND, flatpak --user, KWin, mod durumu
  snapshots.py         Timeshift + ensure_pre_update
  helperclient.py      pkexec köprüsü
helper/anatol-helper   14 verb, JSON çıktı, root
helper/org.anatol.helper.policy
cli/anatol-context     list / show / apply / revert / current / status
cli/anatol-snapshot    status / list / create / restore / delete / auto / ensure-pre-update
axcenter/              PyQt6 arayüz (8 sayfa, tema, ikonlar, worker)
etc/                   anatol.toml, 5 mod profili, APT kancası
calamares/             mount.conf + açıklama
debian/                control/rules/postinst/prerm/desktop/svg/changelog
tests/                 66 test
.github/workflows/     CI (test + paket artifact)
scripts/build-deb.sh   debhelper olmadan .deb
docs/screens/          8 ekran görüntüsü
```

## Donanımda doğrulama çeklisti

Kurulu bir Anatol-X Alpha üzerinde sırayla:

```sh
# 1. Alt hacimler
btrfs subvolume list /            # @ ve @home görünmeli
findmnt -no OPTIONS /home         # subvol=/@home

# 2. Yedekler
anatol-snapshot status            # "@ / @home düzeni: var", mod btrfs
sudo anatol-snapshot create -c "ilk test"
anatol-snapshot list

# 3. APT kancası (canlı oturumda atlanmalı)
sudo apt install --reinstall ax-center     # çıktıda "atlandı — canlı oturum" ya da snapshot satırı
cat /var/log/anatol/anatol.log

# 4. Güç / modlar
anatol-context status             # sürücü + governor + EPP
anatol-context apply game --dry-run
anatol-context apply game         # tek parola istemi
powerprofilesctl get
systemctl is-active bluetooth     # oyun modunda inactive

# 5. Arayüz
ax-center                         # DEMO rozeti GÖRÜNMEMELİ
```

Not edilmesi gerekenler: `lspci` Wi-Fi çipi, Secure Boot durumu
(`mokutil --sb-state`), oturum tipi (Wayland/X11) ve `powerprofilesctl get`
çıktısı. Beta duyurusundan önce bu beş satır testçilerden istenecek.

## Bilinen sınırlar

* **DND** `plasmanotifyrc` üzerinden yazılıyor (Plasma 5/6'da D-Bus API'si
  yok). Plasma 6.3+ üzerinde doğrulandı; Plasma 5'te yedek olarak
  bildirim applet'i elle kapatılabilir. Mod değişimi sonrası DND'nin
  gerçekten açıldığını kontrol eden bir uyarı v1.1'de eklenecek.
* **KWin compositor** yalnızca X11'de kapatılabiliyor; Wayland'de adım
  "atlandı" olarak raporlanıyor (sessizce yutulmuyor).
* **Sürücü kurulumu** kod olarak hazır ama **gerçek donanımda denenmedi**.
  NVIDIA + Secure Boot'lu bir makinede MOK adımı baştan sona yürünmeli;
  saha verisi gelene kadar Beta'da "deneysel" etiketi kalmalı.
* **Yazılım güncellemesi** GUI'den çalışmıyor (v1.1) — `nala upgrade`
  sırasında oluşan kilit sorunları ve önce-snapshot akışı birlikte
  tasarlanmalı.
* **`.deb` imzalanmadı**; Alpha için `-us -uc` yeterli, Beta'da depo anahtarı.

## 0.5.0 ile gelenler (arayüz yenilemesi)

Görsel katman baştan yazıldı; işlevsel davranış aynı kaldı, yeni özellik yok.

| Katman | Ne değişti |
|---|---|
| `theme.py` | Açık/koyu jeton sözlükleri, `SPACE`/`RADIUS` skalası, tipografi seçimi, tek `stylesheet()` |
| `widgets.py` | `Pill`, `Banner`, `Card` (+pill/ek içerik/eylem), `MetricCard`, `SectionHeader`, `StepList`, `EmptyState`, `card_grid` |
| `window.py` | Gradyan logo, ikonlu 238 px kenar çubuğu, `Ctrl+1..8`, breadcrumb üst çubuk, `Toast`, 140 ms geçiş |
| `pages/*` | Sekiz sayfanın tamamı yeni bileşen API'sine taşındı; Hakkında sayfasına marka bloğu |
| `format.py` | `tr_upper()` — Türkçe büyük harf (i → İ, ı → I) |

Doğrulama: `make verify` → 15 kontrol, 69 test, 8 sayfa 2x render.

## 0.4.0 ile eklenenler (sürücüler)

- `lspci -nnk` ayrıştırması, PCI kimlikleri, çekirdek sürücüsü ve modüller
- `nvidia-detect` entegrasyonu + güvenli varsayılan
- Secure Boot (`mokutil --sb-state`) ve DKMS durumu, MOK sertifika adayları
- Üretici tablosu: NVIDIA / AMD / Intel / Broadcom / Realtek / Atheros / MediaTek
- Risk modeli: düşük (firmware) · orta (DKMS) · yüksek (DKMS + Secure Boot)
- Beyaz listeli `driver-install`: snapshot → apt → DKMS/MOK denetimi
- Sürücüler sayfası: donanım kartları, risk rozetleri, onay diyaloğu, adım
  raporu, MOK komutu + panoya kopyalama
- 31 yeni test (toplam 66), GitHub Actions CI

## Açık sorular

1. Mod geçişinde **KDE Activities** eşlemesi 1.0'a girsin mi? Profil alanı
   (`activity`) hazır ama uygulanmıyor — `kactivitymanagerd` D-Bus arayüzü
   gerekiyor ve Wayland'de davranışı test edilmeli.
2. **`grub-btrfs`** varsayılan kurulu gelsin mi? Yedekler sayfası onun
   durumunu gösteriyor ama ISO'ya eklemek GRUB menüsünü uzatıyor.
3. Timeshift'in kendi zamanlayıcısı mı, yoksa AX-Center'ın "günde bir"
   hatırlatması mı? Şu an Timeshift'in kendi ayarına dokunulmuyor.

## Davranış (0.6.2)

- Mod uygulama gerçekten sisteme dokunuyor: güç profili (PPD veya sysfs, yazımdan
  sonra **geri okuma** ile doğrulanır) + servisler (`systemctl`) + kullanıcı yarısı
  (`plasmanotifyrc`, compositor, flatpak, `state.json`).
- Arayüzdeki 23 düğmenin tamamı gerçek işe bağlı; "Güncelleştir" ve
  "Btrfs scrub başlat" 0.6.2'de gerçek işleve kavuştu.
- Bir adım başarısız olursa arayüz kırmızı gösterir ve nedeni yazar; hiçbir adım
  sessizce "başarılı" sayılmaz.
- Ayrıntı: `docs/DAVRANIS.md` (depoya dahil, paket içinde yok).

## Simge (0.6.3)

- Simge yazısızdır: üç kontrol çubuğu (denetim masası). Font gerekmez, 16 px'te
  okunur. `debian/ax-center.svg` (vektör) + `hicolor/{16..256}/apps/ax-center.png`.
- Uygulama içinde aynı geometri `axcenter/brand.py` tarafından QPainter ile
  çizilir; `tests/test_gui.py::test_brand_matches_shipped_svg` ikisini piksel
  düzeyinde karşılaştırır.
