"""Power management: power-profiles-daemon first, raw cpufreq only as fallback.

Two rules learned the hard way, both are enforced here:

1. Never write to sysfs from an unprivileged process. The old anatol-context
   did exactly that and failed silently.
2. intel_pstate has *no* schedutil. Only performance/powersave plus EPP are
   available, so "balanced" must be expressed through EPP there. amd-pstate
   and acpi-cpufreq do have schedutil.

If power-profiles-daemon is running we let it own cpufreq (it sets governor
*and* EPP) instead of fighting it; we only tell it which profile to use.
"""

from __future__ import annotations

from pathlib import Path

from .util import Step, have, read_text, run

CPU_BASE = Path("/sys/devices/system/cpu")
INTEL_PSTATE = CPU_BASE / "intel_pstate"
AMD_PSTATE = CPU_BASE / "amd_pstate"

PROFILES = ("power-saver", "balanced", "performance")


def _cpu_dirs() -> list[Path]:
    if not CPU_BASE.is_dir():
        return []
    return sorted(
        (p for p in CPU_BASE.glob("cpu[0-9]*") if (p / "cpufreq").is_dir()),
        key=lambda p: int(p.name[3:]),
    )


def driver() -> str:
    """scaling_driver of cpu0: intel_pstate, amd-pstate-epp, acpi-cpufreq..."""
    return (read_text(CPU_BASE / "cpu0/cpufreq/scaling_driver") or "").strip()


def available_governors() -> list[str]:
    raw = read_text(CPU_BASE / "cpu0/cpufreq/scaling_available_governors") or ""
    return raw.split()


def current_governor() -> str:
    return (read_text(CPU_BASE / "cpu0/cpufreq/scaling_governor") or "").strip()


def epp_values() -> list[str]:
    raw = read_text(CPU_BASE / "cpu0/cpufreq/energy_performance_available_preferences") or ""
    return raw.split()


def current_epp() -> str:
    return (read_text(CPU_BASE / "cpu0/cpufreq/energy_performance_preference") or "").strip()


def ppd_installed() -> bool:
    return have("powerprofilesctl")


def ppd_active() -> bool:
    res = run(["systemctl", "is-active", "power-profiles-daemon.service"], timeout=10)
    return res.stdout.strip() == "active"


def ppd_current() -> str:
    res = run(["powerprofilesctl", "get"], timeout=10)
    return res.stdout.strip() if res.returncode == 0 else ""


def choose_governor(profile: str) -> str | None:
    """Map a PPD profile name to a governor this CPU actually supports."""
    avail = available_governors()
    if not avail:
        return None
    wanted = {
        "performance": ["performance"],
        "balanced": ["schedutil", "ondemand", "powersave"],
        "power-saver": ["powersave", "ondemand", "schedutil"],
    }[profile]
    for gov in wanted:
        if gov in avail:
            return gov
    return None


def _write_cpu_files(rel: str, value: str, dry_run: bool) -> tuple[int, str]:
    """Her çekirdeğe yaz ve **geri okuyarak** doğrula.

    Yazmanın hata vermemesi "oldu" demek değil: intel_pstate bazı değerleri
    sessizce kendi değerine çevirir. Bu yüzden yazımdan sonra dosya tekrar
    okunur; değer tutmuyorsa çekirdek kabul etmemiştir ve adım başarısız sayılır
    (arayüz "oldu" diyorsa gerçekten olmuştur).
    """
    written, errors = 0, []
    for cpu in _cpu_dirs():
        target = cpu / rel
        if not target.exists():
            continue
        if dry_run:
            written += 1
            continue
        try:
            target.write_text(value + "\n", encoding="utf-8")
            actual = (target.read_text(encoding="utf-8") or "").strip()
        except OSError as exc:
            errors.append(f"{target}: {exc}")
            continue
        if actual == value:
            written += 1
        else:
            errors.append(f"{cpu.name}: çekirdek '{actual}' değerini dayattı")
    return written, "; ".join(errors[:3])


def apply_profile(profile: str, epp: str = "", *, dry_run: bool = False) -> list[Step]:
    """Set the system power profile. Returns the steps, never raises."""
    steps: list[Step] = []
    if profile not in PROFILES:
        return [Step(f"güç profili {profile}", ok=False, detail="bilinmeyen profil")]

    if ppd_installed() and ppd_active():
        res = run(["powerprofilesctl", "set", profile], dry_run=dry_run, timeout=30)
        steps.append(
            Step(
                f"power-profiles-daemon → {profile}",
                ok=res.returncode == 0,
                detail=(res.stderr or "").strip()[:200],
            )
        )
        steps.append(
            Step(
                "cpufreq governor",
                skipped=True,
                detail="power-profiles-daemon yönetiyor, elle yazılmadı",
            )
        )
        if epp:
            steps.append(
                Step(
                    "EPP",
                    skipped=True,
                    detail="güç profili servisi EPP'yi kendisi ayarlıyor",
                )
            )
        return steps

    gov = choose_governor(profile)
    if gov is None:
        detail = (
            f"sürücü {driver() or 'bilinmiyor'}, mevcut governor'lar: "
            f"{', '.join(available_governors()) or 'yok'}"
        )
        steps.append(Step(f"governor → {profile}", ok=False, detail=detail))
    else:
        count, err = _write_cpu_files("cpufreq/scaling_governor", gov, dry_run)
        steps.append(
            Step(
                f"governor → {gov} ({count} çekirdek)",
                ok=count > 0 and not err,
                detail=err or f"sürücü: {driver() or '?'}",
            )
        )

    if epp:
        if epp not in epp_values():
            steps.append(
                Step(
                    f"EPP → {epp}",
                    ok=False,
                    detail="bu CPU EPP desteklemiyor (intel_pstate/amd-pstate-epp gerekir)",
                )
            )
        else:
            count, err = _write_cpu_files(
                "cpufreq/energy_performance_preference", epp, dry_run
            )
            steps.append(
                Step(
                    f"EPP → {epp} ({count} çekirdek)",
                    ok=count > 0 and not err,
                    detail=err,
                )
            )
    return steps


def status() -> dict:
    return {
        "driver": driver(),
        "governors_available": available_governors(),
        "governor": current_governor(),
        "epp": current_epp(),
        "epp_available": epp_values(),
        "ppd_installed": ppd_installed(),
        "ppd_active": ppd_active(),
        "profile": ppd_current(),
        "intel_pstate": INTEL_PSTATE.is_dir(),
        "amd_pstate": AMD_PSTATE.is_dir(),
    }
