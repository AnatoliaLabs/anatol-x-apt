"""Small, boring helpers shared by every Anatol component."""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import tomllib
from dataclasses import asdict, dataclass
from pathlib import Path

# Yollar ortam değişkeniyle ezilebilir: testler ve depodan çalıştırma için.
# Kurulu sistemde hiçbiri ayarlanmaz, varsayılanlar kullanılır.
ETC = Path(os.environ.get("ANATOL_ETC", "/etc/anatol"))
CONTEXT_DIR = Path(os.environ.get("ANATOL_CONTEXT_DIR") or ETC / "contexts.d")
CONFIG_FILE = Path(os.environ.get("ANATOL_CONFIG") or ETC / "anatol.toml")
LOG_DIR = Path(os.environ.get("ANATOL_LOG_DIR") or "/var/log/anatol")
HELPER = os.environ.get("ANATOL_HELPER", "/usr/libexec/anatol-helper")

IS_ROOT = os.geteuid() == 0

_user_state = os.environ.get("XDG_STATE_HOME") or str(Path.home() / ".local/state")
USER_STATE_DIR = Path(_user_state) / "anatol"

SERVICE_RE = re.compile(r"^[A-Za-z0-9@._:\\-]+\.(service|socket|timer|target|mount)$")
FLATPAK_RE = re.compile(r"^[A-Za-z0-9_][A-Za-z0-9_.-]*(\.[A-Za-z0-9_-]+)+$")
SLUG_RE = re.compile(r"^[a-z0-9][a-z0-9_-]{0,31}$")


class AnatolError(Exception):
    """User facing error: the message is meant to be printed as is."""


# --------------------------------------------------------------------------
# process helpers
# --------------------------------------------------------------------------
@dataclass
class Step:
    """One thing we tried to do, so the CLI and the GUI can both report it."""

    label: str
    ok: bool = True
    skipped: bool = False
    detail: str = ""
    data: dict | None = None

    @property
    def status(self) -> str:
        if self.skipped:
            return "skip"
        return "ok" if self.ok else "fail"

    def as_dict(self) -> dict:
        data = asdict(self)
        data["status"] = self.status
        return data


def run(cmd, *, dry_run: bool = False, timeout: int = 180, env=None, input_text=None):
    """Run a command without a shell and never raise.

    Returns subprocess.CompletedProcess; rc 127 means "binary missing",
    rc 124 means "timed out". Callers check `.returncode`.
    """
    argv = [str(c) for c in cmd]
    if dry_run:
        return subprocess.CompletedProcess(argv, 0, "", f"[dry-run] {' '.join(argv)}\n")
    try:
        return subprocess.run(
            argv,
            capture_output=True,
            text=True,
            timeout=timeout,
            env=env,
            input=input_text,
        )
    except FileNotFoundError:
        return subprocess.CompletedProcess(argv, 127, "", f"{argv[0]}: komut bulunamadı")
    except subprocess.TimeoutExpired:
        return subprocess.CompletedProcess(argv, 124, "", "zaman aşımı")
    except OSError as exc:  # pragma: no cover - defensive
        return subprocess.CompletedProcess(argv, 126, "", str(exc))


def have(binary: str) -> bool:
    return shutil.which(binary) is not None


def read_text(path) -> str | None:
    try:
        return Path(path).read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None


def write_text(path, data: str, *, mode: int | None = None) -> None:
    """Atomic write (same directory, fsync'd rename)."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=str(path.parent), prefix=f".{path.name}.")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(data)
            fh.flush()
            os.fsync(fh.fileno())
        if mode is not None:
            os.chmod(tmp, mode)
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def load_toml(path) -> dict:
    with open(path, "rb") as fh:
        return tomllib.load(fh)


def log(message: str) -> None:
    """Log to /var/log/anatol when we may, else to stderr."""
    line = f"[{os.getpid()}] {message}"
    if LOG_DIR.is_dir() and os.access(LOG_DIR, os.W_OK):
        try:
            with open(LOG_DIR / "anatol.log", "a", encoding="utf-8") as fh:
                fh.write(line + "\n")
            return
        except OSError:
            pass
    print(line, file=sys.stderr)


def emit(payload: dict) -> None:
    json.dump(payload, sys.stdout, ensure_ascii=False, indent=None, sort_keys=True)
    sys.stdout.write("\n")
    sys.stdout.flush()


# --------------------------------------------------------------------------
# config
# --------------------------------------------------------------------------
DEFAULT_CONFIG = {
    "snapshot_before_update": True,
    "grub_btrfs_expected": True,
    "dnd_restore_on_exit": False,
}


def load_config() -> dict:
    """Read /etc/anatol/anatol.toml, falling back to sane defaults."""
    cfg = dict(DEFAULT_CONFIG)
    try:
        cfg.update(load_toml(CONFIG_FILE))
    except FileNotFoundError:
        pass
    except (OSError, tomllib.TOMLDecodeError) as exc:
        log(f"anatol.toml okunamadı: {exc}")
    return cfg


def save_allowed_on_anatol() -> bool:
    """True when we look like an installed Anatol-X system."""
    return Path("/etc/os-release").exists() and ETC.exists()
