"""Yazılım ve Güncellemeler: apt + Flatpak tek ekranda."""

from __future__ import annotations

from datetime import datetime

from PyQt6.QtWidgets import QHBoxLayout, QMessageBox, QPushButton

from ..widgets import Banner, Card, Page, Pill, StepList, card_grid, muted, section


class SoftwarePage(Page):
    title = "Yazılım ve Güncellemeler"
    subtitle = (
        "Debian ve Flatpak güncellemeleri birlikte görünür. Güncellemeden önce "
        "otomatik snapshot (Yedekler sayfasındaki anahtar) devreye girer."
    )

    def build(self) -> None:
        self.apt_card = Card("Debian", "—", "apt / nala")
        self.flatpak_card = Card("Flatpak", "—", "runtime + uygulama")
        self.snap_card = Card("Güvenlik ağı", "—", "güncelleme öncesi snapshot")
        self.snap_pill = Pill("—", "muted")
        self.snap_card.add_pill(self.snap_pill)
        self.last_card = Card("Son kontrol", "—")
        self.layout.addLayout(
            card_grid([self.apt_card, self.flatpak_card, self.snap_card, self.last_card], 2)
        )

        actions = QHBoxLayout()
        actions.setSpacing(8)
        self.btn_upgrade = QPushButton("Güncelleştir")
        self.btn_upgrade.setObjectName("primary")  # sayfanın ana eylemi
        self.btn_upgrade.clicked.connect(self.upgrade)
        self.btn_check = QPushButton("Denetle")
        self.btn_check.clicked.connect(self.check)
        for button in (self.btn_upgrade, self.btn_check):
            actions.addWidget(button)
        actions.addStretch(1)
        self.layout.addWidget(section("İşlemler"))
        self.layout.addLayout(actions)
        self.steps = StepList()
        self.layout.addWidget(self.steps)

        self.layout.addWidget(
            Banner(
                "PackageKit gibi bir arka plan güncelleyici açıkken elle güncelleme "
                "kilit hatası verir. AX-Center bunu yakında kapatmayı önerecek (v1.1).",
                "info",
            )
        )
        self.layout.addWidget(section("Hibrit seçim", "yol haritası", Pill("v1.1", "muted")))
        self.layout.addWidget(
            muted(
                "Bir uygulamanın Debian kararlı sürümünü mü, yoksa Flatpak'in en güncel "
                "sürümünü mü istediğinizi seçebileceksiniz. Bu eşleme tablosu için paket "
                "adı ↔ Flatpak kimliği verisi gerekiyor; 1.0 sonrasına bırakıldı."
            )
        )
        self.layout.addStretch(1)

    def refresh(self) -> None:
        updates = self.backend.updates()
        apt, flatpak = updates.get("apt"), updates.get("flatpak")
        self.apt_card.set_value(
            "Bilinmiyor" if apt is None else f"{apt} paket",
            "apt listesi okunamadı" if apt is None else "apt / nala kaynakları",
        )
        self.flatpak_card.set_value(
            "Yok" if flatpak is None and not flatpak else (
                "Bilinmiyor" if flatpak is None else f"{flatpak} uygulama"
            ),
            "flatpak kurulu değil" if flatpak is None else "flatpak remote-ls --updates",
        )
        cfg = self.backend.config()
        enabled = bool(cfg.get("snapshot_before_update", True))
        self.snap_card.set_value(
            "Açık" if enabled else "Kapalı", "Yedekler sayfasından değiştirilir"
        )
        self.snap_pill.setText("etkin" if enabled else "kapalı")
        self.snap_pill.set_kind("ok" if enabled else "muted")
        self.last_card.set_value(datetime.now().strftime("%H:%M"), "bu oturumda · yerel saat")

    def check(self) -> None:
        self.toast("Güncellemeler denetleniyor…")
        self.refresh()
        updates = self.backend.updates()
        self.toast(f"{updates['apt']} Debian + {updates['flatpak']} Flatpak güncellemesi bulundu.")

    def upgrade(self) -> None:
        """Gerçek yükseltme: APT kancası önce snapshot alır, sonra paketler kurulur."""
        if not self.window:
            return
        updates = self.backend.updates()

        def count(value) -> str:
            # "bilinmiyor" durumu 0 diye gösterilmesin: bilmiyorsak söylemeyiz.
            return str(value) if isinstance(value, int) else "sayısı bilinmiyor"

        detail = (
            f"{count(updates.get('apt'))} Debian + {count(updates.get('flatpak'))} "
            "Flatpak güncellemesi kurulacak.\n\n"
            "Önce APT kancası otomatik bir Timeshift snapshot'ı alır (Yedekler "
            "sayfasındaki anahtar açıksa), sonra paketler yükseltilir.\n"
            "İşlem 10-30 dakika sürebilir ve internet bağlantısı ister. "
            "Kapanmadan bekleyin.\n\n"
            + ("(DEMO MODU — gerçek güncelleme yapılmaz.)\n\n" if self.backend.demo else "")
            + "Devam edilsin mi?"
        )
        answer = QMessageBox.warning(
            self,
            "Sistem güncellenecek",
            detail,
            QMessageBox.StandardButton.Cancel | QMessageBox.StandardButton.Yes,
            QMessageBox.StandardButton.Cancel,
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        if not self.window.runner.run(self.backend.pkg_upgrade):
            self.toast("Başka bir işlem sürüyor.", "danger")
            return
        self._set_busy(True)
        self.toast("Snapshot alınıyor, sonra güncelleme başlayacak…")
        self.window.runner.finished.connect(self._upgrade_done)
        self.window.runner.failed.connect(self._upgrade_failed)

    def _set_busy(self, busy: bool) -> None:
        self.btn_upgrade.setEnabled(not busy)
        self.btn_check.setEnabled(not busy)

    def _detach(self) -> None:
        for slot in (self._upgrade_done, self._upgrade_failed):
            try:
                self.window.runner.finished.disconnect(slot)
            except TypeError:
                pass
            try:
                self.window.runner.failed.disconnect(slot)
            except TypeError:
                pass

    def _upgrade_done(self, result) -> None:
        self._detach()
        self._set_busy(False)
        result = result if isinstance(result, dict) else {}
        steps = result.get("steps") or []
        ok = bool(result.get("ok"))
        self.steps.show_steps(
            steps or [{"label": "güncelleme", "status": "ok" if ok else "fail",
                       "detail": result.get("detail", "")}]
        )
        if ok and result.get("reboot_required"):
            self.toast("Güncelleme tamam. Yeniden başlatma öneriliyor.", "success")
        elif ok:
            self.toast("Güncelleme tamamlandı.", "success")
        else:
            self.toast(f"Güncelleme tamamlanamadı: {result.get('detail') or 'ayrıntı için adımlara bakın.'}", "danger")
        self.refresh()

    def _upgrade_failed(self, message: str) -> None:
        self._detach()
        self._set_busy(False)
        self.toast(message, "danger")
