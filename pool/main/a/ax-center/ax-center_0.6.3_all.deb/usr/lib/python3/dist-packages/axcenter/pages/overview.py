"""Genel Bakış: hero + ölçü kartları + mod zinciri + sağlık + profiller.

v0.6 "konsept" düzeni: solda etkin durumun özeti ve halka göstergesi, altında
üç ölçü kartı, sonra iki panel (mod zinciri / sistem sağlığı), profil şeridi ve
hızlı eylemler. Bütün değerler `backend`'den gelir; hiçbir sayı uydurulmaz.
"""

from __future__ import annotations

from datetime import datetime
from pathlib import Path

from PyQt6.QtWidgets import QGridLayout, QHBoxLayout, QLabel, QPushButton, QWidget

from ..format import duration, percent, relative_time
from ..widgets import (
    ChainRow,
    HealthRow,
    HeroCard,
    KpiCard,
    Page,
    Panel,
    Pill,
    ProfileCard,
    QuickAction,
    section,
    tag,
)

MAX_PROFILES = 4


def _clear(layout) -> None:
    """Alt widget'ları sil; yeniden çizimde birikmesin."""
    while layout.count():
        item = layout.takeAt(0)
        widget = item.widget()
        if widget is not None:
            widget.setParent(None)
            widget.deleteLater()
        elif item.layout() is not None:
            _clear(item.layout())


class OverviewPage(Page):
    title = "Genel Bakış"
    subtitle = "Anatol-X durumunun tek ekranda özeti."

    def build(self) -> None:
        # ---------------------------------------------------------------- hero
        self.hero = HeroCard()
        self.hero_eyebrow = self.hero.add_eyebrow("Etkin durum")
        self.hero_title = self.hero.title_label
        self.hero_sub = self.hero.sub_label
        self.hero_tags: QHBoxLayout = self.hero.tag_row
        self.ring = self.hero.ring

        self.btn_snapshot = QPushButton("Şimdi yedek al")
        self.btn_snapshot.setObjectName("primary")
        self.btn_snapshot.clicked.connect(self._snapshot_now)
        self.hero.add_action(self.btn_snapshot)

        self.btn_modes = QPushButton("Mod değiştir")
        self.btn_modes.clicked.connect(self._go_modes)
        self.hero.add_action(self.btn_modes)

        self.btn_check = QPushButton("Güncellemeleri denetle")
        self.btn_check.clicked.connect(self._check_updates)
        self.hero.add_action(self.btn_check)

        self.layout.addWidget(self.hero)

        # ------------------------------------------------------------ ölçüler
        self.upd_card = KpiCard("Güncellemeler", "↑")
        self.snap_card = KpiCard("Son yedek", "◷")
        self.disk_card = KpiCard("Disk", "▤")

        kpis = QHBoxLayout()
        kpis.setSpacing(14)
        for card in (self.upd_card, self.snap_card, self.disk_card):
            kpis.addWidget(card, 1)
        self.layout.addLayout(kpis)

        # ------------------------------------------------------------- paneller
        self.chain = Panel("Mod zinciri", "etkin profilin adımları")
        self.chain_body = self.chain.body

        self.health = Panel("Sistem sağlığı", "salt okunur")
        self.health_body = self.health.body

        panels = QHBoxLayout()
        panels.setSpacing(14)
        panels.addWidget(self.chain, 5)
        panels.addWidget(self.health, 4)
        self.layout.addLayout(panels)

        # -------------------------------------------------------------- profiller
        self.profiles_header = section("Profiller", "tek tık ile modlar sayfası")
        self.layout.addWidget(self.profiles_header)
        profiles = QWidget()
        self.profile_grid = QGridLayout(profiles)
        self.profile_grid.setContentsMargins(0, 0, 0, 0)
        self.profile_grid.setHorizontalSpacing(14)
        self.profile_grid.setVerticalSpacing(14)
        self.layout.addWidget(profiles)

        # ---------------------------------------------------------- hızlı eylemler
        self.layout.addWidget(section("Hızlı eylemler", "tek tık"))
        quick = QWidget()
        quick_row = QHBoxLayout(quick)
        quick_row.setContentsMargins(0, 0, 0, 0)
        quick_row.setSpacing(14)
        tiles = [
            ("◷", "Şimdi yedek al", "btrfs snapshot", self._snapshot_now),
            ("↑", "Güncellemeleri denetle", "apt + flatpak", self._check_updates),
            ("⚙", "Mod değiştir", "profil uygula", self._go_modes),
            ("⛭", "Sürücüleri tara", "donanım denetimi", self._go_drivers),
        ]
        for icon_text, title, sub, slot in tiles:
            tile = QuickAction(icon_text, title, sub)
            tile.clicked.connect(self._wrap(slot))
            quick_row.addWidget(tile, 1)
        self.layout.addWidget(quick)

        # --------------------------------------------------------------- durum
        self.layout.addWidget(section("Sistem durumu"))
        self.status = QLabel("Bilgiler okunuyor…")
        self.status.setObjectName("Faint")
        self.status.setWordWrap(True)
        self.layout.addWidget(self.status)
        self.layout.addStretch(1)

    # ------------------------------------------------------------- yardımcılar
    def _wrap(self, slot):
        def call() -> None:
            slot()

        return call

    def _go_modes(self) -> None:
        if self.window:
            self.window.go_to("modes")

    def _go_backups(self) -> None:
        if self.window:
            self.window.go_to("backups")

    def _go_drivers(self) -> None:
        if self.window:
            self.window.go_to("drivers")

    def _apply_profile(self, ident: str) -> None:
        """Profil kartına tıklama mod uygulamaz, modlar sayfasına götürür."""
        self.toast("Mod uygulamak için modlar sayfasındaki onayı kullanın.", "info")
        self._go_modes()
        if self.window and hasattr(self.window, "focus_mode"):
            self.window.focus_mode(ident)

    def _check_updates(self) -> None:
        self.toast("Güncellemeler denetleniyor…")
        result = self.backend.updates()
        self._set_updates(result)
        if result.get("unknown"):
            self.toast("Güncelleme listesi okunamadı (apt kilidi ya da araç eksik).", "danger")
        else:
            self.toast(
                f"{result['apt']} Debian + {result['flatpak']} Flatpak güncellemesi."
            )

    def _snapshot_now(self) -> None:
        if not self.window:
            return
        if not self.window.runner.run(self.backend.create_snapshot, "AX-Center: genel bakış"):
            self.toast("Başka bir işlem sürüyor.", "danger")
            return
        self.window.runner.finished.connect(self._snapshot_done)
        self.toast("Snapshot alınıyor…")

    def _snapshot_done(self, result) -> None:
        if self.window:
            try:
                self.window.runner.finished.disconnect(self._snapshot_done)
            except TypeError:
                pass
        if isinstance(result, dict) and result.get("ok"):
            self.toast("Snapshot alındı.", "success")
        else:
            detail = result.get("detail") if isinstance(result, dict) else str(result)
            self.toast(f"Snapshot alınamadı: {detail}", "danger")
        self.refresh()

    # ---------------------------------------------------------------- parçalar
    def _set_updates(self, updates: dict) -> None:
        from .. import theme

        c = theme.current()
        apt, flatpak = updates.get("apt"), updates.get("flatpak")
        if apt is None or flatpak is None:
            known = []
            if apt is not None:
                known.append(f"{apt} Debian")
            if flatpak is not None:
                known.append(f"{flatpak} Flatpak")
            self.upd_card.set_value(
                "Bilinmiyor",
                "güncelleme listesi okunamadı" + (f"  ·  {', '.join(known)}" if known else ""),
            )
            self.upd_card.set_segments([])
            self.upd_card.set_pill(Pill("okunamadı", "warn"))
            return
        total = apt + flatpak
        self.upd_card.set_value(
            f"{total} paket" if total else "Güncel",
            f"{apt} Debian  ·  {flatpak} Flatpak",
        )
        if total:
            self.upd_card.set_segments([(apt, c["accent"]), (flatpak, c["accent_2"])])
            self.upd_card.set_pill(Pill(f"{total}", "accent"))
        else:
            self.upd_card.set_segments([])
            self.upd_card.set_pill(Pill("güncel", "ok"))

    def _fill_chain(self, mode: dict | None) -> None:
        _clear(self.chain_body)
        if not mode or mode.get("broken"):
            self.chain.add_row(ChainRow("Mod seçili değil", "Modlar sayfasından bir profil uygulayın.", "", "muted"))
            return
        power = mode.get("power_profile") or "-"
        source = Path(mode.get("source") or "").name
        stopped = mode.get("stop_services") or []
        started = mode.get("start_services") or []
        rows: list[tuple[str, str, str, str]] = [
            ("Güç profili", power, "power-profiles-daemon", "accent"),
            ("EPP", mode.get("epp") or "dokunulmadı", source, "violet"),
            (
                "Servisler",
                f"{len(stopped)} durdurulur · {len(started)} başlatılır",
                "systemd",
                "muted",
            ),
            (
                "Rahatsız etme",
                "açık" if mode.get("dnd") else "kapalı",
                "plasmanotifyrc",
                "accent",
            ),
            ("Compositor", mode.get("compositor") or "auto", "oturum betiği", "violet"),
        ]

        rules = mode.get("flatpak_rules") or []
        if rules:
            offline = [r["app"] for r in rules if not r.get("network", True)]
            rows.append(
                (
                    "Flatpak ağı",
                    "çevrimdışı" if offline else "açık",
                    "flatpak override",
                    "muted",
                )
            )
        for title, value, when, kind in rows:
            self.chain.add_row(ChainRow(title, value, when, kind), divider=True)

    def _fill_profiles(self, modes: list[dict], current: str) -> None:
        _clear(self.profile_grid)
        usable = [m for m in modes if not m.get("broken")]
        # etkin profil şeridin başında görünsün
        usable.sort(key=lambda m: (m["id"] != current, m["name"]))
        shown = usable[:MAX_PROFILES]
        # profil yoksa (ör. /etc/anatol/contexts.d boş) başlık da görünmesin
        self.profiles_header.setVisible(bool(shown))
        if not shown:
            return
        for index, mode in enumerate(shown):
            card = ProfileCard(
                mode["id"],
                mode["name"],
                mode.get("description", ""),
                mode.get("power_profile", ""),
                active=mode["id"] == current,
            )
            card.clicked.connect(self._apply_profile)
            self.profile_grid.addWidget(card, index // MAX_PROFILES, index % MAX_PROFILES)
        for column in range(MAX_PROFILES):
            self.profile_grid.setColumnStretch(column, 1)

    def _fill_health(self, system: dict, snap_status: dict) -> None:
        _clear(self.health_body)
        mem_total = system.get("mem_total_gb", 0) or 1
        mem_used = system.get("mem_used_gb", 0)
        mem_pct = percent(mem_used, mem_total)
        mem_level = "danger" if mem_pct >= 90 else ("warn" if mem_pct >= 75 else "ok")

        mem = HealthRow("Bellek", f"{mem_used:.1f}/{mem_total:.0f} GB", mem_pct, mem_level)
        self.health.add_row(mem, divider=True)

        zram = HealthRow("ZRAM", f"{system.get('zram_gb', 0):.1f} GB")
        self.health.add_row(zram, divider=True)

        grub = snap_status.get("grub_btrfs", {})
        snap = HealthRow(
            "Yedek",
            f"{snap_status.get('count', 0)} adet",
        )
        snap.set_pill(
            Pill(
                "hazır" if snap_status.get("installed") else "yok",
                "ok" if snap_status.get("installed") else "warn",
            )
        )
        self.health.add_row(snap, divider=True)

        grub_row = HealthRow("grub-btrfs", grub.get("state") or "yok")
        grub_row.set_pill(Pill("açık" if grub.get("ok") else "kapalı", "ok" if grub.get("ok") else "muted"))
        self.health.add_row(grub_row, divider=True)

        session = HealthRow("Oturum", str(system.get("session", "-")).upper())
        session.set_pill(Pill(system.get("desktop", "-"), "muted"))
        self.health.add_row(session, divider=True)

        uptime = HealthRow("Çalışma", duration(system.get("uptime_h", 0) * 3600))
        uptime.set_pill(Pill(f"kernel {system.get('kernel', '-')}", "muted"))
        self.health.add_row(uptime)

    def _readiness(self, system: dict, snap_status: dict, updates: dict) -> tuple[int, str]:
        """Halka için gerçek denetimlerden türetilmiş hazırlık yüzdesi."""
        checks = [
            bool(snap_status.get("installed")),
            bool(snap_status.get("btrfs_layout_ok")),
            bool(snap_status.get("grub_btrfs", {}).get("ok")),
            bool(snap_status.get("last")),
            not updates.get("unknown"),
            int(system.get("disk_used_pct", 0)) < 90,
        ]
        passed = sum(1 for check in checks if check)
        return int(passed / len(checks) * 100), f"{passed}/{len(checks)} denetim tamam"

    # --------------------------------------------------------------- refresh
    def refresh(self) -> None:
        system = self.backend.system()
        mode_id = self.backend.current_mode()
        modes = self.backend.modes()
        mode = next((m for m in modes if m["id"] == mode_id), None)
        snap_status = self.backend.snapshot_status()
        updates = self.backend.updates()

        # --- hero
        if mode and not mode.get("broken"):
            self.hero_title.setText(mode["name"])
            self.hero_sub.setText(mode.get("description") or "Profil uygulandı.")
            _clear(self.hero_tags)
            self.hero_tags.addWidget(tag("güç profili", mode.get("power_profile") or "-"))
            self.hero_tags.addWidget(tag("compositor", mode.get("compositor") or "auto"))
            self.hero_tags.addWidget(tag("rahatsız etme", "açık" if mode.get("dnd") else "kapalı"))
            self.hero_tags.addStretch(1)
        else:
            self.hero_title.setText("Mod seçilmedi")
            self.hero_sub.setText(
                "Bir profil uygulandığında güç, servis ve bildirim ayarları birlikte değişir."
            )
            _clear(self.hero_tags)
            self.hero_tags.addWidget(tag("durum", "bekliyor"))
            self.hero_tags.addStretch(1)

        ready, ready_note = self._readiness(system, snap_status, updates)
        self.ring.set_value(ready, "hazır", ready_note)

        # --- ölçüler
        self._set_updates(updates)

        last = snap_status.get("last")
        if last:
            self.snap_card.set_value(
                relative_time(last.get("created")),
                (last.get("comment") or "etiket yok")[:52],
            )
            self.snap_card.set_pill(Pill("btrfs", "accent"))
        else:
            self.snap_card.set_value("Yok", "Henüz yedek alınmamış")
            self.snap_card.set_pill(Pill("boş", "warn"))

        disk_pct = int(system.get("disk_used_pct", 0))
        disk_level = "danger" if disk_pct >= 90 else ("warn" if disk_pct >= 75 else "ok")
        self.disk_card.set_value(
            f"%{disk_pct}",
            f"{system.get('disk_free_gb', 0):.1f} GB boş · "
            f"{system.get('disk_total_gb', 0):.1f} GB toplam",
        )
        self.disk_card.set_percent(disk_pct, disk_level)

        # --- paneller
        self._fill_chain(mode)
        self._fill_health(system, snap_status)
        self._fill_profiles(modes, mode_id)

        # --- alt durum satırı
        power = system.get("power", {})
        parts = [
            f"host {system.get('hostname', '-')}",
            f"güç {power.get('profile') or '-'}",
            f"governor {power.get('governor') or '-'}",
            f"yedek {snap_status.get('mode', '?')} · {snap_status.get('count', 0)} snapshot",
            f"güncelleme {datetime.now():%d.%m.%Y %H:%M}",
        ]
        if system.get("demo"):
            parts.append("DEMO MODU — örnek veriler, gerçek sisteme dokunulmuyor")
        self.status.setText("  ·  ".join(parts))
