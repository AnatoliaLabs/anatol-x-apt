"""Veri katmanı.

İki mod var:

* **canlı**: Anatol-X kurulu bir sistemde gerçek kaynaklardan okur ve
  değişiklikleri anatol-helper üzerinden yapar.
* **demo**: geliştirme makinesinde / canlı ISO'da olmayan bir sistemde
  arayüzü gerçekçi verilerle gösterir. Hiçbir şeyi değiştirmez.

Demo modu yalnızca "hiçbir araç yok" durumunda değil, `AX_CENTER_DEMO=1` ile
de zorlanabilir (tasarım üzerinde çalışırken işe yarıyor).
"""

from __future__ import annotations

import os
import re
import shutil
import subprocess
import time
from pathlib import Path


def _demo_env() -> bool:
    """Ortam değişkeni *okuma anında* değerlendirilir.

    Eskiden modül düzeyinde sabit okunuyordu; `ax-center --demo` bayrağı
    backend içe aktarıldıktan sonra ortamı yazdığı için hiç etkisiz kalıyordu
    (uygulama demo yerine "yardımcı yok → salt okunur" moduna düşüyordu).
    """
    return os.environ.get("AX_CENTER_DEMO") == "1"


def _helper_path() -> Path:
    """Yardımcının yolu tek yerden: anatol.util ile aynı kural.

    Eskiden burada sabit "/usr/libexec/anatol-helper" vardı; ANATOL_HELPER
    ortam değişkeni yok sayılıyordu ve iki ayrı doğruluk kaynağı oluşuyordu.
    """
    return Path(os.environ.get("ANATOL_HELPER") or "/usr/libexec/anatol-helper")


HELPER = _helper_path()
CONTEXT_DIRS = [Path("/etc/anatol/contexts.d"), Path(__file__).resolve().parent.parent / "etc/contexts.d"]


class Backend:
    def __init__(self) -> None:
        # Demo YALNIZCA açıkça istenirse (--demo / AX_CENTER_DEMO=1).
        # Eskiden "anatol-helper yoksa demo" idi: yarım kurulumda arayüz sessizce
        # uydurma veri gösteriyordu (12 güncelleme, sahte GPU, sahte yedek).
        # Bir işletim sisteminde bu, en tehlikeli hata sınıfı.
        self.demo = _demo_env()
        self.helper_ok = HELPER.exists()
        #: canlı ama yardımcı yok -> salt okunur, işlemler parola soramaz
        self.degraded = not self.demo and not self.helper_ok
        self._demo_mode = ""
        self._sys = None
        self._sys_import_error = ""

    # ---------------------------------------------------------------- probes
    def _anatol(self):
        if self._sys is not None:
            return self._sys
        try:
            import sys

            for extra in ("/usr/lib/python3/dist-packages", str(Path(__file__).resolve().parent.parent)):
                if extra not in sys.path:
                    sys.path.insert(0, extra)
            from anatol import contexts as ctx_mod
            from anatol import drivers, power, snapshots, userenv

            self._sys = (ctx_mod, snapshots, userenv, power, drivers)
        except Exception as exc:  # pragma: no cover - depends on install layout
            self._sys_import_error = str(exc)
            self._sys = False
        return self._sys

    # ------------------------------------------------------------------ modes
    def context_dir(self) -> Path | None:
        for directory in CONTEXT_DIRS:
            if directory.is_dir() and any(directory.glob("*.toml")):
                return directory
        return None

    def modes(self) -> list[dict]:
        lib = self._anatol()
        directory = self.context_dir()
        if lib and directory:
            ctx_mod = lib[0]
            return [c.as_dict() for c in ctx_mod.load_all(directory).values()]
        if self.demo:
            return DEMO_MODES
        return []

    def current_mode(self) -> str:
        if self.demo:
            # demo, gerçek kullanıcı durumunu okumaz ve yazmaz
            return self._demo_mode
        lib = self._anatol()
        if not lib:
            return ""
        try:
            return lib[2].load_state().get("mode", "")
        except Exception:
            return ""

    def apply_mode(self, ident: str) -> dict:
        """Blocking; pages run this in a worker thread."""
        if self.demo:
            time.sleep(0.4)
            # Diske yazmıyoruz: demo bir şey uygulamıyor, dolayısıyla "etkin mod"
            # kaydı da gerçek state'e girmemeli (yoksa yeniden açılışta yalan söyler).
            self._demo_mode = ident
            return {"ok": True, "demo": True, "steps": [
                {"label": "power-profiles-daemon → performance", "status": "ok", "detail": ""},
                {"label": "bluetooth.service: stop", "status": "ok", "detail": ""},
                {"label": "Rahatsız Etme → açık", "status": "ok", "detail": "plasmanotifyrc"},
            ]}
        from anatol import contexts as ctx_mod
        from anatol import helperclient, userenv

        ctx = ctx_mod.get(ident, self.context_dir() or ctx_mod.CONTEXT_DIR)
        result = helperclient.call("mode-apply", ident)
        steps = list(result.get("steps", []))
        steps += [userenv.set_dnd(ctx.dnd).as_dict()]
        steps += [userenv.set_compositor(ctx.compositor).as_dict()]
        steps += [s.as_dict() for s in userenv.apply_flatpak_rules(ctx.flatpak_rules)]
        prev = userenv.load_state().get("mode")
        if prev != ident:
            userenv.save_state(mode=ident, previous=prev, changed_at=int(time.time()))
        else:
            userenv.save_state(mode=ident, changed_at=int(time.time()))
        return {"ok": all(s["status"] != "fail" for s in steps), "steps": steps}

    # -------------------------------------------------------------- snapshots
    def snapshots(self) -> list[dict]:
        if self.demo:
            return DEMO_SNAPSHOTS
        lib = self._anatol()
        if lib:
            try:
                return lib[1].list_snapshots()
            except Exception:
                return []
        return DEMO_SNAPSHOTS if self.demo else []

    def snapshot_status(self) -> dict:
        if self.demo:
            return {
                "installed": True,
                "mode": "btrfs",
                "btrfs_layout_ok": True,
                "subvolumes": ["@", "@home"],
                "grub_btrfs": {"unit": "grub-btrfsd.service", "state": "active", "ok": True},
                "count": len(DEMO_SNAPSHOTS),
                "last": DEMO_SNAPSHOTS[0],
                "live_session": False,
            }
        lib = self._anatol()
        if lib:
            try:
                return lib[1].status()
            except Exception:
                pass
        if self.demo:
            return {
                "installed": True,
                "mode": "btrfs",
                "btrfs_layout_ok": True,
                "subvolumes": ["@", "@home"],
                "grub_btrfs": {"unit": "grub-btrfsd.service", "state": "active", "ok": True},
                "count": len(DEMO_SNAPSHOTS),
                "last": DEMO_SNAPSHOTS[0],
                "live_session": False,
            }
        return {"installed": False, "mode": "unknown", "btrfs_layout_ok": None, "count": 0,
                "last": None, "grub_btrfs": {"ok": False, "state": "inactive", "unit": ""},
                "subvolumes": [], "live_session": False}

    def create_snapshot(self, comment: str = "AX-Center") -> dict:
        if self.demo:
            time.sleep(0.6)
            return {"ok": True, "demo": True, "detail": "demo snapshot oluşturuldu"}
        from anatol import helperclient

        return helperclient.call("snapshot-create", comment, timeout=1900)

    def restore_snapshot(self, name: str) -> dict:
        if self.demo:
            time.sleep(0.5)
            return {"ok": True, "demo": True, "reboot_required": True,
                    "detail": "demo: geri yükleme simüle edildi"}
        from anatol import helperclient

        return helperclient.call("snapshot-restore", name, timeout=3600)

    def delete_snapshot(self, name: str) -> dict:
        if self.demo:
            return {"ok": True, "demo": True, "detail": "demo"}
        from anatol import helperclient

        return helperclient.call("snapshot-delete", name, timeout=1800)

    # ------------------------------------------------------- paket işlemleri
    def pkg_update(self) -> dict:
        """Paket listelerini yenile (nala/apt-get update). Yardımcı gerektirir."""
        if self.demo:
            time.sleep(0.6)
            return {"ok": True, "demo": True, "steps": [
                {"label": "paket listeleri güncellendi", "status": "ok", "detail": "demo"},
            ]}
        from anatol import helperclient

        return helperclient.call("pkg-update", timeout=1900)

    def pkg_upgrade(self) -> dict:
        """Tüm sistemi yükselt. Snapshot'ı APT kancası (ensure-pre-update) alır."""
        if self.demo:
            time.sleep(1.2)
            return {"ok": True, "demo": True, "steps": [
                {"label": "snapshot alındı (APT kancası)", "status": "ok",
                 "detail": "demo: 2026-11-13_15-10-22"},
                {"label": "güncelleme", "status": "ok", "detail": "demo: 1 Debian paketi yükseltildi"},
            ], "reboot_required": False}
        from anatol import helperclient

        return helperclient.call("pkg-upgrade", timeout=7300)

    def btrfs_scrub(self, mount: str = "/") -> dict:
        """Btrfs scrub (salt okuma taraması; veri silmez)."""
        if self.demo:
            time.sleep(1.0)
            return {"ok": True, "demo": True, "steps": [
                {"label": "btrfs scrub", "status": "ok",
                 "detail": "demo: 412.884 blok tarandı, 0 hata"},
            ]}
        from anatol import helperclient

        return helperclient.call("btrfs-scrub", mount, timeout=10900)

    # ----------------------------------------------------------------- system
    def system(self) -> dict:
        data = self._demo_system()
        data["demo"] = self.demo
        lib = self._anatol()
        if lib:
            try:
                live_power = lib[3].status()
                if live_power.get("driver") or not self.demo:
                    data["power"] = live_power
            except Exception:
                pass
        return data

    def _demo_system(self) -> dict:
        mem = _meminfo()
        zram = _zram()
        disk = shutil.disk_usage("/")
        return {
            "hostname": os.uname().nodename,
            "kernel": os.uname().release,
            "session": os.environ.get("XDG_SESSION_TYPE", "wayland"),
            "desktop": os.environ.get("XDG_CURRENT_DESKTOP", "KDE"),
            "mem_total_gb": round(mem.get("MemTotal", 16 * 1024 * 1024) / 1024 / 1024, 1),
            "mem_used_gb": round(
                (mem.get("MemTotal", 0) - mem.get("MemAvailable", 0)) / 1024 / 1024, 1
            ),
            "zram_gb": round(zram / 1024 / 1024 / 1024, 1),
            "disk_total_gb": round(disk.total / 1024**3, 1),
            "disk_free_gb": round(disk.free / 1024**3, 1),
            "disk_used_pct": round(disk.used / disk.total * 100),
            "uptime_h": round(_uptime() / 3600, 1),
            "power": {"driver": "amd-pstate-epp", "governor": "powersave",
                      "ppd_active": True, "profile": "balanced",
                      "governors_available": ["performance", "powersave"],
                      "epp": "balance_power", "intel_pstate": False, "amd_pstate": True},
            "updates": {"apt": 12, "flatpak": 3},
            "demo": self.demo,
        }

    # ------------------------------------------------------------------ misc
    def updates(self) -> dict:
        """apt/flatpak güncelleme sayısı.

        None = "okunamadı" (apt kilidi, ağ yok, araç yok). 0 = "gerçekten güncel".
        İkisini karıştırmak, kullanıcıya "Güncel" diye yalan söylemek demek.
        """
        if self.demo:
            return {"apt": 12, "flatpak": 3, "unknown": []}
        apt = self._count_apt_updates()
        flatpak = self._count_flatpak_updates()
        unknown = [name for name, value in (("apt", apt), ("flatpak", flatpak)) if value is None]
        return {"apt": apt, "flatpak": flatpak, "unknown": unknown}

    def _count_apt_updates(self) -> int | None:
        if not shutil.which("apt-get"):
            return None
        try:
            res = subprocess.run(
                ["apt-get", "-s", "-o", "Debug::NoLocking=1", "upgrade"],
                capture_output=True, text=True, timeout=60,
            )
        except Exception:
            return None
        if res.returncode != 0:
            return None
        return len(re.findall(r"^Inst ", res.stdout, re.M))

    def _count_flatpak_updates(self) -> int | None:
        if not shutil.which("flatpak"):
            return None
        try:
            res = subprocess.run(
                ["flatpak", "remote-ls", "--updates", "--columns=application"],
                capture_output=True, text=True, timeout=60,
            )
        except Exception:
            return None
        if res.returncode != 0:
            return None
        lines = [line for line in res.stdout.splitlines() if line.strip()]
        return max(0, len(lines) - 1)

    def drivers_plan(self) -> dict:
        """ADM: tespit + öneri. Demo modunda örnek donanımla aynı mantık çalışır."""
        lib = self._anatol()
        if lib and not self.demo:
            try:
                return lib[4].plan()
            except Exception as exc:
                return {"error": str(exc), "items": [], "devices": [], "packages": [],
                        "risk": "low", "secure_boot": {}, "tools": {}, "mok_files": []}
        if self.demo and lib:
            drivers = lib[4]
            devices = [
                drivers.Device("01:00.0", "0300", "VGA compatible controller", "10de", "2520",
                               "NVIDIA Corporation", "GA106M [GeForce RTX 3060 Mobile]", "nouveau"),
                drivers.Device("03:00.0", "0280", "Network controller", "8086", "2723",
                               "Intel Corporation", "Wi-Fi 6 AX200", "iwlwifi"),
            ]
            plan = drivers.plan(
                devices=devices,
                boot={"efi": True, "enabled": True, "state": "açık", "source": "demo"},
                detect={"available": True, "package": "nvidia-driver", "raw": "demo"},
            )
            plan["demo"] = True
            plan["tools"] = {"lspci": True, "nvidia_detect": True, "mokutil": True, "flatpak": True}
            return plan
        return {"items": [], "devices": [], "packages": [], "risk": "low",
                "secure_boot": {}, "tools": {}, "mok_files": []}

    def install_drivers(self, packages: list[str]) -> dict:
        """Blocking; sürücü kurulumu (snapshot → apt → MOK)."""
        if self.demo:
            time.sleep(1.0)
            steps = [
                {"label": "snapshot alındı", "status": "ok", "detail": "demo: 2026-11-13_14-50-00"},
                {"label": "paketler kuruldu: " + ", ".join(packages), "status": "ok", "detail": ""},
                {"label": "Secure Boot: MOK kaydı gerekiyor", "status": "fail",
                 "detail": "Yeniden başlatmadan önce: sudo mokutil --import /var/lib/shim-signed/mok/MOK.der"},
            ]
            return {"ok": True, "demo": True, "packages": packages, "steps": steps,
                    "reboot_required": True, "mok_required": True,
                    "mok_command": "mokutil --import /var/lib/shim-signed/mok/MOK.der"}
        from anatol import helperclient

        return helperclient.call("driver-install", *packages, timeout=7200)

    def log_bundle(self) -> dict:
        if self.demo:
            time.sleep(0.5)
            return {"ok": True, "demo": True, "path": str(Path.home() / "ax-center-report-demo.tar.gz")}
        from anatol import helperclient

        return helperclient.call("log-bundle")

    def set_config(self, key: str, value) -> dict:
        if self.demo:
            return {"ok": True, "demo": True, "steps": []}
        from anatol import helperclient

        return helperclient.call("config-set", key, str(value).lower() if isinstance(value, bool) else str(value))

    def config(self) -> dict:
        try:
            import tomllib

            with open("/etc/anatol/anatol.toml", "rb") as fh:
                return tomllib.load(fh)
        except Exception:
            return {"snapshot_before_update": True, "snapshot_min_interval_minutes": 15}


# --------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------
def _meminfo() -> dict:
    data = {}
    try:
        for line in Path("/proc/meminfo").read_text().splitlines():
            key, _, rest = line.partition(":")
            data[key] = int(rest.strip().split()[0])
    except (OSError, ValueError, IndexError):
        pass
    return data


def _zram() -> int:
    try:
        return int(Path("/sys/block/zram0/disksize").read_text().strip())
    except (OSError, ValueError):
        return 3_758_096_384


def _uptime() -> float:
    try:
        return float(Path("/proc/uptime").read_text().split()[0])
    except (OSError, ValueError, IndexError):
        return 0.0


DEMO_MODES = [
    {"id": "game", "name": "Oyun / Performans", "description": "Tam performans, arka plan gürültüsü kapalı.",
     "power_profile": "performance", "stop_services": ["bluetooth.service", "cups.service"],
     "start_services": [], "dnd": True, "compositor": "auto", "epp": "performance",
     "flatpak_rules": [], "activity": "", "broken": "", "source": "game.toml"},
    {"id": "work", "name": "İş / Geliştirici", "description": "Dengeli güç, yazıcı ve Bluetooth açık.",
     "power_profile": "balanced", "stop_services": [], "start_services": ["cups.service"],
     "dnd": False, "compositor": "on", "epp": "balance_performance",
     "flatpak_rules": [], "activity": "", "broken": "", "source": "work.toml"},
    {"id": "eco", "name": "Pil / Eco", "description": "Pil ömrü öncelikli.",
     "power_profile": "power-saver", "stop_services": ["bluetooth.service"],
     "start_services": [], "dnd": False, "compositor": "on", "epp": "power",
     "flatpak_rules": [], "activity": "", "broken": "", "source": "eco.toml"},
    {"id": "focus", "name": "Odak / Minimal", "description": "Bildirimler sessiz, sosyal uygulamalar çevrimdışı.",
     "power_profile": "balanced", "stop_services": [], "start_services": [], "dnd": True,
     "compositor": "on", "epp": "",
     "flatpak_rules": [{"app": "org.telegram.desktop", "network": False}],
     "activity": "", "broken": "", "source": "focus.toml"},
    {"id": "creative", "name": "Yaratıcı / Medya", "description": "Compositor ve yazıcı hazır.",
     "power_profile": "balanced", "stop_services": [], "start_services": ["cups.service"],
     "dnd": False, "compositor": "on", "epp": "", "flatpak_rules": [], "activity": "",
     "broken": "", "source": "creative.toml"},
]

def _demo_snapshots() -> list[dict]:
    """Demo verisi: zaman damgaları her açılışta "yeni" olacak şekilde üretilir."""
    now = int(time.time())
    rows = [
        (1 * 86400 + 3600, "O", "APT: güncelleme öncesi otomatik"),
        (3 * 86400 + 5400, "M", "elle: çekirdek denemesi öncesi"),
        (6 * 86400, "O", "APT: güncelleme öncesi otomatik"),
        (10 * 86400, "B", "beta öncesi temiz durum"),
    ]
    out = []
    for offset, tags, comment in rows:
        created = now - offset
        stamp = time.localtime(created)
        out.append(
            {
                "name": time.strftime("%Y-%m-%d_%H-%M-%S", stamp),
                "date": time.strftime("%Y-%m-%d", stamp),
                "time": time.strftime("%H:%M", stamp),
                "created": created,
                "tags": tags,
                "comment": comment,
                "kind": "btrfs",
                "location": "",
            }
        )
    return out


DEMO_SNAPSHOTS = _demo_snapshots()
