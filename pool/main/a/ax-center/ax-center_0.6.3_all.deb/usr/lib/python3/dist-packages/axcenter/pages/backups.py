"""Yedekler: Timeshift listesi, oluştur / geri yükle / sil, otomatik anahtar."""

from __future__ import annotations

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (
    QCheckBox,
    QHBoxLayout,
    QHeaderView,
    QMessageBox,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
)

from .. import theme
from ..format import relative_time
from ..widgets import (
    Banner,
    Card,
    EmptyState,
    MetricCard,
    Page,
    Pill,
    StepList,
    card_grid,
    muted,
    section,
)


class BackupsPage(Page):
    title = "Yedekler"
    subtitle = (
        "Timeshift altyapısı. Geri yükleme sistemi yeniden başlatır; öncesinde "
        "açık bir onay istenir."
    )

    def build(self) -> None:
        self.banner_box = QHBoxLayout()
        self.layout.addLayout(self.banner_box)

        self.mode_card = Card("Snapshot modu", "—")
        self.mode_pill = Pill("—", "muted")
        self.mode_card.add_pill(self.mode_pill)
        self.grub_card = Card("GRUB'dan dönüş", "—")
        self.grub_pill = Pill("—", "muted")
        self.grub_card.add_pill(self.grub_pill)
        self.last_card = Card("Son snapshot", "—")
        self.count_card = MetricCard("Toplam", "—", "", percent=None)
        self.layout.addLayout(
            card_grid([self.mode_card, self.grub_card, self.last_card, self.count_card], 2)
        )

        actions = QHBoxLayout()
        actions.setSpacing(8)
        self.btn_create = QPushButton("Şimdi yedek al")
        self.btn_create.setObjectName("primary")
        self.btn_create.clicked.connect(self.create)
        self.btn_restore = QPushButton("Geri yükle")
        self.btn_restore.setObjectName("danger")
        self.btn_restore.clicked.connect(self.restore)
        self.btn_delete = QPushButton("Sil")
        self.btn_delete.setObjectName("danger")
        self.btn_delete.clicked.connect(self.delete)
        for button in (self.btn_create, self.btn_restore, self.btn_delete):
            actions.addWidget(button)
        actions.addStretch(1)
        self.layout.addWidget(section("İşlemler", "seçili snapshot üzerinde"))
        self.layout.addLayout(actions)

        self.table = QTableWidget(0, 4)
        self.table.setHorizontalHeaderLabels(["Ne zaman", "Tarih", "Etiket", "Açıklama"])
        self.table.verticalHeader().setVisible(False)
        self.table.verticalHeader().setDefaultSectionSize(36)
        self.table.setAlternatingRowColors(True)
        self.table.setShowGrid(False)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QTableWidget.SelectionMode.SingleSelection)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(3, QHeaderView.ResizeMode.Stretch)
        header.setHighlightSections(False)
        header.setDefaultAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        self.table.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.layout.addWidget(section("Snapshot listesi", "en yeniden eskiye"))
        self.layout.addWidget(self.table)

        self.empty = EmptyState(
            "Henüz yedek yok.",
            "“Şimdi yedek al” ile ilk snapshot'ı oluşturun; güncellemelerden önce otomatik alınır.",
        )
        self.layout.addWidget(self.empty)

        self.auto = QCheckBox("Güncellemeden önce otomatik snapshot al")
        self.auto.stateChanged.connect(self.toggle_auto)
        self.layout.addWidget(self.auto)
        self.layout.addWidget(
            muted(
                "Bu anahtar APT kancasını yönetir. Canlı oturumda otomatik snapshot "
                "alınmaz; art arda dpkg çağrılarında 15 dakikalık alt sınır uygulanır."
            )
        )

        self.layout.addWidget(section("Son işlem"))
        self.steps = StepList()
        self.layout.addWidget(self.steps)
        self.layout.addStretch(1)
        self._loading_auto = False

    # ------------------------------------------------------------- rendering
    def refresh(self) -> None:
        status = self.backend.snapshot_status()
        kind = status.get("mode", "unknown")
        label = {"btrfs": "Btrfs", "rsync": "rsync", "unknown": "bilinmiyor"}.get(kind, kind)
        self.mode_card.set_value(label, "dosya sistemi modu")
        self.mode_pill.setText(kind if kind != "unknown" else "yok")
        self.mode_pill.set_kind(
            "ok" if kind == "btrfs" else ("warn" if kind == "rsync" else "muted")
        )

        grub = status.get("grub_btrfs", {})
        self.grub_card.set_value(
            "Hazır" if grub.get("ok") else "Hazır değil",
            f"{grub.get('unit') or 'grub-btrfs kurulu değil'}  ·  {grub.get('state', '-')}",
        )
        self.grub_pill.setText("etkin" if grub.get("ok") else "kapalı")
        self.grub_pill.set_kind("ok" if grub.get("ok") else "muted")

        last = status.get("last")
        if last:
            self.last_card.set_value(
                relative_time(last.get("created")),
                (last.get("comment") or "")[:56],
            )
        else:
            self.last_card.set_value("Yok", "Henüz yedek alınmamış")

        count = status.get("count", 0)
        self.count_card.set_value(
            str(count), "toplam snapshot · son 30 gün" if count else "henüz snapshot yok"
        )

        self._render_banner(status)
        self._fill_table()
        self._load_auto()
        self.btn_restore.setEnabled(self.table.rowCount() > 0)
        self.btn_delete.setEnabled(self.table.rowCount() > 0)

    def _render_banner(self, status: dict) -> None:
        while self.banner_box.count():
            item = self.banner_box.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        if not status.get("installed", False):
            self.banner_box.addWidget(
                Banner("Timeshift kurulu değil: sudo apt install timeshift", "danger")
            )
        elif status.get("mode") == "btrfs" and status.get("btrfs_layout_ok") is False:
            self.banner_box.addWidget(
                Banner(
                    "Btrfs modu seçili ama @ / @home alt hacimleri yok. Kurulum "
                    "Calamares mount.conf düzeltilmeden yapılmış; bu durumda Yedekler "
                    "çalışmaz. calamares/README.md dosyasına bakın.",
                    "danger",
                )
            )
        elif status.get("live_session"):
            self.banner_box.addWidget(
                Banner("Canlı oturumdasınız: otomatik snapshot kapalı.", "info")
            )

    def _fill_table(self) -> None:
        header_height = self.table.horizontalHeader().sizeHint().height()
        items = self.backend.snapshots()
        self.table.setRowCount(len(items))
        mono = theme.mono_font(8.5)
        for row, snap in enumerate(items):
            when = QTableWidgetItem(relative_time(snap.get("created")))
            when.setData(Qt.ItemDataRole.UserRole, snap.get("name"))
            date = QTableWidgetItem(f"{snap.get('date', '')} {snap.get('time', '')}")
            date.setFont(mono)
            tag = QTableWidgetItem(snap.get("tags") or "—")
            tag.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            comment = QTableWidgetItem(snap.get("comment", "") or "")
            for col, item in enumerate((when, date, tag, comment)):
                self.table.setItem(row, col, item)
        self.table.setVisible(bool(items))
        self.empty.setVisible(not items)
        # tablo, kaydırma alanı içinde "kesilmiş" görünmesin: satır sayısına göre boy
        rows = min(len(items), 6)
        body = sum(self.table.rowHeight(r) for r in range(rows))
        self.table.setFixedHeight(
            body + header_height + 2 * self.table.frameWidth() + 4
        )
        if items:
            self.table.selectRow(0)

    def selected_snapshot(self) -> str | None:
        row = self.table.currentRow()
        if row < 0:
            return None
        item = self.table.item(row, 0)
        return item.data(Qt.ItemDataRole.UserRole) if item else None

    def _load_auto(self) -> None:
        cfg = self.backend.config()
        self._loading_auto = True
        self.auto.setChecked(bool(cfg.get("snapshot_before_update", True)))
        self._loading_auto = False

    # --------------------------------------------------------------- actions
    def toggle_auto(self, _state: int) -> None:
        if self._loading_auto or not self.window:
            return
        if not self.window.runner.run(
            self.backend.set_config, "snapshot_before_update", self.auto.isChecked()
        ):
            self.toast("Başka bir işlem sürüyor.", "danger")
            return
        self.window.runner.finished.connect(self._auto_done)
        self.window.runner.failed.connect(self._auto_failed)

    def _detach(self, slot_done, slot_failed) -> None:
        if not self.window:
            return
        for signal, slot in (
            (self.window.runner.finished, slot_done),
            (self.window.runner.failed, slot_failed),
        ):
            try:
                signal.disconnect(slot)
            except TypeError:
                pass

    def _auto_done(self, result) -> None:
        self._detach(self._auto_done, self._auto_failed)
        ok = isinstance(result, dict) and result.get("ok")
        self.toast(
            "Otomatik snapshot ayarı kaydedildi." if ok else "Ayar kaydedilemedi.",
            "success" if ok else "danger",
        )
        self._load_auto()

    def _auto_failed(self, message: str) -> None:
        self._detach(self._auto_done, self._auto_failed)
        self.toast(message, "danger")
        self._load_auto()

    def create(self) -> None:
        if not self.window:
            return
        if not self.window.runner.run(self.backend.create_snapshot, "AX-Center: elle"):
            self.toast("Başka bir işlem sürüyor.", "danger")
            return
        self.toast("Snapshot alınıyor…")
        self.window.runner.finished.connect(self._create_done)
        self.window.runner.failed.connect(self._create_failed)

    def _create_done(self, result) -> None:
        self._detach(self._create_done, self._create_failed)
        ok = isinstance(result, dict) and result.get("ok")
        detail = result.get("detail", "") if isinstance(result, dict) else ""
        self.steps.show_steps(
            [{"label": "snapshot oluştur", "status": "ok" if ok else "fail", "detail": detail}]
        )
        self.toast("Snapshot alındı." if ok else f"Alınamadı: {detail}",
                   "success" if ok else "danger")
        self.refresh()

    def _create_failed(self, message: str) -> None:
        self._detach(self._create_done, self._create_failed)
        self.toast(message, "danger")

    def restore(self) -> None:
        name = self.selected_snapshot()
        if not name:
            self.toast("Önce listeden bir snapshot seçin.", "danger")
            return
        answer = QMessageBox.warning(
            self,
            "Snapshot geri yüklenecek",
            f"{name}\n\nSistem bu noktaya dönecek ve yeniden başlatılacak. "
            "O andan sonra yapılan değişiklikler kaybolur.\n\nDevam edilsin mi?",
            QMessageBox.StandardButton.Cancel | QMessageBox.StandardButton.Yes,
            QMessageBox.StandardButton.Cancel,
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        if not self.window or not self.window.runner.run(self.backend.restore_snapshot, name):
            return
        self.toast("Geri yükleme başladı…")
        self.window.runner.finished.connect(self._restore_done)
        self.window.runner.failed.connect(self._restore_failed)

    def _restore_done(self, result) -> None:
        self._detach(self._restore_done, self._restore_failed)
        ok = isinstance(result, dict) and result.get("ok")
        self.toast(
            "Geri yükleme tamamlandı — şimdi yeniden başlatın."
            if ok
            else "Geri yükleme başarısız.",
            "success" if ok else "danger",
        )
        self.refresh()

    def _restore_failed(self, message: str) -> None:
        self._detach(self._restore_done, self._restore_failed)
        self.toast(message, "danger")

    def delete(self) -> None:
        name = self.selected_snapshot()
        if not name:
            self.toast("Önce listeden bir snapshot seçin.", "danger")
            return
        answer = QMessageBox.question(
            self,
            "Snapshot silinsin mi?",
            f"{name} kalıcı olarak silinecek.",
            QMessageBox.StandardButton.Cancel | QMessageBox.StandardButton.Yes,
            QMessageBox.StandardButton.Cancel,
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        if not self.window or not self.window.runner.run(self.backend.delete_snapshot, name):
            return
        self.window.runner.finished.connect(self._delete_done)
        self.window.runner.failed.connect(self._delete_failed)

    def _delete_done(self, result) -> None:
        self._detach(self._delete_done, self._delete_failed)
        ok = isinstance(result, dict) and result.get("ok")
        self.toast("Snapshot silindi." if ok else "Silinemedi.",
                   "success" if ok else "danger")
        self.refresh()

    def _delete_failed(self, message: str) -> None:
        self._detach(self._delete_done, self._delete_failed)
        self.toast(message, "danger")
