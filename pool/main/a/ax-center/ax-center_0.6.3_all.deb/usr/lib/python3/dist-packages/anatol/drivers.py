"""ADM — Anatol Driver Manager.

Donanımı tespit eder, Debian 13 paket adlarıyla öneri üretir ve kurulumu
kontrollü biçimde yapar. Üç ilke:

1. **Tahmin etme, oku.** Öneri; `lspci -nnk`, `nvidia-detect`, `mokutil` ve
   `dkms` çıktısına dayanır. Tanınmayan donanım için paket uydurulmaz.
2. **Paket adları beyaz listeden geçer.** Yardımcı root olarak apt çağırıyor;
   oraya serbest metin gidemez. `firmware-*`, `nvidia-driver*` gibi kalıplar
   dışındaki her ad reddedilir.
3. **Geri dönüşü olmayan adım yok.** Kurulumdan önce snapshot alınır; canlı
   oturumda ve snapshot alınamayan durumda akış durur (kullanıcı açıkça
   istemedikçe).
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

from .util import AnatolError, Step, have, load_config, run

GPU_CLASSES = {"0300", "0302", "0380"}
NETWORK_CLASSES = {"0200", "0280"}

VENDORS = {
    "10de": "nvidia",
    "1002": "amd",
    "1022": "amd",
    "8086": "intel",
    "10ec": "realtek",
    "14e4": "broadcom",
    "168c": "atheros",
    "14c3": "mediatek",
    "11ab": "marvell",
}

WIFI_DRIVER_HINTS = ("iwlwifi", "ath", "rtw", "rtl", "b43", "brcmfmac", "mt7", "wl")

# Yardımcının kabul ettiği paket kalıpları. Buraya eklenmeyen hiçbir ad
# `driver-install` verb'ünden geçemez.
PACKAGE_PATTERNS = (
    r"^nvidia-driver$",
    r"^nvidia-driver-\d+$",
    r"^nvidia-driver-\d+-\d+$",
    r"^nvidia-kernel-support$",
    r"^nvidia-kernel-dkms$",
    r"^nvidia-dkms-\d+(-\d+)?$",
    r"^nvidia-tesla-\d+(-driver)?$",
    r"^firmware-[a-z0-9][a-z0-9-]{1,40}$",
    r"^broadcom-sta-dkms$",
    r"^rtw89-dkms$",
    r"^rtl8821ce-dkms$",
    r"^mesa-vulkan-drivers$",
    r"^intel-media-va-driver(-non-free)?$",
    r"^intel-gpu-tools$",
    r"^dkms$",
    r"^mokutil$",
    r"^linux-headers-amd64$",
)
_PKG_RE = [re.compile(pattern) for pattern in PACKAGE_PATTERNS]
_BAD_CHARS = re.compile(r"[\s;|&$`<>()\\\"'*?~]")

RISK_ORDER = {"low": 0, "medium": 1, "high": 2}


# --------------------------------------------------------------------------
# donanım taraması
# --------------------------------------------------------------------------
@dataclass
class Device:
    slot: str
    class_id: str
    class_name: str
    vendor_id: str
    device_id: str
    vendor: str
    device: str
    driver: str = ""
    modules: tuple[str, ...] = field(default_factory=tuple)

    @property
    def vendor_key(self) -> str:
        return VENDORS.get(self.vendor_id.lower(), "other")

    @property
    def is_gpu(self) -> bool:
        return self.class_id in GPU_CLASSES

    @property
    def is_wifi(self) -> bool:
        if self.class_id not in NETWORK_CLASSES:
            return False
        haystack = f"{self.class_name} {self.device} {self.driver}".lower()
        return "wireless" in haystack or "wi-fi" in haystack or "wifi" in haystack or any(
            hint in self.driver.lower() for hint in WIFI_DRIVER_HINTS
        )

    @property
    def is_ethernet(self) -> bool:
        return self.class_id in NETWORK_CLASSES and not self.is_wifi

    @property
    def label(self) -> str:
        return f"{self.vendor} {self.device}".strip()

    def as_dict(self) -> dict:
        return {
            "slot": self.slot,
            "class_id": self.class_id,
            "class_name": self.class_name,
            "vendor_id": self.vendor_id,
            "device_id": self.device_id,
            "vendor": self.vendor,
            "device": self.device,
            "driver": self.driver,
            "modules": list(self.modules),
            "label": self.label,
            "kind": "GPU" if self.is_gpu else ("Wi-Fi" if self.is_wifi else "Ağ"),
        }


_LSPCI_LINE = re.compile(
    r"^(?P<slot>[0-9a-fA-F]{2,4}:[0-9a-fA-F]{2}\.[0-7])\s+"
    r"(?P<cls>[^:\[]+?)\s*\[(?P<cls_id>[0-9a-fA-F]{4})\]:\s*(?P<rest>.+)$"
)
_IDS = re.compile(r"\[([0-9a-fA-F]{4}):([0-9a-fA-F]{4})\]\s*(?:\(rev [0-9a-fA-F]+\))?\s*$")


def parse_lspci(text: str) -> list[Device]:
    """`lspci -nnk` çıktısını Device listesine çevirir.

    Örnek satır:
      01:00.0 VGA compatible controller [0300]: NVIDIA Corporation GA106M
      [GeForce RTX 3060 Mobile] [10de:2520] (rev a1)
          Kernel driver in use: nouveau
          Kernel modules: nouveau, nvidia_current
    """
    devices: list[Device] = []
    current: Device | None = None
    for raw in text.splitlines():
        line = raw.rstrip()
        if not line:
            continue
        if line[0] in " \t":
            stripped = line.strip()
            key, _, value = stripped.partition(":")
            key = key.strip().lower()
            if current is None:
                continue
            if key == "kernel driver in use":
                current.driver = value.strip()
            elif key == "kernel modules":
                current.modules = tuple(
                    part.strip() for part in value.split(",") if part.strip()
                )
            continue

        match = _LSPCI_LINE.match(line)
        if not match:
            current = None
            continue
        rest = match.group("rest").strip()
        ids = _IDS.search(rest)
        if ids:
            vendor_id, device_id = ids.group(1).lower(), ids.group(2).lower()
            name = rest[: ids.start()].strip()
        else:
            vendor_id = device_id = ""
            name = rest
        vendor, _, device = name.partition(" ")
        # "NVIDIA Corporation GA106M ..." -> vendor "NVIDIA Corporation"
        if vendor.lower() in ("nvidia", "advanced", "intel", "realtek", "broadcom"):
            parts = name.split()
            vendor = " ".join(parts[:2]) if len(parts) > 1 and parts[1].lower() in (
                "corporation",
                "micro",
                "devices",
                "technologies",
            ) else parts[0]
            device = " ".join(name[len(vendor):].split())
        else:
            device = " ".join(name[len(vendor):].split()) or name

        current = Device(
            slot=match.group("slot"),
            class_id=match.group("cls_id").lower(),
            class_name=match.group("cls").strip(),
            vendor_id=vendor_id,
            device_id=device_id,
            vendor=vendor,
            device=device,
        )
        devices.append(current)
    return devices


def scan() -> list[Device]:
    if not have("lspci"):
        return []
    res = run(["lspci", "-nnk"], timeout=30)
    if res.returncode != 0:
        return []
    return parse_lspci(res.stdout)


# --------------------------------------------------------------------------
# sistem durumu
# --------------------------------------------------------------------------
def secure_boot() -> dict:
    """Secure Boot durumu. None = bilinmiyor (mokutil yok / EFI değil)."""
    efi = Path("/sys/firmware/efi").is_dir()
    if not efi:
        return {"efi": False, "enabled": False, "state": "EFI değil (BIOS)", "source": "sysfs"}
    if not have("mokutil"):
        return {"efi": True, "enabled": None, "state": "bilinmiyor (mokutil yok)", "source": ""}
    res = run(["mokutil", "--sb-state"], timeout=15)
    text = (res.stdout + res.stderr).strip()
    lowered = text.lower()
    if "enabled" in lowered and "disabled" not in lowered:
        return {"efi": True, "enabled": True, "state": "açık", "source": text}
    if "disabled" in lowered:
        return {"efi": True, "enabled": False, "state": "kapalı", "source": text}
    return {"efi": True, "enabled": None, "state": text or "bilinmiyor", "source": res.stderr.strip()}


def nvidia_detect() -> dict:
    """nvidia-detect varsa önerdiği paketi alır."""
    if not have("nvidia-detect"):
        return {"available": False, "package": "", "raw": ""}
    res = run(["nvidia-detect"], timeout=60)
    text = (res.stdout + res.stderr).strip()
    package = ""
    words = re.search(
        r"recommended to install the\s+(.+?)\s+package", text, re.IGNORECASE | re.DOTALL
    )
    if words:
        candidate = " ".join(words.group(1).split())
        if re.match(r"^[a-z0-9-]+$", candidate):
            package = candidate
    if not package:
        alt = re.search(r"^\s*(nvidia-[a-z0-9.\-]+)\s*$", text, re.MULTILINE)
        if alt:
            package = alt.group(1)
    return {"available": True, "package": package, "raw": text[-600:]}


def mok_candidates() -> list[str]:
    """Kurulum sonrası MOK olarak içe aktarılabilecek sertifika dosyaları."""
    paths = [
        "/var/lib/shim-signed/mok/MOK.der",
        "/var/lib/dkms/mok.der",
        "/var/lib/dkms/mok.pub",
    ]
    return [path for path in paths if Path(path).exists()]


def dkms_status() -> list[str]:
    if not have("dkms"):
        return []
    res = run(["dkms", "status"], timeout=60)
    return [line.strip() for line in res.stdout.splitlines() if line.strip()][:12]


# --------------------------------------------------------------------------
# öneriler
# --------------------------------------------------------------------------
def _item(ident: str, kind: str, hardware: str, packages, risk: str, reason: str, notes=None) -> dict:
    return {
        "id": ident,
        "kind": kind,
        "hardware": hardware,
        "packages": list(dict.fromkeys(packages)),
        "risk": risk,
        "reason": reason,
        "notes": list(notes or []),
    }


def recommend_gpu(device: Device, boot: dict, detect: dict | None = None) -> dict:
    key = device.vendor_key
    if key == "nvidia":
        detect = detect if detect is not None else nvidia_detect()
        packages = [detect["package"]] if detect.get("package") else ["nvidia-driver"]
        notes = []
        risk = "medium"
        if detect.get("package"):
            reason = f"nvidia-detect önerisi: {detect['package']} (kapalı kaynak, DKMS)"
        else:
            reason = "NVIDIA GPU. nvidia-detect kurulu değil; nvidia-driver varsayıldı."
            notes.append("Daha isabetli sonuç için: sudo apt install nvidia-detect")
        if device.driver == "nouveau":
            notes.append("Şu an açık kaynak nouveau sürücüsü yüklü.")
        if boot.get("enabled"):
            risk = "high"
            notes.append(
                "Secure Boot açık: DKMS ile derlenen modül imzalanmazsa yüklenmez. "
                "Kurulumdan sonra MOK kaydı gerekebilir."
            )
        elif boot.get("enabled") is None:
            notes.append("Secure Boot durumu okunamadı (mokutil yok). Kurulum sonrası "
                         "sürücü yüklenmezse ilk bakılacak yer burası.")
        return _item(f"gpu:{device.slot}", "GPU", device.label, packages, risk, reason, notes)

    if key == "amd":
        packages = ["firmware-amd-graphics", "mesa-vulkan-drivers"]
        notes = ["amdgpu çekirdek sürücüsü çekirdekle gelir; ek sürücü gerekmez."]
        if device.driver and device.driver != "amdgpu":
            notes.append(f"Etkin sürücü: {device.driver} — amdgpu'ya geçiş kernel parametresi gerektirebilir.")
        return _item(
            f"gpu:{device.slot}", "GPU", device.label, packages, "low",
            "AMD GPU: firmware ve Vulkan sürücüleri yeterli.", notes,
        )

    if key == "intel":
        packages = ["intel-media-va-driver"]
        notes = ["Donanım video kodlama için VA-API sürücüsü."]
        if device.driver and device.driver not in {"i915", "xe"}:
            notes.append(f"Etkin sürücü: {device.driver}")
        return _item(
            f"gpu:{device.slot}", "GPU", device.label, packages, "low",
            "Intel GPU: ek sürücü gerekmez, yalnızca VA-API.", notes,
        )

    return _item(
        f"gpu:{device.slot}", "GPU", device.label, [], "low",
        "Tanınmayan GPU üreticisi; otomatik paket önerilmedi.", ["Elle inceleme gerekir."],
    )


WIFI_FIRMWARE = {
    "intel": ("firmware-iwlwifi", "Intel Wi-Fi: firmware-iwlwifi yeterli."),
    "realtek": ("firmware-realtek", "Realtek: firmware-realtek; çok yeni çiplerde rtw89-dkms gerekebilir."),
    "atheros": ("firmware-atheros", "Atheros: firmware-atheros."),
    "mediatek": ("firmware-mediatek", "MediaTek: firmware-mediatek."),
    "broadcom": (
        "firmware-b43-installer",
        "Broadcom: çipe göre firmware-b43-installer ya da broadcom-sta-dkms gerekir.",
    ),
}


def recommend_wifi(device: Device, boot: dict) -> dict:
    key = device.vendor_key
    if key not in WIFI_FIRMWARE:
        return _item(
            f"wifi:{device.slot}", "Wi-Fi", device.label, [], "low",
            "Tanınmayan Wi-Fi çipi; paket önerilmedi.",
            [f"PCI kimliği: {device.vendor_id}:{device.device_id}"],
        )
    package, reason = WIFI_FIRMWARE[key]
    notes = []
    risk = "low"
    if device.driver:
        notes.append(f"Etkin çekirdek sürücüsü: {device.driver}.")
    if key == "broadcom":
        risk = "medium"
        notes.append("Broadcom'da yanlış seçim Wi-Fi'ı tamamen kapatabilir; "
                     "önce firmware-b43-installer denenmeli.")
    if risk != "low" and boot.get("enabled"):
        risk = "high"
        notes.append("Secure Boot açık: DKMS paketlerinde MOK kaydı gerekir.")
    return _item(f"wifi:{device.slot}", "Wi-Fi", device.label, [package], risk, reason, notes)


def plan(
    *,
    devices: list[Device] | None = None,
    boot: dict | None = None,
    detect: dict | None = None,
) -> dict:
    devices = scan() if devices is None else devices
    boot = secure_boot() if boot is None else boot
    detect = nvidia_detect() if detect is None else detect
    items: list[dict] = []
    for device in devices:
        if device.is_gpu:
            items.append(recommend_gpu(device, boot, detect))
        elif device.is_wifi:
            items.append(recommend_wifi(device, boot))

    packages: list[str] = []
    for item in items:
        packages += [pkg for pkg in item["packages"] if pkg not in packages]

    risk = "low"
    for item in items:
        if RISK_ORDER[item["risk"]] > RISK_ORDER[risk]:
            risk = item["risk"]

    return {
        "secure_boot": boot,
        "devices": [d.as_dict() for d in devices],
        "items": items,
        "packages": packages,
        "risk": risk,
        "requires_reboot": any(item["packages"] for item in items),
        "nvidia_detect": detect,
        "dkms": dkms_status(),
        "mok_files": mok_candidates(),
        "tools": {
            "lspci": have("lspci"),
            "nvidia_detect": have("nvidia-detect"),
            "mokutil": have("mokutil"),
            "flatpak": have("flatpak"),
        },
    }


# --------------------------------------------------------------------------
# kurulum (yalnızca root — yardımcı çağırır)
# --------------------------------------------------------------------------
def validate_packages(names) -> list[str]:
    """Beyaz liste denetimi. Geçersiz ad varsa hiçbir şey kurulmaz."""
    cleaned: list[str] = []
    for raw_name in names:
        name = (raw_name or "").strip()
        if not name or _BAD_CHARS.search(name):
            raise AnatolError(f"geçersiz paket adı: {name!r}")
        if not any(pattern.match(name) for pattern in _PKG_RE):
            raise AnatolError(
                f"bu paket sürücü kurulumu için izinli değil: {name!r}. "
                "İzinli kalıplar: firmware-*, nvidia-driver*, nvidia-kernel-*, dkms, mokutil."
            )
        cleaned.append(name)
    if not cleaned:
        raise AnatolError("kurulacak paket belirtilmedi")
    return list(dict.fromkeys(cleaned))


def _apt_env() -> dict:
    import os

    env = dict(os.environ)
    env.update(
        {
            "DEBIAN_FRONTEND": "noninteractive",
            "LC_ALL": "C.UTF-8",
            "APT_LISTCHANGES_FRONTEND": "none",
        }
    )
    return env


def install(names, *, dry_run: bool = False, allow_no_snapshot: bool = False) -> dict:
    """Paketleri kurar. Önce snapshot, sonra apt, en son MOK yönlendirmesi."""
    from . import snapshots

    packages = validate_packages(names)
    steps: list[Step] = []

    if snapshots.in_live_session() and not dry_run:
        return {
            "ok": False,
            "detail": "Canlı oturumda sürücü kurulumu yapılmaz.",
            "steps": [],
        }

    # 1) güvenlik ağı
    backup = snapshots.create("AX-Center: sürücü kurulumu öncesi", dry_run=dry_run)
    if backup.get("ok"):
        steps.append(Step("snapshot alındı", detail=backup.get("detail", "")[:160]))
    elif allow_no_snapshot:
        steps.append(
            Step("snapshot alınamadı", skipped=True, detail=backup.get("detail", "")[:160])
        )
    else:
        return {
            "ok": False,
            "detail": "Snapshot alınamadı, kurulum durduruldu: "
            + (backup.get("detail") or "bilinmeyen hata"),
            "steps": [s.as_dict() for s in steps],
        }

    # 2) kurulum
    lock_opts = ["-o", "DPkg::Lock::Timeout=120"]
    if have("nala"):
        cmd = ["nala", "install", "-y", *packages]
    else:
        cmd = ["apt-get", "install", "-y", *lock_opts, *packages]
    res = run(cmd, dry_run=dry_run, timeout=3600, env=_apt_env())
    tail = ((res.stderr or "") + (res.stdout or "")).strip().splitlines()
    steps.append(
        Step(
            "paketler kuruldu: " + ", ".join(packages),
            ok=res.returncode == 0,
            detail=(tail[-1][:220] if tail else ""),
        )
    )

    data = {
        "ok": res.returncode == 0,
        "packages": packages,
        "steps": [s.as_dict() for s in steps],
        "reboot_required": res.returncode == 0,
        "mok_required": False,
    }

    if res.returncode != 0 or dry_run:
        data["detail"] = (tail[-1] if tail else "") if res.returncode else ""
        return data

    # 3) MOK / DKMS durumu
    boot = secure_boot()
    status = dkms_status()
    if status:
        steps.append(Step("DKMS", detail="; ".join(status[:3])[:200]))
    files = mok_candidates()
    if boot.get("enabled") and files:
        data["mok_required"] = True
        data["mok_command"] = f"mokutil --import {files[0]}"
        steps.append(
            Step(
                "Secure Boot: MOK kaydı gerekiyor",
                ok=False,
                detail=f"Yeniden başlatmadan önce: sudo {data['mok_command']}",
            )
        )
    elif boot.get("enabled"):
        data["mok_required"] = True
        data["mok_command"] = "mokutil --import <dkms sertifikası>"
        steps.append(
            Step(
                "Secure Boot açık, sertifika bulunamadı",
                skipped=True,
                detail="DKMS sertifikası oluşmadıysa modül imzasız kalır; "
                "kurulum sonrası dkms status çıktısını inceleyin.",
            )
        )

    data["steps"] = [s.as_dict() for s in steps]
    data["detail"] = "Yeniden başlatma gerekiyor."
    return data


def is_allowed_package(name: str) -> bool:
    return bool(name) and not _BAD_CHARS.search(name) and any(
        pattern.match(name) for pattern in _PKG_RE
    )


def settings() -> dict:
    cfg = load_config()
    return {"auto_snapshot": bool(cfg.get("snapshot_before_update", True))}
