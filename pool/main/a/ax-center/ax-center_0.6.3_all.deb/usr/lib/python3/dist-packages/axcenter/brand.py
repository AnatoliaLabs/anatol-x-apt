"""Marka görseli: AX-Center simgesi — üç kontrol çubuğu (vektörel çizim).

Neden yazı yok: eski simge kutu içine "AX" harflerini fontla yazıyordu. Font
yoksa/ölçek küçükse glif dağılıyordu ve simge her masaüstünde aynı görünmüyordu.
Yeni simge yalnızca çizgi ve daireden oluşur: font gerekmez, 16 pikselde de
okunur, `debian/ax-center.svg` ile **aynı** koordinatları kullanır (tek kaynak:
aşağıdaki 64 birimlik ızgara).
"""

from __future__ import annotations

from PyQt6.QtCore import QPointF, QRectF, Qt
from PyQt6.QtGui import QColor, QLinearGradient, QPainter, QPen, QPixmap

#: 64×64 birimlik ızgarada simge geometrisi (debian/ax-center.svg ile birebir).
#: (çizgi başlangıcı x, y, çizgi bitişi x, düğme merkezi x) — y ortak.
SLIDERS = (
    (17.0, 20.5, 38.5, 42.5),
    (25.5, 32.0, 47.0, 21.5),
    (17.0, 43.5, 47.0, 32.0),
)
STROKE = 2.6       # çizgi kalınlığı (birim)
KNOB = 4.4         # düğme yarıçapı (birim)
TILE = 2.0         # gövdenin dış boşluğu (birim)
TILE_RADIUS = 12.5  # köşe yarıçapı (birim)
GRADIENT = ("#00d2ff", "#7b5cff")


def brand_pixmap(size: int = 38, radius: float | None = None) -> QPixmap:
    """Simgeyi verilen kenar uzunluğunda çiz (yüksek DPI için 2x)."""
    ratio = 2
    pix = QPixmap(size * ratio, size * ratio)
    pix.setDevicePixelRatio(ratio)
    pix.fill(Qt.GlobalColor.transparent)
    painter = QPainter(pix)
    painter.setRenderHint(QPainter.RenderHint.Antialiasing)
    # QPainter, devicePixelRatio'su 2 olan pixmap'e *mantıksal* koordinatta
    # çizer (Qt ölçeği kendisi uygular): geometri 0..size aralığına oturur.
    u = size / 64.0

    corner = TILE_RADIUS * u if radius is None else float(radius)
    tile = QRectF(TILE * u, TILE * u, (64 - 2 * TILE) * u, (64 - 2 * TILE) * u)
    gradient = QLinearGradient(tile.topLeft(), tile.bottomRight())
    gradient.setColorAt(0.0, QColor(GRADIENT[0]))
    gradient.setColorAt(1.0, QColor(GRADIENT[1]))
    painter.setPen(Qt.PenStyle.NoPen)
    painter.setBrush(gradient)
    painter.drawRoundedRect(tile, corner, corner)

    # Çizgiler SVG'deki gibi *kalemle* çizilir: yuvarlak uç (round cap) ve aynı
    # kalınlık. Böylece pencere simgesi ile masaüstü simgesi piksel piksel aynı.
    pen = QPen(QColor("#ffffff"))
    pen.setWidthF(STROKE * u)
    pen.setCapStyle(Qt.PenCapStyle.RoundCap)
    painter.setPen(pen)
    painter.setBrush(QColor("#ffffff"))
    for start_x, y, end_x, knob_x in SLIDERS:
        painter.drawLine(QPointF(start_x * u, y * u), QPointF(end_x * u, y * u))
        painter.setPen(Qt.PenStyle.NoPen)
        painter.drawEllipse(QPointF(knob_x * u, y * u), KNOB * u, KNOB * u)
        painter.setPen(pen)
    painter.end()
    return pix
