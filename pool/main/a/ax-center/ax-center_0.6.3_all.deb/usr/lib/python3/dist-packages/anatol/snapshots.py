"""Timeshift wrapper: the safety net behind every destructive action.

Timeshift itself is not reimplemented here. What this module adds is:

  * a reliable way to tell whether Timeshift's Btrfs mode can even work
    (the @/@home layout has to come from the installer, see calamares/),
  * a snapshot listing that does not depend on scraping CLI output when we
    can read the snapshot directories directly,
  * `ensure_pre_update()`, which replaces the old unconditional
    DPkg::Pre-Invoke one-liner: it is a no-op in a live session, it cannot
    recurse, and it can be switched off from the GUI.
"""

from __future__ import annotations

import fcntl
import json
import os
import re
import time
from pathlib import Path

from .util import Step, load_config, log, read_text, run

TS_CONFIG = Path("/etc/timeshift/timeshift.json")
BTRFS_SNAP_DIR = Path("/timeshift-btrfs/snapshots")
RSYNC_SNAP_DIR = Path("/timeshift/snapshots")
LOCK_FILE = Path("/run/anatol-snapshot.lock")
TS_TIME = re.compile(r"(\d{4}-\d{2}-\d{2})_(\d{2})-(\d{2})-(\d{2})")


def installed() -> bool:
    return run(["which", "timeshift"], timeout=10).returncode == 0


def config() -> dict:
    raw = read_text(TS_CONFIG)
    if not raw:
        return {}
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        return {}


def mode() -> str:
    """'btrfs', 'rsync' or 'unknown'."""
    raw = (config().get("btrfs_mode") or "").strip().lower()
    if raw == "true":
        return "btrfs"
    if raw == "false":
        return "rsync"
    fstype = run(["findmnt", "-no", "FSTYPE", "/"], timeout=10).stdout.strip()
    return "btrfs" if fstype == "btrfs" else "unknown"


def root_subvolumes() -> list[str]:
    res = run(["btrfs", "subvolume", "list", "/"], timeout=20)
    if res.returncode != 0:
        return []
    names = []
    for line in res.stdout.splitlines():
        parts = line.split()
        if "path" in parts:
            names.append(parts[parts.index("path") + 1])
    return names


def btrfs_layout_ok() -> bool:
    """Timeshift Btrfs mode needs the @ / @home layout from Calamares."""
    subs = root_subvolumes()
    if not subs:
        return False
    return any(s.strip("/") == "@" for s in subs) and any(
        s.strip("/") == "@home" for s in subs
    )


def grub_btrfs() -> dict:
    for unit in ("grub-btrfsd.service", "grub-btrfs.path", "grub-btrfs.service"):
        res = run(["systemctl", "is-active", unit], timeout=10)
        state = res.stdout.strip()
        if state and state != "inactive":
            return {"unit": unit, "state": state, "ok": state == "active"}
    return {"unit": "", "state": "inactive", "ok": False}


# --------------------------------------------------------------------------
# listing
# --------------------------------------------------------------------------
def _read_info(path: Path) -> dict:
    raw = read_text(path / "info.json")
    if not raw:
        return {}
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        return {}


def _parse_name(name: str) -> dict:
    match = TS_TIME.search(name)
    if not match:
        return {"name": name, "date": "", "time": "", "created": 0}
    date, hh, mm, ss = match.groups()
    stamp = f"{date} {hh}:{mm}:{ss}"
    try:
        created = int(time.mktime(time.strptime(stamp, "%Y-%m-%d %H:%M:%S")))
    except (ValueError, OverflowError):
        created = 0
    return {"name": name, "date": date, "time": f"{hh}:{mm}", "created": created}


def list_snapshots() -> list[dict]:
    """Newest first. Reads the filesystem when possible, CLI otherwise."""
    out: list[dict] = []
    for directory in (BTRFS_SNAP_DIR, RSYNC_SNAP_DIR):
        if not directory.is_dir():
            continue
        try:
            entries = [p for p in directory.iterdir() if p.is_dir()]
        except OSError:
            continue
        for entry in entries:
            info = _read_info(entry)
            item = _parse_name(entry.name)
            item.update(
                {
                    "tags": info.get("tags", ""),
                    "comment": info.get("comments", ""),
                    "location": str(entry),
                    "kind": "btrfs" if directory is BTRFS_SNAP_DIR else "rsync",
                }
            )
            out.append(item)
        if out:
            break

    if not out:
        out = _list_via_cli()

    out.sort(key=lambda s: (s.get("created", 0), s["name"]), reverse=True)
    return out


def _list_via_cli() -> list[dict]:
    if not installed():
        return []
    res = run(["timeshift", "--list", "--scripted"], timeout=120)
    items, seen = [], set()
    for line in res.stdout.splitlines():
        match = re.match(r"^\s*\d+\s*>?\s*(\d{4}-\d{2}-\d{2}_\d{2}-\d{2}-\d{2})", line)
        if not match:
            continue
        name = match.group(1)
        if name in seen:
            continue
        seen.add(name)
        item = _parse_name(name)
        item.update({"tags": "", "comment": "", "location": "", "kind": mode()})
        items.append(item)
    return items


def last_snapshot() -> dict | None:
    snaps = list_snapshots()
    return snaps[0] if snaps else None


# --------------------------------------------------------------------------
# actions (root)
# --------------------------------------------------------------------------
def create(comment: str = "AX-Center", *, dry_run: bool = False) -> dict:
    if not installed():
        return {"ok": False, "detail": "timeshift kurulu değil", "steps": []}
    if mode() == "btrfs" and not btrfs_layout_ok():
        return {
            "ok": False,
            "detail": "Btrfs modu etkin ama @/@home alt hacimleri yok. "
            "Calamares mount.conf düzeltilmeden Yedekler çalışmaz.",
            "steps": [],
        }
    cmd = ["timeshift", "--create", "--scripted", "--comments", comment[:120]]
    res = run(cmd, dry_run=dry_run, timeout=1800)
    detail = (res.stderr or res.stdout).strip().splitlines()
    step = Step(
        "snapshot oluştur",
        ok=res.returncode == 0,
        detail=detail[-1][:300] if detail else "",
    )
    return {"ok": step.ok, "detail": step.detail, "steps": [step.as_dict()]}


def delete(name: str, *, dry_run: bool = False) -> dict:
    if not TS_TIME.search(name or ""):
        return {"ok": False, "detail": f"geçersiz snapshot adı: {name!r}", "steps": []}
    res = run(["timeshift", "--delete", "--snapshot", name, "--scripted"], dry_run=dry_run, timeout=1800)
    step = Step(f"sil {name}", ok=res.returncode == 0, detail=(res.stderr or "").strip()[:300])
    return {"ok": step.ok, "detail": step.detail, "steps": [step.as_dict()]}


def restore(name: str, *, dry_run: bool = False) -> dict:
    if not TS_TIME.search(name or ""):
        return {"ok": False, "detail": f"geçersiz snapshot adı: {name!r}", "steps": []}
    res = run(
        ["timeshift", "--restore", "--snapshot", name, "--scripted", "--yes"],
        dry_run=dry_run,
        timeout=3600,
    )
    ok = res.returncode == 0
    step = Step(
        f"geri yükle {name}",
        ok=ok,
        detail=(res.stderr or res.stdout).strip()[-300:],
    )
    return {
        "ok": ok,
        "detail": step.detail,
        "reboot_required": ok,
        "steps": [step.as_dict()],
    }


# --------------------------------------------------------------------------
# the APT hook, done properly
# --------------------------------------------------------------------------
def in_live_session() -> bool:
    if Path("/run/live").exists() or Path("/lib/live/mount").exists():
        return True
    fstype = run(["findmnt", "-no", "FSTYPE", "/"], timeout=10).stdout.strip()
    return fstype in ("overlay", "squashfs", "tmpfs")


def ensure_pre_update(*, dry_run: bool = False) -> dict:
    """Called from /etc/apt/apt.conf.d/80-anatol-snapshot before dpkg runs.

    Returns {"ran": bool, "reason": str}. Never raises, never blocks a
    package operation: any failure is logged and ignored.
    """
    cfg = load_config()
    if not cfg.get("snapshot_before_update", True):
        return {"ran": False, "reason": "ayar kapalı (anatol.toml)"}
    if in_live_session():
        return {"ran": False, "reason": "canlı oturum — snapshot atlandı"}
    if not installed():
        return {"ran": False, "reason": "timeshift yok"}
    if mode() == "btrfs" and not btrfs_layout_ok():
        return {"ran": False, "reason": "@/@home alt hacimleri yok"}

    min_interval = int(cfg.get("snapshot_min_interval_minutes", 15)) * 60
    last = last_snapshot()
    if last and last.get("created") and time.time() - last["created"] < min_interval:
        return {"ran": False, "reason": "son snapshot çok yeni"}

    LOCK_FILE.parent.mkdir(parents=True, exist_ok=True)
    try:
        lock_fd = os.open(LOCK_FILE, os.O_CREAT | os.O_RDWR, 0o600)
    except OSError as exc:
        return {"ran": False, "reason": f"kilit açılamadı: {exc}"}
    try:
        try:
            fcntl.flock(lock_fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            return {"ran": False, "reason": "başka bir snapshot sürüyor"}
        result = create("APT: güncelleme öncesi otomatik", dry_run=dry_run)
        log(f"pre-update snapshot: {result.get('detail', '')}")
        return {"ran": result["ok"], "reason": result.get("detail", "")}
    finally:
        os.close(lock_fd)


def status() -> dict:
    return {
        "installed": installed(),
        "mode": mode(),
        "btrfs_layout_ok": btrfs_layout_ok() if mode() == "btrfs" else None,
        "subvolumes": root_subvolumes()[:12],
        "grub_btrfs": grub_btrfs(),
        "count": len(list_snapshots()),
        "last": last_snapshot(),
        "live_session": in_live_session(),
    }
