"""AX-Center — Anatol-X denetim masası (PyQt6)."""

APP_NAME = "AX-Center"
APP_ID = "ax-center"
VERSION = "0.6.3"
TAGLINE = "Anatol-X 1.0 Alpha"
