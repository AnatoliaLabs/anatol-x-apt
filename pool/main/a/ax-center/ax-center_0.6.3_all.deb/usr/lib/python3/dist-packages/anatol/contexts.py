"""Adaptive Context profiles ("modlar").

Profiles live in /etc/anatol/contexts.d/*.toml and are plain data: nothing
about a mode is hard coded in Python. A user can drop a new file in and it
shows up in the GUI and in `anatol-context list`.

Example
-------
    id = "game"
    name = "Oyun / Performans"
    power_profile = "performance"
    stop_services = ["bluetooth.service", "cups.service"]
    dnd = true
"""

from __future__ import annotations

import tomllib
from dataclasses import dataclass, field
from pathlib import Path

from .util import (
    CONTEXT_DIR,
    FLATPAK_RE,
    SERVICE_RE,
    SLUG_RE,
    load_toml,
    log,
)

VALID_POWER = ("performance", "balanced", "power-saver")
VALID_EPP = ("performance", "balance_performance", "balance_power", "power")
VALID_COMPOSITOR = ("auto", "on", "off")


class ContextError(ValueError):
    """Raised when a profile file is malformed."""


@dataclass(frozen=True)
class FlatpakRule:
    app: str
    network: bool | None = None  # False -> ağ erişimini kısıtla


@dataclass
class Context:
    id: str
    name: str
    description: str = ""
    icon: str = "preferences-system"
    power_profile: str = "balanced"
    epp: str = ""
    stop_services: tuple[str, ...] = field(default_factory=tuple)
    start_services: tuple[str, ...] = field(default_factory=tuple)
    dnd: bool = False
    compositor: str = "auto"
    flatpak_rules: tuple[FlatpakRule, ...] = field(default_factory=tuple)
    activity: str = ""
    source: Path | None = None
    broken: str = ""

    @property
    def ok(self) -> bool:
        return not self.broken

    def as_dict(self) -> dict:
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "icon": self.icon,
            "power_profile": self.power_profile,
            "epp": self.epp,
            "stop_services": list(self.stop_services),
            "start_services": list(self.start_services),
            "dnd": self.dnd,
            "compositor": self.compositor,
            "flatpak_rules": [
                {"app": r.app, "network": r.network} for r in self.flatpak_rules
            ],
            "activity": self.activity,
            "source": str(self.source) if self.source else "",
            "broken": self.broken,
        }


def _str_list(data: dict, key: str) -> tuple[str, ...]:
    raw = data.get(key, [])
    if isinstance(raw, str):
        raw = [raw]
    if not isinstance(raw, list):
        raise ContextError(f"{key} bir liste olmalı")
    out = []
    for item in raw:
        if not isinstance(item, str) or not SERVICE_RE.match(item.strip()):
            raise ContextError(f"{key} içinde geçersiz servis adı: {item!r}")
        out.append(item.strip())
    return tuple(dict.fromkeys(out))


def parse(data: dict, *, source: Path | None = None, slug: str | None = None) -> Context:
    ident = str(data.get("id") or slug or "").strip().lower()
    if not SLUG_RE.match(ident):
        raise ContextError(f"geçersiz mod kimliği: {ident!r}")
    name = str(data.get("name") or ident).strip()
    if not name:
        raise ContextError("name boş olamaz")

    power = str(data.get("power_profile", "balanced")).strip().lower()
    if power not in VALID_POWER:
        raise ContextError(
            f"power_profile {power!r} geçersiz (izinli: {', '.join(VALID_POWER)})"
        )

    epp = str(data.get("epp", "")).strip().lower()
    if epp and epp not in VALID_EPP:
        raise ContextError(f"epp {epp!r} geçersiz (izinli: {', '.join(VALID_EPP)})")

    compositor = str(data.get("compositor", "auto")).strip().lower()
    if compositor not in VALID_COMPOSITOR:
        raise ContextError("compositor auto|on|off olmalı")

    rules: list[FlatpakRule] = []
    raw_rules = data.get("flatpak_rules", [])
    if isinstance(raw_rules, dict):
        raw_rules = [
            {"app": k, **(v if isinstance(v, dict) else {})} for k, v in raw_rules.items()
        ]
    if not isinstance(raw_rules, list):
        raise ContextError("flatpak_rules bir liste olmalı")
    for item in raw_rules:
        if not isinstance(item, dict):
            raise ContextError("flatpak_rules girdileri tablo olmalı")
        app = str(item.get("app", "")).strip()
        if not FLATPAK_RE.match(app):
            raise ContextError(f"geçersiz flatpak uygulama kimliği: {app!r}")
        network = item.get("network")
        rules.append(FlatpakRule(app=app, network=None if network is None else bool(network)))

    ctx = Context(
        id=ident,
        name=name,
        description=str(data.get("description", "")).strip(),
        icon=str(data.get("icon", "preferences-system")).strip() or "preferences-system",
        power_profile=power,
        epp=epp,
        stop_services=_str_list(data, "stop_services"),
        start_services=_str_list(data, "start_services"),
        dnd=bool(data.get("dnd", False)),
        compositor=compositor,
        flatpak_rules=tuple(rules),
        activity=str(data.get("activity", "")).strip(),
        source=source,
    )

    overlap = set(ctx.stop_services) & set(ctx.start_services)
    if overlap:
        raise ContextError(
            "aynı servis hem durdurulan hem başlatılanlar içinde: "
            + ", ".join(sorted(overlap))
        )
    return ctx


def load(path) -> Context:
    path = Path(path)
    return parse(load_toml(path), source=path, slug=path.stem)


def load_all(directory=CONTEXT_DIR) -> dict[str, Context]:
    """Load every profile, keeping broken ones visible instead of hiding them."""
    directory = Path(directory)
    found: dict[str, Context] = {}
    if not directory.is_dir():
        return found
    for path in sorted(directory.glob("*.toml")):
        try:
            ctx = load(path)
        except (ContextError, OSError, tomllib.TOMLDecodeError) as exc:
            log(f"{path.name} yüklenemedi: {exc}")
            found[f"!{path.stem}"] = Context(
                id=path.stem, name=path.name, source=path, broken=str(exc)
            )
            continue
        if ctx.id in found:
            log(f"yinelenen mod kimliği {ctx.id} ({path.name}) yok sayıldı")
            continue
        found[ctx.id] = ctx
    return found


def get(ident: str, directory=CONTEXT_DIR) -> Context:
    """Load one profile by id, refusing anything that is not a plain slug."""
    if not SLUG_RE.match(ident or ""):
        raise ContextError(f"geçersiz mod kimliği: {ident!r}")
    path = Path(directory) / f"{ident}.toml"
    if not path.is_file():
        raise ContextError(f"mod bulunamadı: {ident}")
    return load(path)
