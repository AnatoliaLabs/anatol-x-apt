"""Gizlilik: telemetri durumu, flatpak izinleri, güvenlik duvarı."""

from __future__ import annotations

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import QLabel, QPushButton

from ..widgets import Card, Page, Pill, card_grid, muted, section


class PrivacyPage(Page):
    title = "Gizlilik"
    subtitle = "Telemetri yok — ve bunu iddia etmek yerine kurulu paketlerden doğrularız."

    def build(self) -> None:
        self.telemetry_card = Card("Telemetri", "—", "kurulu paketler üzerinden doğrulanır")
        self.telemetry_pill = Pill("—", "muted")
        self.telemetry_card.add_pill(self.telemetry_pill)
        self.fw_card = Card("Güvenlik duvarı", "—", "ufw yönetimi v1.1'de")
        self.fw_card.add_pill(Pill("v1.1", "muted"))
        self.flatpak_card = Card(
            "Flatpak izinleri", "—", "mod kuralları bugünden çalışıyor"
        )
        self.flatpak_card.add_pill(Pill("v1.x", "muted"))
        self.layout.addLayout(
            card_grid([self.telemetry_card, self.fw_card, self.flatpak_card], 2)
        )

        self.layout.addWidget(
            section("Telemetri denetimi", "yalnızca kurulu paketler", self._verify_button())
        )
        self.layout.addWidget(
            muted(
                "Kontrol edilenler: kde-telemetry, apport, popularity-contest, "
                "systemd-coredump raporlaması, snapd. Sonuç tahmin değil, "
                "dpkg-query çıktısıdır."
            )
        )
        self.detail = QLabel("")
        self.detail.setObjectName("Mono")
        self.detail.setWordWrap(True)
        self.layout.addWidget(self.detail)

        self.layout.addWidget(section("Güvenlik duvarı ve izinler", "yol haritası"))
        self.roadmap = Card(
            "Neler açık, neler planlı",
            "İzin görüntüleyici 1.x",
            "Flatseal benzeri basit izin görüntüleyici 1.x'e bırakıldı. ufw aç/kapat "
            "v1.1'de. Bugün çalışan: modlar sayfasındaki flatpak_rules — odak modunda "
            "seçili uygulamaların ağ erişimi kapatılabiliyor.",
        )
        self.roadmap.add_action(Pill("bugün çalışıyor", "ok"))
        self.layout.addWidget(self.roadmap)
        self.layout.addStretch(1)

    def _verify_button(self) -> QPushButton:
        self.btn_verify = QPushButton("Yeniden doğrula")
        self.btn_verify.setObjectName("ghost")
        self.btn_verify.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_verify.clicked.connect(self.verify)
        return self.btn_verify

    def verify(self) -> None:
        self.refresh()
        self.toast("Telemetri denetimi tamamlandı.")

    def refresh(self) -> None:
        found = self._suspects()
        if found:
            self.telemetry_card.set_value("İncele", "bulunan: " + ", ".join(found))
            self.telemetry_pill.setText("dikkat")
            self.telemetry_pill.set_kind("warn")
        else:
            self.telemetry_card.set_value(
                "Yok", "kurulu paketlerde telemetri aracı bulunmadı"
            )
            self.telemetry_pill.setText("temiz")
            self.telemetry_pill.set_kind("ok")
        self.fw_card.set_value("Kapalı", "ufw yönetimi v1.1'de açılacak")
        self.flatpak_card.set_value("Moda bağlı", "flatpak_rules profil dosyalarında")
        self.detail.setText(
            "sonuç: " + (", ".join(found) if found else "şüpheli paket yok")
        )

    def _suspects(self) -> list[str]:
        """Yalnızca gerçekten kurulu olanları söyle; tahmin yürütme."""
        import shutil
        import subprocess

        suspects = {
            "kde-telemetry": "kde-telemetry",
            "apport": "apport",
            "popularity-contest": "popularity-contest",
            "snapd": "snapd",
        }
        if not shutil.which("dpkg-query"):
            return []
        try:
            out = subprocess.run(
                ["dpkg-query", "-W", "-f=${Package} ${Status}\n"],
                capture_output=True, text=True, timeout=20,
            ).stdout
        except Exception:
            return []
        installed = {
            line.split()[0]
            for line in out.splitlines()
            if line.endswith("install ok installed")
        }
        return [name for pkg, name in suspects.items() if pkg in installed]
