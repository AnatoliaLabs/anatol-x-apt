"""Sistem: ZRAM, Btrfs bakımı, oturum, servisler."""

from __future__ import annotations

from PyQt6.QtWidgets import QHBoxLayout, QMessageBox, QPushButton

from ..widgets import Card, Page, Pill, StepList, card_grid, section


class SystemPage(Page):
    title = "Sistem"
    subtitle = "ZRAM, Btrfs bakımı, oturum tipi ve servisler."

    def build(self) -> None:
        self.zram_card = Card("ZRAM", "—")
        self.session_card = Card("Oturum", "—")
        self.kernel_card = Card("Çekirdek", "—")
        self.btrfs_card = Card("Btrfs", "—")
        self.layout.addLayout(
            card_grid([self.zram_card, self.session_card, self.kernel_card, self.btrfs_card], 2)
        )

        actions = QHBoxLayout()
        actions.setSpacing(8)
        self.btn_scrub = QPushButton("Btrfs scrub başlat")
        self.btn_scrub.setObjectName("primary")
        self.btn_scrub.clicked.connect(self.scrub)
        actions.addWidget(self.btn_scrub)
        actions.addStretch(1)
        self.layout.addWidget(section("Bakım"))
        self.layout.addLayout(actions)
        self.steps = StepList()
        self.layout.addWidget(self.steps)

        self.layout.addWidget(section("Yol haritası", "canlı sistem üzerinde henüz açılmadı"))

        self.services_card = Card(
            "Servis yöneticisi",
            "Planlı",
            "Servis listesi ve aç/kapat. Şimdilik: systemctl list-units --type=service",
        )
        self.services_card.add_pill(Pill("v1.1", "muted"))
        self.session_cfg_card = Card(
            "Oturum seçimi",
            "Planlı",
            "Wayland/X11 varsayılanı /etc/sddm.conf.d içinden gelir; yanlış ayar "
            "oturumu açılmaz yapabildiği için bu yazma işi v1.1'e bırakıldı.",
        )
        self.session_cfg_card.add_pill(Pill("v1.1", "muted"))
        self.layout.addLayout(card_grid([self.services_card, self.session_cfg_card], 2))
        self.layout.addStretch(1)

    def refresh(self) -> None:
        system = self.backend.system()
        power = system.get("power", {})
        self.zram_card.set_value(f"{system['zram_gb']:.1f} GB", "zram0 · zstd")
        self.session_card.set_value(system["session"].upper(), system["desktop"])
        self.kernel_card.set_value(system["kernel"], f"uptime {system['uptime_h']:.1f} sa")
        snap = self.backend.snapshot_status()
        if snap.get("mode") == "btrfs":
            self.btrfs_card.set_value(
                "Alt hacim düzeni var" if snap.get("btrfs_layout_ok") else "Düzen eksik",
                "scrub elle çalıştırılabilir",
            )
        else:
            self.btrfs_card.set_value("Btrfs değil", f"mod: {snap.get('mode')}")
        self._power = power

    def scrub(self) -> None:
        """Btrfs scrub: salt okuma taraması, veri silmez; sonucu burada gösterilir."""
        if not self.window:
            return
        answer = QMessageBox.warning(
            self,
            "Btrfs scrub başlatılacak",
            "Kök dosya sistemi (/ ) baştan sona taranacak.\n\n"
            "Bu bir salt okuma işlemidir: veri silinmez, dosyalar değişmez. "
            "Disk büyüklüğüne göre 10 dakika - 2 saat sürer ve bu sürede disk "
            "daha çok çalışır.\n\n"
            + ("(DEMO MODU — gerçek tarama yapılmaz.)\n\n" if self.backend.demo else "")
            + "Başlatılsın mı?",
            QMessageBox.StandardButton.Cancel | QMessageBox.StandardButton.Yes,
            QMessageBox.StandardButton.Cancel,
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        if not self.window.runner.run(self.backend.btrfs_scrub, "/"):
            self.toast("Başka bir işlem sürüyor.", "danger")
            return
        self.btn_scrub.setEnabled(False)
        self.toast("scrub çalışıyor… (uzun sürebilir)")
        self.window.runner.finished.connect(self._scrub_done)
        self.window.runner.failed.connect(self._scrub_failed)

    def _detach(self) -> None:
        for slot in (self._scrub_done, self._scrub_failed):
            try:
                self.window.runner.finished.disconnect(slot)
            except TypeError:
                pass
            try:
                self.window.runner.failed.disconnect(slot)
            except TypeError:
                pass

    def _scrub_done(self, result) -> None:
        self._detach()
        self.btn_scrub.setEnabled(True)
        result = result if isinstance(result, dict) else {}
        ok = bool(result.get("ok"))
        self.steps.show_steps(
            result.get("steps")
            or [{"label": "btrfs scrub", "status": "ok" if ok else "fail",
                 "detail": result.get("detail", "")}]
        )
        self.toast("scrub tamamlandı." if ok else
                   f"scrub tamamlanamadı: {result.get('detail') or 'adımlara bakın'}",
                   "success" if ok else "danger")
        self.refresh()

    def _scrub_failed(self, message: str) -> None:
        self._detach()
        self.btn_scrub.setEnabled(True)
        self.toast(message, "danger")
