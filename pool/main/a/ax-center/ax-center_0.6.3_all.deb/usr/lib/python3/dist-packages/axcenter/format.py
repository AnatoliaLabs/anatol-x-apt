"""İnsan diliyle biçimlendirme: "Dün 21:40", "3 gün önce", "12,4 GB"."""

from __future__ import annotations

import time
from datetime import datetime


def relative_time(stamp: int | float | None) -> str:
    """Zaman damgasını Türkçe, kısa ve okunur biçime çevirir."""
    if not stamp:
        return "—"
    now = time.time()
    delta = now - float(stamp)
    if delta < -60:
        return datetime.fromtimestamp(stamp).strftime("%d.%m.%Y %H:%M")
    if delta < 60:
        return "az önce"
    if delta < 3600:
        return f"{int(delta // 60)} dk önce"

    when = datetime.fromtimestamp(stamp)
    today = datetime.fromtimestamp(now).date()
    days = (today - when.date()).days
    if days == 0:
        return f"bugün {when:%H:%M}"
    if days == 1:
        return f"dün {when:%H:%M}"
    if days < 7:
        return f"{days} gün önce {when:%H:%M}"
    if when.year == today.year:
        return when.strftime("%d.%m %H:%M")
    return when.strftime("%d.%m.%Y")


def size_gb(value: float) -> str:
    """GB değerini okunur biçimde verir (1 ondalık)."""
    return f"{value:.1f} GB"


def duration(seconds: float) -> str:
    seconds = max(0, int(seconds))
    hours, rest = divmod(seconds, 3600)
    minutes = rest // 60
    if hours >= 24:
        return f"{hours // 24} gün {hours % 24} saat"
    if hours:
        return f"{hours} saat {minutes} dk"
    return f"{minutes} dk"


def tr_upper(text: str) -> str:
    """Türkçe kurallarına uygun büyük harf (i → İ, ı → I)."""
    return text.replace("i", "İ").replace("ı", "I").upper()


def percent(part: float, total: float) -> int:
    if not total:
        return 0
    return round(part / total * 100)
