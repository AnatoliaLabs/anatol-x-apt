"""Talk to /usr/libexec/anatol-helper, asking polkit for permission once.

The GUI and the CLIs both go through here, so there is exactly one place
that knows how privilege escalation happens.

Exit codes returned by the helper / pkexec:
    126  kullanıcı parola istemini iptal etti
    127  yetki verilmedi ya da yardımcı bulunamadı
"""

from __future__ import annotations

import json
import os

from .util import HELPER, IS_ROOT, AnatolError, run


def helper_available() -> bool:
    return os.access(HELPER, os.X_OK)


def call(verb: str, *args: str, dry_run: bool = False, timeout: int = 3600) -> dict:
    """Run one helper verb and return its JSON answer.

    Raises AnatolError with a Turkish, actionable message on failure.
    """
    if not dry_run and not helper_available():
        raise AnatolError(
            "anatol-helper bulunamadı. Kurulum eksik: sudo apt install --reinstall ax-center"
        )
    cmd = [HELPER] if IS_ROOT else ["pkexec", HELPER]
    cmd += [verb, *[str(a) for a in args], "--json"]
    res = run(cmd, dry_run=dry_run, timeout=timeout)

    if dry_run:
        return {"ok": True, "verb": verb, "steps": [], "dry_run": True}

    if res.returncode == 126:
        raise AnatolError("İşlem iptal edildi (parola istemi kapatıldı).")
    if res.returncode == 124:
        # run() kendi zaman aşımında öldürdü: genelde polkit ajanı yok ya da
        # yanıt vermiyor. Kullanıcı "zaman aşımı" gibi belirsiz bir metin değil,
        # ne yapacağını görmeli.
        raise AnatolError(
            "Yetki istemi yanıtsız kaldı. Polkit ajanı çalışmıyor olabilir "
            "(KDE: polkit-kde-agent-1). Oturumu kapatıp açmayı deneyin."
        )
    if res.returncode == 127:
        raise AnatolError(
            "Yetki verilmedi. Yardımcının kurulu ve polkit kuralının yerinde "
            "olduğundan emin olun."
        )

    payload = _parse(res.stdout)
    if payload is None:
        payload = {
            "ok": res.returncode == 0,
            "verb": verb,
            "steps": [],
            "detail": (res.stderr or res.stdout).strip()[:500],
        }
    payload.setdefault("ok", res.returncode == 0)
    return payload


def _parse(text: str) -> dict | None:
    text = (text or "").strip()
    if not text:
        return None
    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        # tolerate stray lines before the JSON document
        start = text.find("{")
        if start < 0:
            return None
        try:
            data = json.loads(text[start:])
        except json.JSONDecodeError:
            return None
    return data if isinstance(data, dict) else None
