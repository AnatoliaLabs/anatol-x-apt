"""Sürücüler (ADM): tespit → öneri → snapshot'lı kurulum → MOK yönlendirmesi."""

from __future__ import annotations

from PyQt6.QtCore import Qt
from PyQt6.QtGui import QGuiApplication
from PyQt6.QtWidgets import (
    QHBoxLayout,
    QLabel,
    QMessageBox,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from ..widgets import Banner, Card, Page, Pill, StepList, muted, section

RISK_LABEL = {"low": "düşük risk", "medium": "orta risk", "high": "yüksek risk"}
RISK_KIND = {"low": "ok", "medium": "accent", "high": "danger"}


class DeviceCard(Card):
    def __init__(self, device: dict) -> None:
        driver = device.get("driver") or "sürücü yüklü değil"
        modules = ", ".join(device.get("modules") or [])
        hint = f"çekirdek sürücüsü: {driver}"
        if modules:
            hint += f"  ·  modüller: {modules}"
        super().__init__(device.get("kind", "Donanım"), device.get("label", "?"), hint)
        # GPU/Wi-Fi adları uzun: 15pt'lik başlık kartı şişiriyor.
        super().set_small_value(True)
        super().add_pill(Pill(device.get("slot", ""), "muted"))


class RecommendationCard(Card):
    def __init__(self, item: dict) -> None:
        packages = ", ".join(item.get("packages") or []) or "paket önerilmedi"
        reason = item.get("reason", "")
        hardware = item.get("hardware", "?")
        hint = f"{hardware}  ·  {reason}" if reason else hardware
        super().__init__("Önerilen paket", packages, hint)
        super().set_small_value(True)
        self.item = item
        super().add_pill(Pill(RISK_LABEL.get(item.get("risk", "low"), "?"),
                              RISK_KIND.get(item.get("risk", "low"), "muted")))
        for note in item.get("notes", []):
            label = QLabel(f"•  {note}")
            label.setWordWrap(True)
            label.setObjectName("Muted")
            super().add_widget(label)


class DriversPage(Page):
    title = "Sürücüler"
    subtitle = (
        "ADM (Anatol Driver Manager): GPU ve Wi-Fi çipini okur, Debian 13 paket "
        "adlarıyla öneri üretir, kurulumdan önce snapshot alır."
    )

    def build(self) -> None:
        self.top_row = QHBoxLayout()
        self.top_row.setSpacing(8)
        self.sb_pill = Pill("Secure Boot: —", "muted")
        self.scan_pill = Pill("tarama —", "muted")
        self.btn_rescan = QPushButton("Yeniden tara")
        self.btn_rescan.clicked.connect(self.refresh)
        self.top_row.addWidget(self.sb_pill)
        self.top_row.addWidget(self.scan_pill)
        self.top_row.addStretch(1)
        self.top_row.addWidget(self.btn_rescan)
        self.layout.addLayout(self.top_row)

        self.banner_box = QVBoxLayout()
        self.layout.addLayout(self.banner_box)

        self.layout.addWidget(section("Donanım"))
        self.devices_box = QWidget()
        self.devices_layout = QVBoxLayout(self.devices_box)
        self.devices_layout.setContentsMargins(0, 0, 0, 0)
        self.devices_layout.setSpacing(12)
        self.layout.addWidget(self.devices_box)

        self.layout.addWidget(section("Öneri"))
        self.items_box = QWidget()
        self.items_layout = QVBoxLayout(self.items_box)
        self.items_layout.setContentsMargins(0, 0, 0, 0)
        self.items_layout.setSpacing(12)
        self.layout.addWidget(self.items_box)

        actions = QHBoxLayout()
        actions.setSpacing(8)
        self.btn_install = QPushButton("Önerilenleri kur")
        self.btn_install.setObjectName("primary")
        self.btn_install.clicked.connect(self.install)
        self.btn_install.setEnabled(False)
        actions.addWidget(self.btn_install)
        actions.addStretch(1)
        self.layout.addWidget(section("Kurulum"))
        self.layout.addLayout(actions)
        self.layout.addWidget(
            muted(
                "Kurulum sırası: snapshot → apt (nala varsa nala) → DKMS/MOK denetimi. "
                "Sürücü değişikliği yeniden başlatma ister. Canlı oturumda kurulum kapalıdır."
            )
        )

        self.layout.addWidget(section("Son işlem"))
        self.steps = StepList()
        self.layout.addWidget(self.steps)

        self.mok_card = Card("Secure Boot / MOK", "—")
        self.mok_command = QLabel("")
        self.mok_command.setObjectName("Accent")
        self.mok_command.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        self.mok_command.setWordWrap(True)
        self.mok_card.add_widget(self.mok_command)
        btn_copy = QPushButton("Komutu kopyala")
        btn_copy.clicked.connect(self.copy_mok)
        self.mok_card.add_action(btn_copy)
        self.mok_card.setVisible(False)
        self.layout.addWidget(self.mok_card)

        self.layout.addStretch(1)
        self._plan: dict = {}

    # ------------------------------------------------------------- rendering
    def refresh(self) -> None:
        self._plan = self.backend.drivers_plan()
        self._render_pills()
        self._render_banner()
        self._render_devices()
        self._render_items()
        packages = self._plan.get("packages") or []
        self.btn_install.setText(
            f"Önerilenleri kur ({len(packages)} paket)" if packages else "Kurulacak paket yok"
        )
        self.btn_install.setEnabled(bool(packages))

    def _render_pills(self) -> None:
        boot = self._plan.get("secure_boot") or {}
        state = boot.get("state", "bilinmiyor")
        enabled = boot.get("enabled")
        if enabled is True:
            self.sb_pill.setText(f"Secure Boot: {state}")
            self.sb_pill.set_kind("danger")
        elif enabled is False:
            self.sb_pill.setText(f"Secure Boot: {state}")
            self.sb_pill.set_kind("ok")
        else:
            self.sb_pill.setText(f"Secure Boot: {state}")
            self.sb_pill.set_kind("muted")

        tools = self._plan.get("tools") or {}
        missing = [name for name, ok in tools.items() if not ok]
        self.scan_pill.setText(
            "tarama: gerçek" if not missing else "eksik araç: " + ", ".join(missing)
        )
        self.scan_pill.set_kind("ok" if not missing else "muted")

    def _render_banner(self) -> None:
        while self.banner_box.count():
            item = self.banner_box.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        if self._plan.get("error"):
            self.banner_box.addWidget(Banner(f"Tarama hatası: {self._plan['error']}", "danger"))
            return
        boot = self._plan.get("secure_boot") or {}
        if boot.get("enabled") and self._plan.get("risk") in ("medium", "high"):
            self.banner_box.addWidget(
                Banner(
                    "Secure Boot açık ve önerilen sürücü DKMS ile derleniyor. Kurulumdan "
                    "sonra MOK kaydı yapılmazsa modül yüklenmez ve ekran/VPN gibi "
                    "şeyler çalışmayabilir. AX-Center adımı atlamaz, komutu verir.",
                    "danger",
                )
            )
        if boot.get("efi") and boot.get("enabled") is None:
            self.banner_box.addWidget(
                Banner(
                    "Secure Boot durumu okunamadı. `sudo apt install mokutil` sonrası "
                    "Yeniden tara.",
                    "info",
                )
            )

    def _clear(self, layout: QVBoxLayout) -> None:
        while layout.count():
            item = layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

    def _render_devices(self) -> None:
        self._clear(self.devices_layout)
        devices = self._plan.get("devices") or []
        if not devices:
            self.devices_layout.addWidget(
                muted("Donanım okunamadı. `pciutils` kurulu mu? (lspci)")
            )
            return
        for device in devices:
            self.devices_layout.addWidget(DeviceCard(device))

    def _render_items(self) -> None:
        self._clear(self.items_layout)
        items = self._plan.get("items") or []
        if not items:
            self.items_layout.addWidget(muted("Öneri üretilecek GPU/Wi-Fi bulunamadı."))
            return
        for item in items:
            self.items_layout.addWidget(RecommendationCard(item))

    # --------------------------------------------------------------- actions
    def install(self) -> None:
        packages = self._plan.get("packages") or []
        if not packages or not self.window:
            return
        risk = RISK_LABEL.get(self._plan.get("risk", "low"), "?")
        detail = (
            f"Kurulacak paketler:\n    {', '.join(packages)}\n\n"
            f"Risk: {risk}\n"
            "Önce Timeshift snapshot alınacak, sonra paketler kurulacak ve "
            "sistem yeniden başlatma isteyecek.\n\n"
            + ("(DEMO MODU — gerçek kurulum yapılmaz.)\n\n" if self.backend.demo else "")
            + "Devam edilsin mi?"
        )
        answer = QMessageBox.warning(
            self,
            "Sürücü kurulumu",
            detail,
            QMessageBox.StandardButton.Cancel | QMessageBox.StandardButton.Yes,
            QMessageBox.StandardButton.Cancel,
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        if not self.window.runner.run(self.backend.install_drivers, packages):
            self.toast("Başka bir işlem sürüyor.", "danger")
            return
        self.btn_install.setEnabled(False)
        self.toast("Snapshot alınıyor, sonra paketler kurulacak…")
        self.window.runner.finished.connect(self._on_done)
        self.window.runner.failed.connect(self._on_failed)

    def _detach(self) -> None:
        if not self.window:
            return
        for signal, slot in (
            (self.window.runner.finished, self._on_done),
            (self.window.runner.failed, self._on_failed),
        ):
            try:
                signal.disconnect(slot)
            except TypeError:
                pass

    def _on_done(self, result) -> None:
        self._detach()
        self.btn_install.setEnabled(True)
        if not isinstance(result, dict):
            return
        self.steps.show_steps(result.get("steps", []), "Adım kaydı yok.")
        if result.get("mok_command"):
            self.mok_card.setVisible(True)
            self.mok_card.set_value(
                "Kayıt gerekli" if result.get("mok_required") else "Kontrol edildi",
                "Yeniden başlatmadan önce sertifikayı içe aktarın, sonra MOK menüsünde onaylayın.",
            )
            self.mok_command.setText("sudo " + result["mok_command"])
        if result.get("ok"):
            prefix = "DEMO: " if result.get("demo") else ""
            self.toast(
                prefix
                + "Kurulum tamam. Yeniden başlatın; Secure Boot açıksa MOK adımını atlamayın."
            )
        else:
            self.toast(result.get("detail") or "Kurulum başarısız.", "danger")
        self.refresh()

    def _on_failed(self, message: str) -> None:
        self._detach()
        self.btn_install.setEnabled(True)
        self.steps.show_steps([{"label": message, "status": "fail"}])
        self.toast(message, "danger")

    def copy_mok(self) -> None:
        text = self.mok_command.text().strip()
        if text:
            QGuiApplication.clipboard().setText(text)
            self.toast("Komut panoya kopyalandı.")
