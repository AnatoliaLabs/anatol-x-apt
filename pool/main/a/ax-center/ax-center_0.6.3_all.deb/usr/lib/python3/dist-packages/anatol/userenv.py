"""Desktop-side bits of a mode switch: DND, Flatpak overrides, KWin.

These run as the *logged in user* on purpose. The root helper must never
touch files in $HOME: doing so would leave root-owned files in the user's
config and break the session later.
"""

from __future__ import annotations

import json
import os
from pathlib import Path

from .util import USER_STATE_DIR, Step, have, read_text, run, write_text

CONFIG_HOME = Path(os.environ.get("XDG_CONFIG_HOME") or Path.home() / ".config")
PLASMA_NOTIFY = CONFIG_HOME / "plasmanotifyrc"
STATE_FILE = USER_STATE_DIR / "state.json"

DND_FAR_FUTURE = "2099-12-31T23:59:59"
DND_OFF = "1970-01-01T00:00:01"


# --------------------------------------------------------------------------
# KDE configuration access (works on Plasma 5 and 6)
# --------------------------------------------------------------------------
def _kde_tool(kind: str) -> str | None:
    for name in (f"{kind}config6", f"{kind}config5", f"{kind}config"):
        if have(name):
            return name
    return None


def kread(file: str, group: str, key: str, default: str = "") -> str:
    tool = _kde_tool("kread")
    if not tool:
        return default
    res = run([tool, "--file", file, "--group", group, "--key", key], timeout=10)
    return res.stdout.strip() if res.returncode == 0 else default


def kwrite(file: str, group: str, key: str, value: str, *, dry_run: bool = False) -> bool:
    tool = _kde_tool("kwrite")
    if not tool:
        return False
    res = run(
        [tool, "--file", file, "--group", group, "--key", key, value],
        dry_run=dry_run,
        timeout=10,
    )
    return res.returncode == 0


# --------------------------------------------------------------------------
# Do Not Disturb
# --------------------------------------------------------------------------
def dnd_enabled() -> bool:
    until = kread("plasmanotifyrc", "DoNotDisturb", "Until")
    return bool(until) and until > "2030-01-01"


def set_dnd(enabled: bool, *, dry_run: bool = False) -> Step:
    """Plasma stores DND as an end timestamp in plasmanotifyrc.

    plasmashell watches that file, so writing it is enough; there is no
    D-Bus call for this in Plasma 5/6. Known good on Plasma 6.3+.
    """
    if not PLASMA_NOTIFY.exists() and not _kde_tool("kwrite"):
        return Step(
            "Rahatsız Etme",
            skipped=True,
            detail="KDE araçları bulunamadı (kwriteconfig)",
        )
    value = DND_FAR_FUTURE if enabled else DND_OFF
    if dry_run:
        return Step(f"Rahatsız Etme → {'aç' if enabled else 'kapat'}", detail="[dry-run]")
    if not kwrite("plasmanotifyrc", "DoNotDisturb", "Until", value):
        return Step(
            "Rahatsız Etme",
            ok=False,
            detail="plasmanotifyrc yazılamadı",
        )
    # Plasma 6 also keeps a boolean in the notifications applet config.
    kwrite("plasmanotifyrc", "DoNotDisturb", "Enabled", "true" if enabled else "false")
    return Step(
        f"Rahatsız Etme → {'açık' if enabled else 'kapalı'}",
        detail="plasmanotifyrc güncellendi",
    )


# --------------------------------------------------------------------------
# KWin compositor (X11 only)
# --------------------------------------------------------------------------
def session_type() -> str:
    value = (os.environ.get("XDG_SESSION_TYPE") or "").lower()
    if value:
        return value
    res = run(["loginctl", "show-session", "self", "-p", "Type", "--value"], timeout=10)
    return res.stdout.strip().lower() or "unknown"


def _qdbus() -> str | None:
    for name in ("qdbus6", "qdbus-qt6", "qdbus"):
        if have(name):
            return name
    return None


def set_compositor(mode: str, *, dry_run: bool = False) -> Step:
    if mode == "auto":
        return Step("Compositor", skipped=True, detail="değiştirilmedi (auto)")
    if session_type() != "x11":
        return Step(
            "Compositor",
            skipped=True,
            detail="Wayland oturumunda kapatılamaz (KWin kısıtı)",
        )
    tool = _qdbus()
    if not tool:
        return Step("Compositor", skipped=True, detail="qdbus bulunamadı")
    action = "suspend" if mode == "off" else "resume"
    res = run(
        [tool, "org.kde.KWin", "/Compositor", f"org.kde.kwin.Compositing.{action}"],
        dry_run=dry_run,
        timeout=15,
    )
    return Step(
        f"Compositor → {'kapalı' if mode == 'off' else 'açık'}",
        ok=res.returncode == 0,
        detail=(res.stderr or "").strip()[:200],
    )


# --------------------------------------------------------------------------
# Flatpak overrides
# --------------------------------------------------------------------------
def flatpak_installed() -> bool:
    return have("flatpak")


def override_network(app: str, network: bool | None, *, dry_run: bool = False) -> Step:
    if network is None:
        return Step(f"{app}", skipped=True, detail="kural yok")
    flag = "--share=network" if network else "--unshare=network"
    res = run(["flatpak", "override", "--user", flag, app], dry_run=dry_run, timeout=60)
    word = "açık" if network else "kapalı"
    return Step(
        f"{app}: ağ erişimi {word}",
        ok=res.returncode == 0,
        detail=(res.stderr or "").strip()[:200],
    )


def apply_flatpak_rules(rules, *, dry_run: bool = False) -> list[Step]:
    if not flatpak_installed():
        if not rules:
            return []
        return [Step("Flatpak izinleri", skipped=True, detail="flatpak kurulu değil")]
    return [override_network(r.app, r.network, dry_run=dry_run) for r in rules]


# --------------------------------------------------------------------------
# mode state, so "geri dön" is possible
# --------------------------------------------------------------------------
def save_state(**values) -> None:
    data = load_state()
    data.update({k: v for k, v in values.items() if v is not None})
    try:
        write_text(STATE_FILE, json.dumps(data, ensure_ascii=False, indent=2), mode=0o600)
    except OSError:
        pass


def load_state() -> dict:
    raw = read_text(STATE_FILE)
    if not raw:
        return {}
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        return {}
