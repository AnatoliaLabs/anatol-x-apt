"""AX-Center sayfaları."""

from .about import AboutPage
from .backups import BackupsPage
from .drivers import DriversPage
from .modes import ModesPage
from .overview import OverviewPage
from .privacy import PrivacyPage
from .software import SoftwarePage
from .system import SystemPage

__all__ = [
    "AboutPage",
    "BackupsPage",
    "DriversPage",
    "ModesPage",
    "OverviewPage",
    "PrivacyPage",
    "SoftwarePage",
    "SystemPage",
]
