"""Arayüz bileşenleri: kart, metrik kartı, rozet, şerit, adım listesi, sayfa."""

from __future__ import annotations

import html
from typing import ClassVar

from PyQt6.QtCore import QRectF, QSize, Qt, pyqtSignal
from PyQt6.QtGui import QColor, QConicalGradient, QFont, QPainter, QPen
from PyQt6.QtWidgets import (
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QProgressBar,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
)

from . import theme
from .format import tr_upper


# --------------------------------------------------------------------------
# küçük yardımcılar
# --------------------------------------------------------------------------
def label(text: str, object_name: str = "", *, wrap: bool = False) -> QLabel:
    widget = QLabel(text)
    if object_name:
        widget.setObjectName(object_name)
    widget.setWordWrap(wrap)
    return widget


def muted(text: str) -> QLabel:
    return label(text, "Muted", wrap=True)


def faint(text: str) -> QLabel:
    return label(text, "Faint", wrap=True)


def mono(text: str, object_name: str = "Mono") -> QLabel:
    widget = QLabel(text)
    widget.setObjectName(object_name)
    widget.setFont(theme.mono_font(8.5))
    widget.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
    return widget


def hairline() -> QFrame:
    line = QFrame()
    line.setObjectName("Hairline")
    line.setFixedHeight(1)
    return line


class Pill(QLabel):
    """Küçük durum rozeti (pastil)."""

    TONES: ClassVar[dict[str, str]] = {
        "ok": "ok",
        "danger": "danger",
        "warn": "warn",
        "accent": "accent",
        "muted": "muted",
        "neutral": "muted",
    }

    def __init__(self, text: str, kind: str = "muted", parent=None) -> None:
        super().__init__(text, parent)
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.setSizePolicy(QSizePolicy.Policy.Maximum, QSizePolicy.Policy.Fixed)
        self.set_kind(kind)

    def set_kind(self, kind: str) -> None:
        c = theme.current()
        tones = {
            "ok": (c["ok"], c["ok_soft"]),
            "danger": (c["danger"], c["danger_soft"]),
            "warn": (c["warn"], c["warn_soft"]),
            "accent": (c["accent_text"], c["accent_soft"]),
            "muted": (c["text_dim"], c["row"]),
        }
        fg, bg = tones.get(self.TONES.get(kind, "muted"), tones["muted"])
        self._kind = self.TONES.get(kind, "muted")
        self._fg = fg
        self._bg = bg
        self.setStyleSheet(
            f"color: {fg}; background: {bg}; border: 1px solid {fg}55;"
            "border-radius: 9px; padding: 2px 9px; font-size: 7.5pt; font-weight: 600;"
        )
        self.setVisible(bool(self.text()))

    def setText(self, text: str) -> None:
        super().setText(text)
        self.setVisible(bool(text))

    def apply_theme(self, colors: dict) -> None:
        """Açık/koyu temada okunur kalan tonlar (renk seti theme'den gelir)."""
        self.set_kind(getattr(self, "_kind", "muted"))


class Banner(QFrame):
    """Sayfa üstü uyarı şeridi: ikon çizgisi + metin."""

    def __init__(self, text: str, kind: str = "danger", *, parent=None) -> None:
        super().__init__(parent)
        self.kind = kind
        self.setObjectName("Banner")
        box = QHBoxLayout(self)
        box.setContentsMargins(14, 11, 14, 11)
        box.setSpacing(10)
        self.mark = QLabel("●")
        self.mark.setStyleSheet("font-size: 9pt;")
        self.label = QLabel(text)
        self.label.setWordWrap(True)
        box.addWidget(self.mark, 0, Qt.AlignmentFlag.AlignTop)
        box.addWidget(self.label, 1)
        self.apply_theme(theme.current())

    def apply_theme(self, c: dict) -> None:
        color = c["danger"] if self.kind == "danger" else c["accent_text"]
        bg = c["danger_soft"] if self.kind == "danger" else c["accent_soft"]
        self.setStyleSheet(
            f"#Banner {{ background: {bg}; border: 1px solid {color}55; border-radius: 10px; }}"
        )
        self.mark.setStyleSheet(f"color: {color}; font-size: 9pt; background: transparent;")
        self.label.setStyleSheet(f"color: {color}; background: transparent; font-size: 9.5pt;")


# --------------------------------------------------------------------------
# kartlar
# --------------------------------------------------------------------------
class Card(QFrame):
    """Etiket + büyük değer + açıklama + (isteğe bağlı) eylem altlığı."""

    def __init__(
        self,
        title: str,
        value: str = "—",
        hint: str = "",
        *,
        accent: bool = False,
        compact: bool = False,
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self.setObjectName("Card")
        self.setProperty("accent", accent)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)

        box = QVBoxLayout(self)
        box.setContentsMargins(18, 15, 18, 15)
        box.setSpacing(7)

        self.title_row = QHBoxLayout()
        self.title_row.setSpacing(8)
        self.title_label = QLabel(tr_upper(title))
        self.title_label.setObjectName("CardLabel")
        self.title_row.addWidget(self.title_label)
        self.title_row.addStretch(1)

        self.value_label = QLabel(value)
        self.value_label.setObjectName("CardValue")
        self.value_label.setWordWrap(True)

        self.hint_label = QLabel(hint)
        self.hint_label.setObjectName("CardHint")
        self.hint_label.setWordWrap(True)
        self.hint_label.setVisible(bool(hint))

        box.addLayout(self.title_row)
        box.addWidget(self.value_label)
        box.addWidget(self.hint_label)
        # NOT: buraya addStretch konmaz; footer eklendiğinde içerik ile buton
        # arasında ölü boşluk oluşur. Kartlar Fixed yükseklik politikası kullanır.

        self._box = box
        self._footer: QWidget | None = None
        self._footer_layout: QHBoxLayout | None = None
        self._extras: QVBoxLayout | None = None
        self.setMinimumHeight(92 if compact else 104)

    # --- içerik ---
    def set_value(self, value: str, hint: str | None = None) -> None:
        self.value_label.setText(value)
        if hint is not None:
            self.hint_label.setText(hint)
            self.hint_label.setVisible(bool(hint))

    def set_title(self, text: str) -> None:
        self.title_label.setText(tr_upper(text))

    def set_small_value(self, small: bool = True) -> None:
        self.value_label.setProperty("small", small)
        self.value_label.style().unpolish(self.value_label)
        self.value_label.style().polish(self.value_label)

    def set_accent(self, accent: bool) -> None:
        self.setProperty("accent", accent)
        self.style().unpolish(self)
        self.style().polish(self)

    def add_pill(self, widget: QWidget) -> None:
        self.title_row.addWidget(widget)

    def add_widget(self, widget: QWidget) -> None:
        if self._extras is None:
            self._extras = QVBoxLayout()
            self._extras.setContentsMargins(0, 0, 0, 0)
            self._extras.setSpacing(4)
            self._box.addLayout(self._extras)
        self._extras.addWidget(widget)

    def add_action(self, widget: QWidget) -> None:
        if self._footer is None:
            self._box.addSpacing(6)
            self._box.addWidget(hairline())
            self._footer = QWidget()
            self._footer_layout = QHBoxLayout(self._footer)
            self._footer_layout.setContentsMargins(0, 8, 0, 0)
            self._footer_layout.setSpacing(8)
            self._footer_layout.setAlignment(Qt.AlignmentFlag.AlignLeft)
            self._box.addWidget(self._footer)
        self._footer_layout.addWidget(widget)

    def add_stretch_action(self) -> None:
        if self._footer_layout is not None:
            self._footer_layout.addStretch(1)


class MetricCard(Card):
    """Ölçü gösteren kart: değer + ince ilerleme çubuğu + yüzde."""

    def __init__(
        self,
        title: str,
        value: str = "—",
        hint: str = "",
        *,
        percent: int | None = None,
        level: str = "ok",
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(title, value, hint, parent=parent)
        self.bar = QProgressBar()
        self.bar.setTextVisible(False)
        self.bar.setFixedHeight(6)
        self.bar.setProperty("level", level)
        self.bar.setRange(0, 100)
        self._box.insertWidget(3, self.bar)
        if percent is None:
            self.bar.setVisible(False)
        else:
            self.bar.setValue(max(0, min(100, percent)))

    def set_percent(self, percent: int, level: str | None = None) -> None:
        self.bar.setVisible(True)
        self.bar.setValue(max(0, min(100, percent)))
        if level:
            self.bar.setProperty("level", level)
            self.bar.style().unpolish(self.bar)
            self.bar.style().polish(self.bar)


# --------------------------------------------------------------------------
# bölüm başlığı
# --------------------------------------------------------------------------
class SectionHeader(QWidget):
    def __init__(self, title: str, hint: str = "", right: QWidget | None = None, parent=None) -> None:
        super().__init__(parent)
        box = QVBoxLayout(self)
        box.setContentsMargins(0, 6, 0, 0)
        box.setSpacing(6)
        row = QHBoxLayout()
        row.setSpacing(10)
        self.title = label(title, "SectionTitle")
        row.addWidget(self.title)
        if hint:
            row.addWidget(label(hint, "SectionHint"))
        row.addStretch(1)
        if right is not None:
            row.addWidget(right)
        box.addLayout(row)
        box.addWidget(hairline())


def section(text: str, hint: str = "", right: QWidget | None = None) -> SectionHeader:
    return SectionHeader(text, hint, right)


def card_grid(cards: list[QWidget], columns: int = 2) -> QGridLayout:
    grid = QGridLayout()
    grid.setHorizontalSpacing(14)
    grid.setVerticalSpacing(14)
    for index, card in enumerate(cards):
        grid.addWidget(card, index // columns, index % columns)
    for col in range(columns):
        grid.setColumnStretch(col, 1)
    return grid


# --------------------------------------------------------------------------
# adım listesi (işlem raporu)
# --------------------------------------------------------------------------
class StepList(QWidget):
    """İşlem sonuçları: her satır ✔ / ✖ / ○ ve isteğe bağlı ayrıntı."""

    MARKS: ClassVar[dict[str, tuple[str, str]]] = {
        "ok": ("✔", "#35d399"),
        "fail": ("✖", "#ff3b61"),
        "skip": ("○", "#64748b"),
    }

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._box = QVBoxLayout(self)
        self._box.setContentsMargins(0, 0, 0, 0)
        self._box.setSpacing(6)

    def count(self) -> int:
        return self._box.count()

    def texts(self) -> list[str]:
        out = []
        for index in range(self._box.count()):
            widget = self._box.itemAt(index).widget()
            if isinstance(widget, QLabel):
                out.append(widget.text())
        return out

    def clear(self) -> None:
        while self._box.count():
            item = self._box.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

    def show_steps(self, steps: list[dict], empty: str = "") -> None:
        self.clear()
        if not steps:
            self._box.addWidget(muted(empty or "Sonuç yok."))
            return
        for step in steps:
            status = step.get("status", "ok")
            mark, color = self.MARKS.get(status, self.MARKS["ok"])
            detail = step.get("detail") or ""
            row = QWidget()
            line = QHBoxLayout(row)
            line.setContentsMargins(10, 7, 10, 7)
            line.setSpacing(10)
            badge = QLabel(mark)
            badge.setFixedWidth(14)
            badge.setStyleSheet(f"color: {color}; font-size: 9pt; background: transparent;")
            title = QLabel(step.get("label", ""))
            title.setWordWrap(True)
            title.setStyleSheet("background: transparent;")
            line.addWidget(badge, 0, Qt.AlignmentFlag.AlignTop)
            line.addWidget(title, 1)
            if detail:
                extra = QLabel(detail)
                extra.setObjectName("Faint")
                extra.setWordWrap(True)
                extra.setStyleSheet("background: transparent;")
                line.addWidget(extra, 1)
            row.setStyleSheet("background: rgba(127, 145, 175, 0.06); border-radius: 8px;")
            self._box.addWidget(row)


# --------------------------------------------------------------------------
# sayfa iskeleti
# --------------------------------------------------------------------------
class Page(QWidget):
    """Ortak iskelet: başlık, alt açıklama, kaydırılabilir gövde."""

    title = "Sayfa"
    subtitle = ""

    def __init__(self, backend, window=None, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("Page")
        self.backend = backend
        self.window = window

        outer = QVBoxLayout(self)
        outer.setContentsMargins(28, 18, 28, 20)
        outer.setSpacing(6)

        header = QHBoxLayout()
        header.setSpacing(12)
        titles = QVBoxLayout()
        titles.setSpacing(4)
        self.title_label = QLabel(self.title)
        self.title_label.setObjectName("PageTitle")
        titles.addWidget(self.title_label)
        if self.subtitle:
            self.subtitle_label = QLabel(self.subtitle)
            self.subtitle_label.setObjectName("PageSub")
            self.subtitle_label.setWordWrap(True)
            titles.addWidget(self.subtitle_label)
        header.addLayout(titles, 1)
        self._actions = QHBoxLayout()
        self._actions.setSpacing(8)
        self._actions.setAlignment(Qt.AlignmentFlag.AlignTop)
        header.addLayout(self._actions)
        outer.addLayout(header)
        outer.addSpacing(10)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        self.body = QWidget()
        self.body.setObjectName("Body")
        self.layout = QVBoxLayout(self.body)
        self.layout.setContentsMargins(0, 0, 10, 8)
        self.layout.setSpacing(14)
        scroll.setWidget(self.body)
        outer.addWidget(scroll, 1)

        self.build()
        self.refresh()

    def add_page_action(self, widget: QWidget) -> None:
        self._actions.addWidget(widget)

    # alt sınıflar doldurur
    def build(self) -> None:  # pragma: no cover - UI
        pass

    def refresh(self) -> None:  # pragma: no cover - UI
        pass

    def toast(self, message: str, kind: str = "info") -> None:
        if self.window is not None and hasattr(self.window, "toast"):
            self.window.toast(message, kind)


class EmptyState(QWidget):
    """Boş durum: başlık + açıklama, ortalanmış."""

    def __init__(self, title: str, hint: str = "", parent=None) -> None:
        super().__init__(parent)
        box = QVBoxLayout(self)
        box.setContentsMargins(0, 18, 0, 18)
        box.setSpacing(6)
        box.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.title = label(title, "Muted")
        self.title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        box.addWidget(self.title)
        if hint:
            self.hint = label(hint, "Faint")
            self.hint.setAlignment(Qt.AlignmentFlag.AlignCenter)
            box.addWidget(self.hint)


def hbox(*widgets, spacing: int = 8, stretch_at_end: bool = True) -> QHBoxLayout:
    box = QHBoxLayout()
    box.setSpacing(spacing)
    for widget in widgets:
        if widget is None:
            box.addStretch(1)
        else:
            box.addWidget(widget)
    if stretch_at_end:
        box.addStretch(1)
    return box


class SectionPlaceholder(QLabel):
    """Serbest metin gösteren sade alan (durum listeleri için)."""

    def __init__(self, text: str = "", parent=None) -> None:
        super().__init__(text, parent)
        self.setObjectName("Muted")
        self.setWordWrap(True)
        self.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)

# --------------------------------------------------------------------------
# v0.6 konsept bileşenleri
# --------------------------------------------------------------------------
class HeroCard(QFrame):
    """Sayfanın üst paneli: etkin durum, etiketler, eylemler ve halka."""

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setObjectName("HeroCard")
        row = QHBoxLayout(self)
        row.setContentsMargins(20, 16, 16, 16)
        row.setSpacing(18)

        left = QVBoxLayout()
        left.setSpacing(8)
        self.eyebrow_label = QLabel("")
        self.eyebrow_label.setObjectName("Eyebrow")
        left.addWidget(self.eyebrow_label)

        self.title_label = QLabel("—")
        self.title_label.setObjectName("HeroTitle")
        self.title_label.setWordWrap(True)
        left.addWidget(self.title_label)

        self.sub_label = QLabel("")
        self.sub_label.setObjectName("HeroSub")
        self.sub_label.setWordWrap(True)
        left.addWidget(self.sub_label)

        self.tag_row = QHBoxLayout()
        self.tag_row.setSpacing(7)
        self.tag_row.setContentsMargins(0, 4, 0, 0)
        left.addLayout(self.tag_row)

        left.addSpacing(6)
        self.action_row = QHBoxLayout()
        self.action_row.setSpacing(9)
        self.action_row.addStretch(1)
        left.addLayout(self.action_row)
        row.addLayout(left, 1)

        self.ring = RingGauge(0, "hazır")
        row.addWidget(self.ring, 0, Qt.AlignmentFlag.AlignVCenter)

    def add_eyebrow(self, text: str) -> QLabel:
        self.eyebrow_label.setText(tr_upper(text))
        return self.eyebrow_label

    def add_action(self, widget: QWidget) -> None:
        self.action_row.insertWidget(self.action_row.count() - 1, widget)


class RingGauge(QWidget):
    """Yüzde halkası: ince cyan→violet yay + ortada değer.

    Qt'de `conic-gradient` yok; QConicalGradient + drawArc ile çiziliyor.
    """

    def __init__(
        self,
        percent: int = 0,
        caption: str = "",
        note: str = "",
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self._percent = max(0, min(100, percent))
        self._caption = caption
        self._note = note
        self.setMinimumSize(132, 138)
        self.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)

    def set_value(self, percent: int, caption: str = "", note: str = "") -> None:
        self._percent = max(0, min(100, int(percent)))
        if caption:
            self._caption = caption
        self._note = note
        self.update()

    def sizeHint(self) -> QSize:
        return QSize(132, 138)

    def paintEvent(self, _event) -> None:
        c = theme.current()
        side = 112
        rect = QRectF((self.width() - side) / 2, 2, side, side)
        thickness = 9.0

        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        # arka halka
        track = QPen(QColor(c["surface3"]), thickness, Qt.PenStyle.SolidLine)
        track.setCapStyle(Qt.PenCapStyle.RoundCap)
        painter.setPen(track)
        painter.drawArc(
            rect.adjusted(thickness / 2, thickness / 2, -thickness / 2, -thickness / 2),
            0,
            360 * 16,
        )

        # değer yayı
        gradient = QConicalGradient(rect.center(), 200.0)
        gradient.setColorAt(0.0, QColor(c["accent"]))
        gradient.setColorAt(0.55, QColor(c["accent_2"]))
        gradient.setColorAt(1.0, QColor(c["accent"]))
        pen = QPen(QColor(c["accent"]), thickness, Qt.PenStyle.SolidLine)
        pen.setBrush(gradient)
        pen.setCapStyle(Qt.PenCapStyle.RoundCap)
        painter.setPen(pen)
        painter.drawArc(
            rect.adjusted(thickness / 2, thickness / 2, -thickness / 2, -thickness / 2),
            200 * 16,
            -int(self._percent * 3.6 * 16),
        )

        # orta metin
        painter.setPen(QColor(c["text"]))
        font = theme.ui_font(15, QFont.Weight.Bold)
        painter.setFont(font)
        painter.drawText(
            QRectF(rect.left(), rect.top() + 30, rect.width(), 26),
            Qt.AlignmentFlag.AlignCenter,
            f"%{self._percent}",
        )
        painter.setPen(QColor(c["text_faint"]))
        painter.setFont(theme.ui_font(6.5, QFont.Weight.DemiBold))
        painter.drawText(
            QRectF(rect.left(), rect.top() + 56, rect.width(), 16),
            Qt.AlignmentFlag.AlignCenter,
            self._caption.upper(),
        )
        painter.end()

        if self._note:
            note = QLabel(self._note)
            note.setObjectName("Faint")
            note.setAlignment(Qt.AlignmentFlag.AlignCenter)
            note.setWordWrap(True)
            note.setGeometry(0, side, self.width(), self.height() - side)


class SegmentedBar(QWidget):
    """İki parçalı ilerleme çubuğu (ör. 12 Debian + 3 Flatpak)."""

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._parts: list[tuple[int, str]] = []
        self.setFixedHeight(5)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)

    def set_parts(self, parts: list[tuple[int, str]]) -> None:
        self._parts = [(max(0, value), color) for value, color in parts]
        self.update()

    def paintEvent(self, _event) -> None:
        c = theme.current()
        total = sum(value for value, _ in self._parts)
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.setPen(Qt.PenStyle.NoPen)
        full = QRectF(0, 0, self.width(), 5)
        painter.setBrush(QColor(c["surface3"]))
        painter.drawRoundedRect(full, 2.5, 2.5)
        if not total:
            painter.end()
            return
        x = 0.0
        for index, (value, color) in enumerate(self._parts):
            width = self.width() * value / total
            if index < len(self._parts) - 1:
                width -= 3
            painter.setBrush(QColor(color))
            painter.drawRoundedRect(QRectF(x, 0, max(2.0, width), 5), 2.5, 2.5)
            x += width + 3
        painter.end()


class KpiCard(QFrame):
    """Tek satırlık ölçü kartı: ikon, etiket, değer, çubuk, kanıt satırı."""

    def __init__(
        self,
        label_text: str,
        icon_text: str = "•",
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self.setObjectName("Kpi")
        box = QVBoxLayout(self)
        box.setContentsMargins(15, 13, 15, 14)
        box.setSpacing(7)

        head = QHBoxLayout()
        head.setSpacing(8)
        chip = QLabel(icon_text)
        chip.setObjectName("KpiIcon")
        chip.setFixedSize(24, 24)
        chip.setAlignment(Qt.AlignmentFlag.AlignCenter)
        head.addWidget(chip)
        self.label = QLabel(tr_upper(label_text))
        self.label.setObjectName("CardLabel")
        head.addWidget(self.label)
        head.addStretch(1)
        self.pill: QWidget | None = None
        box.addLayout(head)

        self.value = QLabel("—")
        self.value.setObjectName("KpiValue")
        box.addWidget(self.value)

        self.bar = SegmentedBar()
        self.bar.setVisible(False)
        self.progress = QProgressBar()
        self.progress.setTextVisible(False)
        self.progress.setFixedHeight(5)
        self.progress.setRange(0, 100)
        self.progress.setVisible(False)
        box.addWidget(self.bar)
        box.addWidget(self.progress)

        self.small = QLabel("")
        self.small.setObjectName("KpiSmall")
        self.small.setWordWrap(True)
        self.setMinimumHeight(106)
        self.small.setVisible(False)
        box.addWidget(self.small)

    def set_value(self, value: str, small: str = "") -> None:
        self.value.setText(value)
        self.small.setText(small)
        self.small.setVisible(bool(small))

    def set_pill(self, widget: QWidget) -> None:
        """Rozeti değiştir; yenilemede üst üste birikmesin."""
        head = self.layout().itemAt(0).layout()
        if self.pill is not None:
            head.removeWidget(self.pill)
            self.pill.setParent(None)
            self.pill.deleteLater()
        self.pill = widget
        head.addWidget(widget)

    def set_segments(self, parts: list[tuple[int, str]]) -> None:
        self.progress.setVisible(False)
        self.bar.set_parts(parts)
        self.bar.setVisible(bool(parts))

    def set_percent(self, percent: int, level: str = "ok") -> None:
        self.bar.setVisible(False)
        self.progress.setProperty("level", level)
        self.progress.style().unpolish(self.progress)
        self.progress.style().polish(self.progress)
        self.progress.setValue(max(0, min(100, int(percent))))
        self.progress.setVisible(True)


class Panel(QFrame):
    """Başlıklı yüzey: zincir listesi, sistem sağlığı gibi bloklar."""

    def __init__(self, title: str, hint: str = "", parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setObjectName("Panel")
        self.box = QVBoxLayout(self)
        self.box.setContentsMargins(0, 0, 0, 8)
        self.box.setSpacing(0)

        head = QHBoxLayout()
        head.setContentsMargins(16, 14, 16, 10)
        head.setSpacing(10)
        self.title = QLabel(title)
        self.title.setObjectName("SectionTitle")
        head.addWidget(self.title)
        if hint:
            self.hint = QLabel(hint)
            self.hint.setObjectName("SectionHint")
            head.addWidget(self.hint)
        head.addStretch(1)
        self.head_right = head
        self.box.addLayout(head)

        self.body = QVBoxLayout()
        self.body.setContentsMargins(8, 0, 8, 0)
        self.body.setSpacing(0)
        self.box.addLayout(self.body)
        self.box.addStretch(1)

    def add_pill(self, widget: QWidget) -> None:
        self.head_right.addWidget(widget)

    def add_row(self, widget: QWidget, *, divider: bool = False) -> None:
        if divider:
            line = hairline()
            line.setContentsMargins(8, 0, 8, 0)
            self.body.addWidget(line)
        self.body.addWidget(widget)


class ChainRow(QFrame):
    """Zincir satırı: renkli nokta, başlık, açıklama, sağda tam tarih."""

    def __init__(
        self,
        title: str,
        subtitle: str = "",
        when: str = "",
        kind: str = "accent",
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self.setObjectName("ChainRow")
        c = theme.current()
        colors = {"accent": c["accent"], "violet": c["accent_2"], "muted": c["text_faint"]}
        line = QHBoxLayout(self)
        line.setContentsMargins(9, 7, 9, 7)
        line.setSpacing(11)

        dot = QLabel()
        dot.setFixedSize(8, 8)
        dot.setStyleSheet(
            f"background: {colors.get(kind, c['accent'])}; border-radius: 4px;"
        )
        line.addWidget(dot, 0, Qt.AlignmentFlag.AlignVCenter)

        text = QVBoxLayout()
        text.setSpacing(1)
        name = QLabel(title)
        name.setObjectName("ChainTitle")
        text.addWidget(name)
        if title and subtitle:
            sub = QLabel(subtitle)
            sub.setObjectName("ChainSub")
            text.addWidget(sub)
        line.addLayout(text, 1)

        if when:
            stamp = QLabel(when)
            stamp.setObjectName("ChainWhen")
            line.addWidget(stamp, 0, Qt.AlignmentFlag.AlignVCenter)


class HealthRow(QFrame):
    """Sağlık satırı: ad, değer, çubuk veya rozet."""

    def __init__(
        self,
        name: str,
        value: str = "",
        percent: int | None = None,
        level: str = "ok",
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        line = QHBoxLayout(self)
        line.setContentsMargins(9, 7, 9, 7)
        line.setSpacing(10)
        self.name = QLabel(name)
        self.name.setObjectName("HealthName")
        self.name.setFixedWidth(92)
        line.addWidget(self.name)
        self.value = QLabel(value)
        self.value.setObjectName("HealthValue")
        self.value.setMinimumWidth(64)
        line.addWidget(self.value)
        line.addStretch(1)
        self.bar: QProgressBar | None = None
        if percent is not None:
            self.bar = QProgressBar()
            self.bar.setTextVisible(False)
            self.bar.setFixedHeight(5)
            self.bar.setFixedWidth(96)
            self.bar.setProperty("level", level)
            self.bar.setRange(0, 100)
            self.bar.setValue(max(0, min(100, percent)))
            line.addWidget(self.bar)
        self.slot = QHBoxLayout()
        self.slot.setSpacing(6)
        line.addLayout(self.slot)

    def set_value(self, value: str) -> None:
        self.value.setText(value)

    def set_percent(self, percent: int, level: str = "ok") -> None:
        if self.bar is None:
            return
        self.bar.setProperty("level", level)
        self.bar.style().unpolish(self.bar)
        self.bar.style().polish(self.bar)
        self.bar.setValue(max(0, min(100, int(percent))))

    def set_pill(self, widget: QWidget) -> None:
        while self.slot.count():
            item = self.slot.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        self.slot.addWidget(widget)


class ProfileCard(QFrame):
    """Mod profili kartı (Genel Bakış şeridi). Tıklanabilir."""

    clicked = pyqtSignal(str)

    def __init__(
        self,
        ident: str,
        name: str,
        subtitle: str = "",
        power: str = "",
        active: bool = False,
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self.setObjectName("Pcard")
        self.ident = ident
        self.setProperty("active", active)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        box = QVBoxLayout(self)
        box.setContentsMargins(14, 12, 14, 13)
        box.setSpacing(4)

        head = QHBoxLayout()
        head.setSpacing(8)
        eyebrow = QLabel("AKTİF" if active else "PROFİL")
        eyebrow.setObjectName("Eyebrow")
        head.addWidget(eyebrow)
        head.addStretch(1)
        if power:
            self.pill = Pill(power, "accent" if active else "muted")
            head.addWidget(self.pill)
        box.addLayout(head)

        title = QLabel(name)
        title.setObjectName("PcardName")
        box.addWidget(title)
        if subtitle:
            sub = QLabel(subtitle)
            sub.setObjectName("PcardSub")
            sub.setWordWrap(True)
            box.addWidget(sub)

    def mouseReleaseEvent(self, event) -> None:
        if event.button() == Qt.MouseButton.LeftButton:
            self.clicked.emit(self.ident)
        super().mouseReleaseEvent(event)


class QuickAction(QPushButton):
    """İkonlu, iki satırlı hızlı eylem düğmesi."""

    def __init__(
        self,
        icon_text: str,
        title: str,
        subtitle: str = "",
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self.setObjectName("Qcard")
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setMinimumHeight(52)
        row = QHBoxLayout(self)
        row.setContentsMargins(12, 10, 12, 10)
        row.setSpacing(11)
        chip = QLabel(icon_text)
        chip.setObjectName("QcardIcon")
        chip.setFixedSize(28, 28)
        chip.setAlignment(Qt.AlignmentFlag.AlignCenter)
        row.addWidget(chip)
        text = QVBoxLayout()
        text.setSpacing(1)
        head = QLabel(title)
        head.setObjectName("QcardTitle")
        text.addWidget(head)
        if subtitle:
            sub = QLabel(subtitle)
            sub.setObjectName("QcardSub")
            text.addWidget(sub)
        row.addLayout(text, 1)


def tag(text: str, value: str = "") -> QLabel:
    """Hero etiket çipi: 'güç profili **performance**'."""
    widget = QLabel(f"{html.escape(text)} <b>{html.escape(value)}</b>" if value else html.escape(text))
    widget.setObjectName("HeroTag")
    return widget


def eyebrow(text: str) -> QLabel:
    return label(tr_upper(text), "Eyebrow")

