"""Ana pencere: sol menü, üst bar, sayfa yığını, bildirimler.

Görsel dil v0.6 "konsept": üç bölümlü kenar çubuğu (Çalışma / Donanım / Diğer),
her satırda klavye ipucu, üst barda arama kutusu (Ctrl+K), cihaz kartı ve tek
vurgu rengi. Hareket az ve amaçlı: sayfa geçişinde 140 ms solma, bildirimlerde
180 ms belirme.
"""

from __future__ import annotations

import shutil
import socket
from typing import ClassVar

from PyQt6.QtCore import QEasingCurve, QPropertyAnimation, Qt, QTimer
from PyQt6.QtGui import (
    QIcon,
    QKeySequence,
    QShortcut,
)
from PyQt6.QtWidgets import (
    QButtonGroup,
    QCompleter,
    QFrame,
    QGraphicsOpacityEffect,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMainWindow,
    QPushButton,
    QStackedWidget,
    QVBoxLayout,
    QWidget,
)

from . import APP_NAME, TAGLINE, VERSION, icons, theme
from .backend import Backend
from .brand import brand_pixmap
from .format import duration
from .pages import (
    AboutPage,
    BackupsPage,
    DriversPage,
    ModesPage,
    OverviewPage,
    PrivacyPage,
    SoftwarePage,
    SystemPage,
)
from .widgets import Banner, Pill
from .workers import TaskRunner

NAV = [
    ("overview", "Genel Bakış"),
    ("modes", "Modlar"),
    ("backups", "Yedekler"),
    ("drivers", "Sürücüler"),
    ("software", "Yazılım"),
    ("system", "Sistem"),
    ("privacy", "Gizlilik"),
    ("about", "Hakkında"),
]

SECTIONS = [
    ("Çalışma", ["overview", "modes", "backups"]),
    ("Donanım", ["drivers", "software", "system"]),
    ("Diğer", ["privacy", "about"]),
]


class NavButton(QPushButton):
    """Kenar çubuğu satırı: simge, ad, sağda klavye ipucu."""

    def __init__(self, key: str, text: str, index: int, parent=None) -> None:
        super().__init__(parent)
        self.key = key
        self.setProperty("nav", True)
        self.setCheckable(True)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setToolTip(f"{text}  ·  Ctrl+{index}")
        self.setMinimumHeight(34)

        row = QHBoxLayout(self)
        row.setContentsMargins(10, 6, 9, 6)
        row.setSpacing(10)

        self.icon_label = QLabel()
        self.icon_label.setFixedSize(18, 18)
        self.icon_label.setPixmap(icons.pixmap(key, "#9aa9be", 18))
        self.icon_label.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        row.addWidget(self.icon_label)

        self.text_label = QLabel(text)
        self.text_label.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        row.addWidget(self.text_label, 1)

        self.hint = QLabel(str(index))
        self.hint.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self.hint.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.hint.setFixedHeight(16)
        self.hint.setMinimumWidth(17)
        row.addWidget(self.hint)

        self.toggled.connect(self._sync_colors)
        self._sync_colors(self.isChecked())

    def _sync_colors(self, active: bool) -> None:
        c = theme.current()
        self.icon_label.setPixmap(
            icons.pixmap(self.key, c["accent_text"] if active else "#9aa9be", 18)
        )
        weight = "600" if active else "400"
        self.text_label.setStyleSheet(
            f"color: {c['text'] if active else c['text_dim']};"
            f" font-size: 9.5pt; font-weight: {weight}; background: transparent;"
        )
        self.hint.setStyleSheet(
            f"color: {c['accent_text'] if active else c['text_faint']};"
            f" font-size: 7pt; border: 1px solid {c['border']};"
            " border-radius: 4px; padding: 0px 4px; background: transparent;"
        )


class DeviceCard(QFrame):
    """Kenar çubuğu altındaki cihaz kartı: host, oturum, çekirdek."""

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("DevCard")
        box = QVBoxLayout(self)
        box.setContentsMargins(12, 10, 12, 11)
        box.setSpacing(5)

        def row(key: str, value: str, mono: bool = False) -> QLabel:
            line = QHBoxLayout()
            line.setSpacing(6)
            name = QLabel(key.upper())
            name.setObjectName("DevLabel")
            val = QLabel(value)
            val.setObjectName("DevValue" if not mono else "DevMono")
            val.setAlignment(Qt.AlignmentFlag.AlignRight)
            val.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
            line.addWidget(name)
            line.addStretch(1)
            line.addWidget(val)
            box.addLayout(line)
            return val

        self.host = row("HOST", socket.gethostname()[:18])
        self.session = row("OTURUM", "—")
        self.kernel = row("ÇEKİRDEK", "—", mono=True)


class SearchBox(QFrame):
    """Üst bar araması: sayfa adıyla eşleşir, Ctrl+K odaklar."""

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("SearchBox")
        self.setFixedHeight(32)
        self.setMinimumWidth(250)
        self.setMaximumWidth(330)
        row = QHBoxLayout(self)
        row.setContentsMargins(9, 0, 7, 0)
        row.setSpacing(7)

        glyph = QLabel("⌕")
        glyph.setObjectName("Faint")
        row.addWidget(glyph)

        self.input = QLineEdit()
        self.input.setObjectName("SearchInput")
        self.input.setPlaceholderText("Sayfa ara…")
        self.input.setClearButtonEnabled(True)
        row.addWidget(self.input, 1)

        self.hint = QLabel("Ctrl K")
        self.hint.setObjectName("SearchHint")
        row.addWidget(self.hint)

        self.completer = QCompleter([text for _key, text in NAV], self)
        self.completer.setCaseSensitivity(Qt.CaseSensitivity.CaseInsensitive)
        self.completer.setFilterMode(Qt.MatchFlag.MatchContains)
        self.input.setCompleter(self.completer)


class Toast(QLabel):
    """Kendiliğinden kaybolan bildirim; belirip soluyor."""

    def __init__(self, parent) -> None:
        super().__init__(parent)
        self.setObjectName("Toast")
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.setVisible(False)
        self.effect = QGraphicsOpacityEffect(self)
        self.setGraphicsEffect(self.effect)
        self.anim = QPropertyAnimation(self.effect, b"opacity", self)
        self.anim.setDuration(180)
        self.anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        self.timer = QTimer(self)
        self.timer.setSingleShot(True)
        self.timer.timeout.connect(self.dismiss)

    def show_message(self, text: str, kind: str = "info", msec: int = 4200) -> None:
        self.setProperty("kind", kind)
        self.style().unpolish(self)
        self.style().polish(self)
        self.setText(text)
        self.adjustSize()
        self.reposition()
        self.setVisible(True)
        self.raise_()
        self.anim.stop()
        self.anim.setStartValue(0.0)
        self.anim.setEndValue(1.0)
        self.anim.start()
        self.timer.start(msec)

    def dismiss(self) -> None:
        self.anim.stop()
        self.anim.setStartValue(self.effect.opacity())
        self.anim.setEndValue(0.0)
        self.anim.finished.connect(self._hide_once)
        self.anim.start()

    def _hide_once(self) -> None:
        try:
            self.anim.finished.disconnect(self._hide_once)
        except TypeError:
            pass
        self.setVisible(False)

    def reposition(self) -> None:
        if not self.parent():
            return
        area = self.parent().rect()
        self.move(
            (area.width() - self.width()) // 2,
            area.height() - self.height() - 26,
        )


class Sidebar(QFrame):
    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("Sidebar")
        self.setFixedWidth(248)

        box = QVBoxLayout(self)
        box.setContentsMargins(14, 16, 14, 14)
        box.setSpacing(2)

        brand = QHBoxLayout()
        brand.setSpacing(11)
        logo = QLabel()
        logo.setPixmap(brand_pixmap(36))
        logo.setFixedSize(36, 36)
        titles = QVBoxLayout()
        titles.setSpacing(1)
        name = QLabel("AX-Center")
        name.setObjectName("BrandName")
        tag = QLabel(TAGLINE)
        tag.setObjectName("BrandTag")
        titles.addWidget(name)
        titles.addWidget(tag)
        brand.addWidget(logo)
        brand.addLayout(titles)
        brand.addStretch(1)
        box.addLayout(brand)
        box.addSpacing(14)

        self.group = QButtonGroup(self)
        self.group.setExclusive(True)
        self.buttons: dict[str, QPushButton] = {}
        index_of = {key: number for number, (key, _t) in enumerate(NAV, start=1)}
        titles_of = dict(NAV)
        for section_title, keys in SECTIONS:
            head = QLabel(section_title.upper())
            head.setObjectName("NavSection")
            box.addWidget(head)
            for key in keys:
                button = NavButton(key, titles_of[key], index_of[key])
                self.group.addButton(button)
                box.addWidget(button)
                self.buttons[key] = button

        box.addStretch(1)
        self.chip = DeviceCard()
        box.addWidget(self.chip)
        box.addSpacing(10)
        footer = QHBoxLayout()
        footer.setSpacing(6)
        version = QLabel(f"v{VERSION}")
        version.setObjectName("VersionTag")
        self.mode_pill = Pill("canlı", "ok")
        footer.addWidget(version)
        footer.addStretch(1)
        footer.addWidget(self.mode_pill)
        box.addLayout(footer)


class MainWindow(QMainWindow):
    FEEDBACK: ClassVar[dict[str, int]] = {"danger": 6000, "success": 3800, "info": 4200}

    def __init__(self, backend: Backend | None = None) -> None:
        super().__init__()
        self.backend = backend or Backend()
        self.runner = TaskRunner(self)
        self.colors = theme.DARK
        self._current = "overview"

        self.setWindowTitle(APP_NAME)
        self.setWindowIcon(QIcon(brand_pixmap(64)))
        self.resize(1180, 780)
        self.setMinimumSize(960, 640)

        root = QWidget()
        root.setObjectName("Root")
        shell = QHBoxLayout(root)
        shell.setContentsMargins(0, 0, 0, 0)
        shell.setSpacing(0)

        self.sidebar = Sidebar()
        shell.addWidget(self.sidebar)

        right = QWidget()
        right_layout = QVBoxLayout(right)
        right_layout.setContentsMargins(0, 0, 0, 0)
        right_layout.setSpacing(0)

        # ---- üst bar
        self.topbar = QFrame()
        self.topbar.setObjectName("TopBar")
        self.topbar.setFixedHeight(56)
        bar = QHBoxLayout(self.topbar)
        bar.setContentsMargins(24, 0, 20, 0)
        bar.setSpacing(10)
        self.crumb_root = QLabel("AX-Center")
        self.crumb_root.setObjectName("CrumbRoot")
        self.crumb_sep = QLabel("›")
        self.crumb_sep.setObjectName("CrumbSep")
        self.crumb = QLabel("Genel Bakış")
        self.crumb.setObjectName("CrumbCurrent")
        bar.addWidget(self.crumb_root)
        bar.addWidget(self.crumb_sep)
        bar.addWidget(self.crumb)
        bar.addStretch(1)

        self.search = SearchBox()
        bar.addWidget(self.search)

        self.host_chip = QLabel("")
        self.host_chip.setObjectName("Faint")
        bar.addWidget(self.host_chip)

        self.polkit_chip = Pill("polkit", "ok")
        has_polkit = shutil.which("pkexec") is not None
        self.polkit_chip.setText("polkit" if has_polkit else "parola yok")
        self.polkit_chip.set_kind("ok" if has_polkit else "warn")
        # Demo gerçek bir sistem değil: yetki zincirini orada göstermiyoruz
        # (görünürlük en sonda: Pill.setText kendini yeniden görünür yapıyor).
        self.polkit_chip.setVisible(not self.backend.demo)
        self.polkit_chip.setToolTip(
            "pkexec bulundu: yetki istemleri çalışır."
            if has_polkit
            else "pkexec bulunamadı: mod, yedek ve sürücü işlemleri parola soramaz."
        )
        bar.addWidget(self.polkit_chip)

        self.btn_refresh = QPushButton()
        self.btn_refresh.setObjectName("IconButton")
        self.btn_refresh.setFixedSize(30, 30)
        self.btn_refresh.setIcon(icons.icon("refresh", "#9aa9be", 15))
        self.btn_refresh.setToolTip("Sayfayı yenile  ·  F5")
        self.btn_refresh.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_refresh.clicked.connect(self.refresh_current)
        bar.addWidget(self.btn_refresh)
        right_layout.addWidget(self.topbar)

        # ---- uyarı şeridi: canlı ama yardımcı yok
        self.banner_host = QFrame()
        self.banner_host.setObjectName("BannerHost")
        banner_box = QVBoxLayout(self.banner_host)
        banner_box.setContentsMargins(24, 12, 24, 0)
        banner_box.setSpacing(0)
        self.banner_host.setVisible(False)
        right_layout.addWidget(self.banner_host)

        self.stack = QStackedWidget()
        right_layout.addWidget(self.stack, 1)
        shell.addWidget(right, 1)
        self.setCentralWidget(root)

        # ---- sayfalar
        self.pages: dict[str, QWidget] = {}
        for key, _text in NAV:
            page = self._make_page(key)
            self.pages[key] = page
            self.stack.addWidget(page)
            self.sidebar.buttons[key].clicked.connect(lambda _=False, k=key: self.go_to(k))

        self._set_sidebar_mode()
        self._render_banner()
        self._wire_search()

        self.status = self.statusBar()
        self.status.setSizeGripEnabled(False)

        self._toast = Toast(self)
        self._fade = QGraphicsOpacityEffect(self.stack)
        self._fade_anim = QPropertyAnimation(self._fade, b"opacity", self)
        self._fade_anim.setDuration(140)
        self._fade_anim.setEasingCurve(QEasingCurve.Type.OutCubic)

        self._install_shortcuts()
        self._update_chrome()
        self.go_to("overview", animate=False)

    # ------------------------------------------------------------------ setup
    def _wire_search(self) -> None:
        self.search.input.textChanged.connect(self._filter_nav)
        self.search.input.returnPressed.connect(self._search_go)
        self.search.completer.activated.connect(self._search_pick)

    def _search_go(self) -> None:
        query = self.search.input.text().strip().lower()
        if not query:
            return
        for key, text in NAV:
            if query in text.lower():
                self.go_to(key)
                self.search.input.clear()
                return
        self.toast("Eşleşen sayfa yok.", "info")

    def _search_pick(self, text: str) -> None:
        for key, title in NAV:
            if title == text:
                self.go_to(key)
                break
        self.search.input.clear()

    def _filter_nav(self, text: str) -> None:
        query = text.strip().lower()
        for key, title in NAV:
            self.sidebar.buttons[key].setVisible(not query or query in title.lower())

    def _set_sidebar_mode(self) -> None:
        if self.backend.demo:
            self.sidebar.mode_pill.setText("DEMO")
            self.sidebar.mode_pill.set_kind("danger")
        elif self.backend.degraded:
            self.sidebar.mode_pill.setText("salt okunur")
            self.sidebar.mode_pill.set_kind("warn")
        else:
            self.sidebar.mode_pill.setText("canlı")
            self.sidebar.mode_pill.set_kind("ok")

    def _render_banner(self) -> None:
        """Sessiz yalan yerine görünür uyarı.

        anatol-helper yoksa hiçbir şey uygulanamaz; kullanıcı bunu ilk saniyede
        görmeli. Eskiden arayüz sessizce demo verisine düşüyordu.
        """
        box = self.banner_host.layout()
        while box.count():
            item = box.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        if not self.backend.degraded:
            self.banner_host.setVisible(False)
            return
        banner = Banner(
            "anatol-helper bulunamadı (/usr/libexec/anatol-helper). "
            "Arayüz salt okunur: mod, yedek, sürücü ve güncelleme işlemleri "
            "çalışmaz. Kurulum: sudo apt install --reinstall ax-center",
            "danger",
        )
        box.addWidget(banner)
        self.banner_host.setVisible(True)

    def _make_page(self, key: str) -> QWidget:
        mapping = {
            "overview": OverviewPage,
            "modes": ModesPage,
            "backups": BackupsPage,
            "drivers": DriversPage,
            "software": SoftwarePage,
            "system": SystemPage,
            "privacy": PrivacyPage,
            "about": AboutPage,
        }
        return mapping[key](self.backend, self)

    def _install_shortcuts(self) -> None:
        for index, (key, _text) in enumerate(NAV, start=1):
            shortcut = QShortcut(QKeySequence(f"Ctrl+{index}"), self)
            shortcut.activated.connect(lambda k=key: self.go_to(k))
        refresh = QShortcut(QKeySequence("F5"), self)
        refresh.activated.connect(self.refresh_current)
        reload_ = QShortcut(QKeySequence("Ctrl+R"), self)
        reload_.activated.connect(self.refresh_current)
        find = QShortcut(QKeySequence("Ctrl+K"), self)
        find.activated.connect(self.focus_search)
        quit_ = QShortcut(QKeySequence("Ctrl+Q"), self)
        quit_.activated.connect(self.close)

    def focus_search(self) -> None:
        self.search.input.setFocus(Qt.FocusReason.ShortcutFocusReason)
        self.search.input.selectAll()

    def _update_chrome(self) -> None:
        system = self.backend.system()
        self.sidebar.chip.session.setText(str(system.get("session", "—")).upper())
        kernel = str(system.get("kernel", "—"))
        self.sidebar.chip.kernel.setText(kernel[:20])
        self.sidebar.chip.host.setText(str(system.get("hostname", "—"))[:18])
        self.host_chip.setText(
            f"{system.get('hostname', '')}  ·  {system.get('session', '')}  ·  "
            f"{duration(system.get('uptime_h', 0) * 3600)} açık"
        )

    # -------------------------------------------------------------------- nav
    def go_to(self, key: str, animate: bool = True) -> None:
        page = self.pages.get(key)
        if page is None:
            return
        self.stack.setCurrentWidget(page)
        self.sidebar.buttons[key].setChecked(True)
        self._current = key
        self.crumb.setText(page.title)
        self.setWindowTitle(f"{APP_NAME} — {page.title}")
        if hasattr(page, "refresh"):
            page.refresh()
        if animate:
            self._fade_anim.stop()
            self._fade.setOpacity(0.0)
            self.stack.setGraphicsEffect(self._fade)
            self._fade_anim.setStartValue(0.0)
            self._fade_anim.setEndValue(1.0)
            self._fade_anim.start()
        else:
            self.stack.setGraphicsEffect(None)

    def focus_mode(self, ident: str) -> None:
        """Genel Bakış'taki profil kartından modlar sayfasına geçiş."""
        page = self.pages.get("modes")
        if page is not None and hasattr(page, "focus_mode"):
            page.focus_mode(ident)

    def refresh_current(self) -> None:
        page = self.pages.get(self._current)
        if page is not None and hasattr(page, "refresh"):
            page.refresh()
            self._update_chrome()
            self.toast("Yenilendi.", "info")

    # ------------------------------------------------------------- bildirimler
    def toast(self, message: str, kind: str = "info") -> None:
        self._toast.show_message(message, kind, self.FEEDBACK.get(kind, 4200))
        self.status.showMessage(message, 6000)

    # ------------------------------------------------------------------ olaylar
    def resizeEvent(self, event) -> None:
        super().resizeEvent(event)
        if self._toast.isVisible():
            self._toast.reposition()

    def closeEvent(self, event) -> None:
        if self.runner.busy:
            self.toast("Süren bir işlem var; bitmesini bekleyin.", "danger")
        super().closeEvent(event)
