"""Modlar: amiral gemisi özelliği. Tek tık, tek parola, geri alınabilir."""

from __future__ import annotations

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import QPushButton, QVBoxLayout, QWidget

from ..widgets import Card, Page, Pill, StepList, card_grid, muted, section

POWER_LABEL = {
    "performance": "Performans",
    "balanced": "Dengeli",
    "power-saver": "Pil tasarrufu",
}

ORDER = ["game", "work", "creative", "focus", "eco"]


class ModeCard(Card):
    """Tek mod kartı: güç profili üst etiket, servis etkileri alt satırda."""

    def __init__(self, mode: dict, page: ModesPage) -> None:
        details = []
        if mode.get("stop_services"):
            details.append(
                "durdurur: "
                + ", ".join(s.replace(".service", "") for s in mode["stop_services"])
            )
        if mode.get("start_services"):
            details.append(
                "başlatır: "
                + ", ".join(s.replace(".service", "") for s in mode["start_services"])
            )
        if mode.get("dnd"):
            details.append("Rahatsız Etme açık")
        if mode.get("flatpak_rules"):
            details.append(f"{len(mode['flatpak_rules'])} flatpak kuralı")

        power = mode.get("power_profile") or ""
        super().__init__(
            POWER_LABEL.get(power, "Profil"),
            mode.get("name", mode.get("id", "?")),
            "  ·  ".join(details) or "servis değişikliği yok",
        )
        self.mode = mode

        self.pill = Pill("etkin", "accent")
        self.add_pill(self.pill)

        self.button = QPushButton("Etkinleştir")
        self.button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.button.clicked.connect(lambda: page.activate(mode["id"]))
        self.add_action(self.button)
        self.set_current(page.is_current(mode["id"]))

    def set_current(self, current: bool) -> None:
        self.pill.setVisible(current)
        self.button.setText("Etkin  ✓" if current else "Etkinleştir")
        self.button.setObjectName("subtle" if current else "flat")
        self.button.style().unpolish(self.button)
        self.button.style().polish(self.button)
        self.set_accent(current)


def _clear_layout(layout) -> None:
    """Izgara/satır düzenlerini çocuklarıyla birlikte boşalt."""
    while layout.count():
        item = layout.takeAt(0)
        widget = item.widget()
        if widget is not None:
            widget.deleteLater()
        elif item.layout() is not None:
            _clear_layout(item.layout())


class ModesPage(Page):
    title = "Modlar"
    subtitle = (
        "Adaptif bağlamlar: güç profili, servisler, bildirimler ve izinler tek "
        "hareketle. Profiller /etc/anatol/contexts.d içindeki düzenlenebilir TOML dosyaları."
    )

    def build(self) -> None:
        self.cards: list[ModeCard] = []
        self.container = QWidget()
        self.container_layout = QVBoxLayout(self.container)
        self.container_layout.setContentsMargins(0, 0, 0, 0)
        self.container_layout.setSpacing(14)
        self.layout.addWidget(self.container)
        self.layout.addWidget(section("Son işlem", "uygulanan adımlar"))
        self.steps = StepList()
        self.layout.addWidget(self.steps)
        self.layout.addStretch(1)
        self.build_cards()

    def build_cards(self) -> None:
        while self.container_layout.count():
            item = self.container_layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()
            elif item.layout() is not None:
                _clear_layout(item.layout())
        self.cards = []
        broken = [
            muted(f"✖ {mode.get('name')}: bozuk profil — {mode['broken']}")
            for mode in self._ordered(self.backend.modes())
            if mode.get("broken")
        ]
        for mode in self._ordered(self.backend.modes()):
            if not mode.get("broken"):
                self.cards.append(ModeCard(mode, self))
        # üç sütunlu ızgara: yüksek ekranlarda tüm profiller tek bakışta
        for start in range(0, len(self.cards), 3):
            self.container_layout.addLayout(card_grid(self.cards[start : start + 3], 3))
        for row in broken:
            self.container_layout.addWidget(row)
        if not self.cards:
            self.container_layout.addWidget(
                muted("Hiç mod bulunamadı. /etc/anatol/contexts.d boş olabilir.")
            )

    @staticmethod
    def _ordered(modes: list[dict]) -> list[dict]:
        def key(mode: dict):
            ident = mode.get("id", "")
            return (ORDER.index(ident) if ident in ORDER else len(ORDER), mode.get("name", ""))

        return sorted(modes, key=key)

    def is_current(self, ident: str) -> bool:
        return self.backend.current_mode() == ident

    # ------------------------------------------------------------- actions
    def activate(self, ident: str) -> None:
        if not self.window:
            return
        if not self.window.runner.run(self.backend.apply_mode, ident):
            self.toast("Başka bir işlem sürüyor.", "danger")
            return
        self.toast("Mod uygulanıyor; gerekirse parola sorulacak…")
        self.window.runner.finished.connect(self._on_done)
        self.window.runner.failed.connect(self._on_failed)

    def _detach(self) -> None:
        if not self.window:
            return
        for signal, slot in (
            (self.window.runner.finished, self._on_done),
            (self.window.runner.failed, self._on_failed),
        ):
            try:
                signal.disconnect(slot)
            except TypeError:
                pass

    def _on_done(self, result) -> None:
        self._detach()
        if isinstance(result, dict):
            steps = result.get("steps", [])
            self.steps.show_steps(steps, "Adım kaydı yok.")
            ok = bool(result.get("ok"))
            failed = [s for s in steps if s.get("status") == "fail"]
            if ok:
                self.toast("Mod uygulandı.", "info")
            else:
                names = ", ".join(s.get("label", "?") for s in failed[:2]) or "adımlar"
                self.toast(
                    f"{len(failed)} adım uygulanamadı ({names}). "
                    "Ayrıntı aşağıdaki listede; donanım desteklemiyorsa mod "
                    "kısmen uygulanmış olur.",
                    "danger",
                )
        self.refresh()

    def _on_failed(self, message: str) -> None:
        self._detach()
        self.steps.show_steps([{"label": message, "status": "fail"}])
        self.toast(message, "danger")

    def refresh(self) -> None:
        for card in self.cards:
            card.set_current(self.is_current(card.mode["id"]))
