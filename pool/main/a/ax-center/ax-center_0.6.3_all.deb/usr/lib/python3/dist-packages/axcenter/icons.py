"""Menü simgeleri: emoji yok, QPainter ile çizilmiş küçük vektörler.

Neden: her sistemde emoji fontu yok (özellikle minimal KDE kurulumlarında)
ve eksik glif kutucuk olarak çizilir. 18 pikselde geometrik simge her yerde
aynı görünür ve tema rengine uyar.
"""

from __future__ import annotations

from PyQt6.QtCore import QPointF, QRectF, QSize, Qt
from PyQt6.QtGui import QColor, QIcon, QPainter, QPainterPath, QPen, QPixmap

DEFAULT = "#c9d4e8"


def _painter(pix: QPixmap, color: str, width: float = 1.6) -> QPainter:
    painter = QPainter(pix)
    painter.setRenderHint(QPainter.RenderHint.Antialiasing)
    pen = QPen(QColor(color))
    pen.setWidthF(width)
    pen.setCapStyle(Qt.PenCapStyle.RoundCap)
    pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
    painter.setPen(pen)
    painter.setBrush(Qt.BrushStyle.NoBrush)
    return painter


def pixmap(key: str, color: str = DEFAULT, size: int = 18) -> QPixmap:
    pix = QPixmap(size, size)
    pix.fill(Qt.GlobalColor.transparent)
    p = _painter(pix, color, max(1.2, size / 11))
    s = size
    u = s / 18.0  # ölçek

    if key == "overview":
        for x, y in ((2, 2), (10, 2), (2, 10), (10, 10)):
            p.drawRoundedRect(QRectF(x * u, y * u, 6 * u, 6 * u), 1.4, 1.4)

    elif key == "modes":
        bolt = QPainterPath()
        bolt.moveTo(QPointF(10.5 * u, 1.5 * u))
        bolt.lineTo(QPointF(4.0 * u, 10.0 * u))
        bolt.lineTo(QPointF(8.5 * u, 10.0 * u))
        bolt.lineTo(QPointF(7.0 * u, 16.5 * u))
        bolt.lineTo(QPointF(14.0 * u, 7.5 * u))
        bolt.lineTo(QPointF(9.5 * u, 7.5 * u))
        bolt.closeSubpath()
        p.fillPath(bolt, QColor(color))
        p.drawPath(bolt)

    elif key == "backups":
        shield = QPainterPath()
        shield.moveTo(QPointF(9 * u, 1.8 * u))
        shield.lineTo(QPointF(15.2 * u, 4.2 * u))
        shield.lineTo(QPointF(15.2 * u, 9.0 * u))
        shield.cubicTo(
            QPointF(15.2 * u, 13.2 * u), QPointF(12.2 * u, 15.6 * u), QPointF(9 * u, 16.6 * u)
        )
        shield.cubicTo(
            QPointF(5.8 * u, 15.6 * u), QPointF(2.8 * u, 13.2 * u), QPointF(2.8 * u, 9.0 * u)
        )
        shield.lineTo(QPointF(2.8 * u, 4.2 * u))
        shield.closeSubpath()
        p.drawPath(shield)
        tick = QPainterPath()
        tick.moveTo(QPointF(6.2 * u, 8.8 * u))
        tick.lineTo(QPointF(8.4 * u, 11.2 * u))
        tick.lineTo(QPointF(12.0 * u, 6.6 * u))
        p.drawPath(tick)

    elif key == "drivers":
        p.drawRoundedRect(QRectF(5 * u, 2.5 * u, 8 * u, 6 * u), 1.6, 1.6)
        p.drawLine(QPointF(7.2 * u, 8.5 * u), QPointF(7.2 * u, 11.5 * u))
        p.drawLine(QPointF(10.8 * u, 8.5 * u), QPointF(10.8 * u, 11.5 * u))
        p.drawLine(QPointF(9 * u, 11.5 * u), QPointF(9 * u, 15.5 * u))

    elif key == "software":
        p.drawRoundedRect(QRectF(2.6 * u, 5.4 * u, 12.8 * u, 9.6 * u), 1.6, 1.6)
        p.drawLine(QPointF(2.6 * u, 8.6 * u), QPointF(15.4 * u, 8.6 * u))
        p.drawLine(QPointF(9 * u, 5.4 * u), QPointF(9 * u, 15.0 * u))

    elif key == "system":
        for index, y in enumerate((4.5, 9.0, 13.5)):
            p.drawLine(QPointF(2.6 * u, y * u), QPointF(15.4 * u, y * u))
            x = (6.5 if index != 1 else 11.5) * u
            p.setBrush(QColor(color))
            p.drawEllipse(QPointF(x, y * u), 2.0 * u, 2.0 * u)
            p.setBrush(Qt.BrushStyle.NoBrush)

    elif key == "privacy":
        p.drawRoundedRect(QRectF(4.2 * u, 8.2 * u, 9.6 * u, 7.4 * u), 1.8, 1.8)
        shackle = QPainterPath()
        shackle.moveTo(QPointF(6.4 * u, 8.2 * u))
        shackle.lineTo(QPointF(6.4 * u, 6.2 * u))
        shackle.cubicTo(
            QPointF(6.4 * u, 2.6 * u), QPointF(11.6 * u, 2.6 * u), QPointF(11.6 * u, 6.2 * u)
        )
        shackle.lineTo(QPointF(11.6 * u, 8.2 * u))
        p.drawPath(shackle)

    elif key == "about":
        p.drawEllipse(QRectF(2.6 * u, 2.6 * u, 12.8 * u, 12.8 * u))
        p.setBrush(QColor(color))
        p.drawEllipse(QPointF(9 * u, 6.2 * u), 1.0 * u, 1.0 * u)
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawLine(QPointF(9 * u, 9.0 * u), QPointF(9 * u, 13.0 * u))

    elif key == "refresh":
        arc = QPainterPath()
        arc.arcMoveTo(QRectF(3.2 * u, 3.2 * u, 11.6 * u, 11.6 * u), 55)
        arc.arcTo(QRectF(3.2 * u, 3.2 * u, 11.6 * u, 11.6 * u), 55, 265)
        p.drawPath(arc)
        arrow = QPainterPath()
        arrow.moveTo(QPointF(11.6 * u, 1.8 * u))
        arrow.lineTo(QPointF(12.4 * u, 4.6 * u))
        arrow.lineTo(QPointF(9.6 * u, 4.2 * u))
        p.drawPath(arrow)

    elif key == "bolt":
        bolt = QPainterPath()
        bolt.moveTo(QPointF(9.5 * u, 2.0 * u))
        bolt.lineTo(QPointF(4.5 * u, 10.0 * u))
        bolt.lineTo(QPointF(9.0 * u, 10.0 * u))
        bolt.lineTo(QPointF(8.0 * u, 16.0 * u))
        bolt.lineTo(QPointF(13.5 * u, 8.0 * u))
        bolt.lineTo(QPointF(9.0 * u, 8.0 * u))
        bolt.closeSubpath()
        p.fillPath(bolt, QColor(color))

    else:  # bilinmeyen anahtar: nokta
        p.setBrush(QColor(color))
        p.drawEllipse(QPointF(9 * u, 9 * u), 2.0 * u, 2.0 * u)

    p.end()
    return pix


def icon(key: str, color: str = DEFAULT, size: int = 18) -> QIcon:
    return QIcon(pixmap(key, color, size))


def icon_size(size: int = 18) -> QSize:
    return QSize(size, size)
