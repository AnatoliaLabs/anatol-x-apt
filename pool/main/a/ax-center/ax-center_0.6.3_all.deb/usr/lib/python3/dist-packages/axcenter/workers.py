"""Arka plan işçisi: pkexec/polkit diyaloğu GUI'yi dondurmasın."""

from __future__ import annotations

from PyQt6.QtCore import QObject, QThread, pyqtSignal


class Worker(QThread):
    done = pyqtSignal(object)
    failed = pyqtSignal(str)

    def __init__(self, func, *args, parent: QObject | None = None, **kwargs) -> None:
        super().__init__(parent)
        self._func = func
        self._args = args
        self._kwargs = kwargs

    def run(self) -> None:
        try:
            self.done.emit(self._func(*self._args, **self._kwargs))
        except Exception as exc:  # AnatolError dahil
            self.failed.emit(str(exc))


class TaskRunner(QObject):
    """Basit tek iş sırası: aynı anda iki parola istemi açılmasın."""

    busy_changed = pyqtSignal(bool)
    finished = pyqtSignal(object)
    failed = pyqtSignal(str)

    def __init__(self, parent: QObject | None = None) -> None:
        super().__init__(parent)
        self._worker: Worker | None = None

    @property
    def busy(self) -> bool:
        return self._worker is not None and self._worker.isRunning()

    def run(self, func, *args, **kwargs) -> bool:
        if self.busy:
            return False
        worker = Worker(func, *args, parent=self, **kwargs)
        worker.done.connect(self._on_done)
        worker.failed.connect(self._on_failed)
        worker.finished.connect(self._on_thread_finished)
        self._worker = worker
        self.busy_changed.emit(True)
        worker.start()
        return True

    def _on_done(self, result) -> None:
        self.finished.emit(result)

    def _on_failed(self, message) -> None:
        self.failed.emit(message)

    def _on_thread_finished(self) -> None:
        self._worker = None
        self.busy_changed.emit(False)
