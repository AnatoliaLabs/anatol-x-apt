"""systemd service toggling with a hard-coded safety net.

A mode switch may stop services, but it must never be able to log you out or
cut the network out from under the package manager. Anything in PROTECTED is
refused even if a profile file asks for it.
"""

from __future__ import annotations

from .util import SERVICE_RE, Step, run

PROTECTED = {
    "dbus.service",
    "dbus-broker.service",
    "systemd-logind.service",
    "systemd-journald.service",
    "systemd-udevd.service",
    "polkit.service",
    "accounts-daemon.service",
    "networkmanager.service",
    "systemd-resolved.service",
    "sddm.service",
    "lightdm.service",
    "gdm.service",
    "display-manager.service",
    "sshd.service",
    "apparmor.service",
    "cron.service",
}

VERBS = ("start", "stop", "restart", "enable", "disable")


def is_active(unit: str) -> bool:
    res = run(["systemctl", "is-active", unit], timeout=10)
    return res.stdout.strip() == "active"


def is_enabled(unit: str) -> bool:
    res = run(["systemctl", "is-enabled", unit], timeout=10)
    return res.stdout.strip() in ("enabled", "enabled-runtime", "static")


def exists(unit: str) -> bool:
    res = run(["systemctl", "list-unit-files", "--no-legend", unit], timeout=15)
    return bool(res.stdout.strip())


def control(unit: str, verb: str, *, dry_run: bool = False) -> Step:
    if not SERVICE_RE.match(unit or ""):
        return Step(f"{unit}: {verb}", ok=False, detail="geçersiz servis adı")
    if verb not in VERBS:
        return Step(f"{unit}: {verb}", ok=False, detail="geçersiz işlem")
    if unit in PROTECTED:
        return Step(
            f"{unit}: {verb}",
            skipped=True,
            detail="korunan servis (oturum/ağ/oturum açma) — dokunulmadı",
        )
    if not exists(unit):
        return Step(f"{unit}: {verb}", skipped=True, detail="bu sistemde kurulu değil")
    res = run(["systemctl", verb, unit], dry_run=dry_run, timeout=90)
    return Step(
        f"{unit}: {verb}",
        ok=res.returncode == 0,
        detail=(res.stderr or res.stdout).strip()[:200],
    )


def apply(stop=(), start=(), *, dry_run: bool = False) -> list[Step]:
    steps = [control(unit, "stop", dry_run=dry_run) for unit in stop]
    steps += [control(unit, "start", dry_run=dry_run) for unit in start]
    return steps


def list_user_services() -> list[dict]:
    """Small, honest service list for the GUI (no filtering magic)."""
    res = run(
        ["systemctl", "list-units", "--type=service", "--no-legend", "--no-pager", "--all"],
        timeout=20,
    )
    out = []
    for line in res.stdout.splitlines():
        parts = line.split(None, 4)
        if len(parts) < 4 or not parts[0].endswith(".service"):
            continue
        out.append(
            {
                "unit": parts[0],
                "load": parts[1],
                "active": parts[2],
                "sub": parts[3],
                "description": parts[4] if len(parts) > 4 else "",
                "protected": parts[0] in PROTECTED,
            }
        )
    return out
