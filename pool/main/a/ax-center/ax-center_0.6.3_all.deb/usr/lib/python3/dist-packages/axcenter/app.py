"""Uygulama girişi.

    ax-center              normal başlatma
    ax-center --demo       gerçek sisteme dokunmadan arayüz (tasarım/test)
    ax-center --screenshot out/   her sayfayı PNG olarak kaydet (dokümantasyon)
"""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

from PyQt6.QtGui import QIcon
from PyQt6.QtWidgets import QApplication

from . import APP_NAME, VERSION
from .backend import Backend
from .theme import apply_fonts, colors, stylesheet
from .window import MainWindow, brand_pixmap

NAV_KEYS = ["overview", "modes", "backups", "drivers", "software", "system", "privacy", "about"]


def build_app(argv: list[str]) -> QApplication:
    app = QApplication(argv)
    app.setApplicationName(APP_NAME)
    app.setApplicationVersion(VERSION)
    app.setOrganizationName("Anatol-X")
    app.setDesktopFileName("ax-center")  # .desktop dosya adıyla aynı olmalı (görev çubuğu gruplaması)
    app.setWindowIcon(QIcon(brand_pixmap(128)))
    apply_fonts(app)
    app.setStyleSheet(stylesheet(colors(app)))
    return app


def main(argv: list[str] | None = None) -> int:
    argv = list(sys.argv if argv is None else argv)
    parser = argparse.ArgumentParser(prog="ax-center", add_help=True)
    from . import VERSION

    parser.add_argument(
        "--version",
        action="version",
        version=f"AX-Center {VERSION} (Anatol-X)",
        help="sürümü yaz ve çık (grafik oturum gerekmez)",
    )
    parser.add_argument("--demo", action="store_true", help="gerçek sisteme dokunma")
    parser.add_argument("--screenshot", metavar="DIR", help="sayfaları PNG olarak kaydet")
    parser.add_argument(
        "--scale", type=float, default=2.0, help="ekran görüntüsü ölçeği (varsayılan 2)"
    )
    args, qt_args = parser.parse_known_args(argv[1:])

    if args.demo:
        os.environ["AX_CENTER_DEMO"] = "1"

    app = build_app([argv[0], *qt_args])
    window = MainWindow(Backend())

    if args.screenshot:
        return _screenshot(window, Path(args.screenshot), args.scale)

    window.show()
    return app.exec()


def _screenshot(window: MainWindow, directory: Path, scale: float = 2.0) -> int:
    """Her sayfayı gerçek widget'lardan 2x çözünürlükte render et."""
    from PyQt6.QtGui import QImage, QPainter

    directory.mkdir(parents=True, exist_ok=True)
    if window.backend.demo:
        # Ekran görüntüleri bir kullanıcının "profil uyguladıktan sonraki" hâlini
        # göstersin: demo profili gerçek demo yolundan uygulanıyor (sisteme
        # dokunmaz, yalnızca demo durumunu değiştirir).
        window.backend.apply_mode("eco")
    window.resize(1280, 900)
    window.show()
    QApplication.processEvents()
    for key in NAV_KEYS:
        window.go_to(key, animate=False)
        QApplication.processEvents()
        window.repaint()
        QApplication.processEvents()
        base = window.size()
        image = QImage(
            int(base.width() * scale), int(base.height() * scale), QImage.Format.Format_ARGB32
        )
        # QPainter, paint device'in devicePixelRatio'sunu kendisi uygular;
        # ayrıca scale() çağırmak 4x'e çıkarır (bir kez bu hata yapıldı).
        image.setDevicePixelRatio(scale)
        image.fill(0)
        painter = QPainter(image)
        window.render(painter)
        painter.end()
        path = directory / f"{key}.png"
        image.save(str(path), "PNG")
        print(path)
    window.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
