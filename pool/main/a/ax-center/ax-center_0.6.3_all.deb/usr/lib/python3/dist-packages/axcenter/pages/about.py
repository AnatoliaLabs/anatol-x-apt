"""Hakkında: sürüm, bağlantılar, log paketleme."""

from __future__ import annotations

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import QFrame, QHBoxLayout, QLabel, QPushButton, QVBoxLayout, QWidget

from .. import TAGLINE, VERSION
from ..brand import brand_pixmap
from ..widgets import Card, Page, Pill, card_grid, label, mono, muted, section


class AboutPage(Page):
    title = "Hakkında"
    subtitle = f"{TAGLINE} · AX-Center {VERSION}"

    def build(self) -> None:
        self.layout.addWidget(self._hero())

        self.version_card = Card("Sürüm", VERSION, f"{TAGLINE} · {VERSION}")
        self.version_card.add_pill(Pill("alfa", "accent"))
        self.mode_card = Card("Çalışma modu", "—")
        self.mode_pill = Pill("—", "muted")
        self.mode_card.add_pill(self.mode_pill)
        self.license_card = Card(
            "Lisans", "GPL-3.0-or-later", "Debian 13 (trixie) · Python 3.13 · PyQt6"
        )
        self.helper_card = Card(
            "Ayrıcalık modeli",
            "pkexec + polkit",
            "Arayüz yetkisiz çalışır; yalnızca izin listesindeki komutlar "
            "anatol-helper üzerinden root ile çalışır.",
        )
        self.layout.addLayout(
            card_grid(
                [
                    self.version_card,
                    self.mode_card,
                    self.license_card,
                    self.helper_card,
                ],
                2,
            )
        )

        self.layout.addWidget(section("Hata raporu", "kişisel veri toplamaz"))
        self.layout.addWidget(
            muted(
                "Log paketi; journal, donanım dökümü, paket listesi ve "
                "/etc/anatol içeriğini tek bir tar.gz'de toplar ve ev dizinine "
                "bırakır. Parola, anahtar ya da kişisel dosya toplanmaz."
            )
        )
        row = QHBoxLayout()
        self.btn_log = QPushButton("Log paketle")
        self.btn_log.setObjectName("primary")
        self.btn_log.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_log.clicked.connect(self.bundle)
        row.addWidget(self.btn_log)
        row.addStretch(1)
        self.layout.addLayout(row)
        self.result = QLabel("")
        self.result.setObjectName("Muted")
        self.result.setWordWrap(True)
        self.layout.addWidget(self.result)

        self.layout.addWidget(section("Bağlantılar"))
        self.layout.addWidget(
            mono("web    anatol-x.org\nmatriks  #anatol-x\nhata     git.anatol-x.org/ax-center")
        )
        self.layout.addStretch(1)

    def _hero(self) -> QWidget:
        """Marka bloğu: logo, ad, sürüm ve kısa tanıtım."""
        hero = QFrame()
        hero.setObjectName("Hero")
        box = QHBoxLayout(hero)
        box.setContentsMargins(18, 16, 18, 16)
        box.setSpacing(16)

        logo = QLabel()
        logo.setPixmap(brand_pixmap(56))
        logo.setFixedSize(56, 56)
        box.addWidget(logo, 0, Qt.AlignmentFlag.AlignTop)

        text = QVBoxLayout()
        text.setSpacing(2)
        text.addWidget(label("AX-Center", "HeroTitle"))
        text.addWidget(
            label("Anatol-X kontrol merkezi", "HeroSubtitle")
        )
        text.addWidget(
            muted(
                "Modlar, yedekler, sürücüler ve sistem bakımı tek pencerede. "
                "Tüm yetkili işler polkit üzerinden tek parolayla onaylanır."
            )
        )
        box.addLayout(text, 1)
        return hero

    def refresh(self) -> None:
        demo = self.backend.demo
        self.mode_card.set_value(
            "DEMO" if demo else "Canlı sistem",
            "gerçek sisteme dokunulmuyor" if demo else "anatol-helper bulundu",
        )
        self.mode_pill.setText("demo" if demo else "canlı")
        self.mode_pill.set_kind("warn" if demo else "ok")

    def bundle(self) -> None:
        if not self.window or not self.window.runner.run(self.backend.log_bundle):
            return
        self.toast("Log paketi hazırlanıyor…")
        self.window.runner.finished.connect(self._done)
        self.window.runner.failed.connect(self._failed)

    def _detach(self) -> None:
        if not self.window:
            return
        for signal, slot in (
            (self.window.runner.finished, self._done),
            (self.window.runner.failed, self._failed),
        ):
            try:
                signal.disconnect(slot)
            except TypeError:
                pass

    def _done(self, result) -> None:
        self._detach()
        if isinstance(result, dict) and result.get("ok"):
            self.result.setText(f"Paket: {result.get('path')}")
            self.toast("Log paketi oluşturuldu.")
        else:
            self.result.setText("Paket oluşturulamadı.")
            self.toast("Log paketi oluşturulamadı.", "danger")

    def _failed(self, message: str) -> None:
        self._detach()
        self.result.setText(message)
        self.toast(message, "danger")
