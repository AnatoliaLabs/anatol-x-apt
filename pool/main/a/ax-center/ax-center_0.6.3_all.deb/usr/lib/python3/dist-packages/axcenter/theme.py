"""Tasarım sistemi: renk, tipografi, ölçü ve global stil sayfası.

Tek kaynak burasıdır: sayfalar renk kodlamaz, `theme.colors()` sözlüğünü ve
`theme.stylesheet()` çıktısını kullanır.

Görsel dil (v0.6 "konsept"): katmanlı yüzeyler, cyan→violet gradyan yalnızca
etkin/vurgulu öğelerde, 20 px yarıçap, ince hairline kenarlıklar. Qt'de
`backdrop-filter` ya da `box-shadow` yok; cam etkisi yarı saydam gradyanla,
derinlik ise kenarlık + üst iç ışık (1 px açık çizgi) ile taklit edilir.
"""

from __future__ import annotations

import os

from PyQt6.QtCore import Qt
from PyQt6.QtGui import QFont, QFontDatabase, QPalette

# --------------------------------------------------------------------------
# renk belirteçleri
# --------------------------------------------------------------------------
DARK = {
    "bg": "#070a10",
    "bg_elev": "#0a0e16",
    "surface": "#101620",
    "surface2": "#151c28",
    "surface3": "#1c2432",
    "border": "rgba(255, 255, 255, 0.075)",
    "border_soft": "rgba(255, 255, 255, 0.05)",
    "border_strong": "rgba(255, 255, 255, 0.13)",
    "text": "#eef3fb",
    "text_dim": "#9aa9be",
    "text_faint": "#65748b",
    "accent": "#22d3ee",
    "accent_text": "#67e8f9",
    "accent_2": "#7c5cff",
    "accent_soft": "rgba(34, 211, 238, 0.13)",
    "accent_line": "rgba(34, 211, 238, 0.42)",
    "danger": "#fb7185",
    "danger_soft": "rgba(251, 113, 133, 0.12)",
    "warn": "#fbbf24",
    "warn_soft": "rgba(251, 191, 36, 0.12)",
    "ok": "#34d399",
    "ok_soft": "rgba(52, 211, 153, 0.12)",
    "mono": "#b9c7dd",
    "on_accent": "#04121a",
    "row": "rgba(127, 145, 175, 0.06)",
}

LIGHT = {
    "bg": "#f1f5fb",
    "bg_elev": "#ffffff",
    "surface": "#ffffff",
    "surface2": "#f7f9fd",
    "surface3": "#eaeff8",
    "border": "rgba(16, 32, 56, 0.13)",
    "border_soft": "rgba(16, 32, 56, 0.09)",
    "border_strong": "rgba(16, 32, 56, 0.20)",
    "text": "#0b1624",
    "text_dim": "#4c5d76",
    "text_faint": "#7386a0",
    "accent": "#0891b2",
    "accent_text": "#0e7490",
    "accent_2": "#6d4df0",
    "accent_soft": "rgba(8, 145, 178, 0.10)",
    "accent_line": "rgba(8, 145, 178, 0.40)",
    "danger": "#d92d4b",
    "danger_soft": "rgba(217, 45, 75, 0.09)",
    "warn": "#b4740a",
    "warn_soft": "rgba(180, 116, 10, 0.10)",
    "ok": "#0f9d76",
    "ok_soft": "rgba(15, 157, 118, 0.10)",
    "mono": "#3d4a61",
    "on_accent": "#ffffff",
    "row": "rgba(16, 32, 56, 0.04)",
}

# Ölçü sistemi (px). Tüm boşluklar bu ölçeğin katı.
SPACE = {"xs": 4, "sm": 8, "md": 12, "lg": 16, "xl": 24, "2xl": 32}
RADIUS = {"sm": 10, "md": 14, "lg": 20}

UI_FAMILIES = ["Inter", "Noto Sans", "Cantarell", "Noto Sans CJK SC", "DejaVu Sans"]
MONO_FAMILIES = ["JetBrains Mono", "Source Code Pro", "DejaVu Sans Mono", "Noto Sans Mono CJK SC"]


def _first_available(candidates: list[str], fallback: str) -> str:
    installed = set(QFontDatabase.families())
    for name in candidates:
        if name in installed:
            return name
    return fallback


def ui_font(size_pt: float = 10.0, weight: QFont.Weight = QFont.Weight.Normal) -> QFont:
    font = QFont(_first_available(UI_FAMILIES, "DejaVu Sans"))
    font.setPointSizeF(size_pt)
    font.setWeight(weight)
    font.setHintingPreference(QFont.HintingPreference.PreferDefaultHinting)
    return font


def mono_font(size_pt: float = 9.0) -> QFont:
    font = QFont(_first_available(MONO_FAMILIES, "DejaVu Sans Mono"))
    font.setPointSizeF(size_pt)
    return font


def apply_fonts(app) -> None:
    """Uygulama geneli tipografi: sistemde Inter varsa o, yoksa Noto/DejaVu."""
    app.setFont(ui_font(10))


def is_dark(app) -> bool:
    """Breeze açık/koyu tercihine uy: Qt 6.5+ colorScheme, yoksa palet parlaklığı."""
    try:
        scheme = app.styleHints().colorScheme()
        if scheme == Qt.ColorScheme.Dark:
            return True
        if scheme == Qt.ColorScheme.Light:
            return False
    except (AttributeError, TypeError):
        pass
    window = app.palette().color(QPalette.ColorRole.Window)
    return window.lightness() < 128


def colors(app) -> dict:
    """AX_CENTER_THEME=dark|light ile sistem tercihi ezilebilir (test/ekran görüntüsü)."""
    forced = os.environ.get("AX_CENTER_THEME", "").lower()
    if forced == "dark":
        set_current(DARK)
        return DARK
    if forced == "light":
        set_current(LIGHT)
        return LIGHT
    chosen = DARK if is_dark(app) else LIGHT
    set_current(chosen)
    return chosen


# --------------------------------------------------------------------------
# gradyan yardımcıları (QSS)
# --------------------------------------------------------------------------
_CURRENT: dict = {"colors": DARK}


def set_current(c: dict) -> None:
    """Özel çizim yapan widget'lar (halka, çubuk) için son çözülen renk seti."""
    _CURRENT["colors"] = c


def current() -> dict:
    return _CURRENT["colors"]


def accent_gradient() -> str:
    """Birincil düğme / etkin öğe gradyanı."""
    return "qlineargradient(x1:0, y1:0, x2:1, y2:0.6, stop:0 #3ee8ff, stop:0.5 #22d3ee, stop:1 #7c5cff)"


def brand_gradient() -> str:
    return "qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #3ee8ff, stop:1 #7c5cff)"


def panel_gradient(c: dict) -> str:
    """Kart yüzeyi: üstte hafif ışık, altta gövde rengi (cam hissi)."""
    if c is LIGHT:
        return f"qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #ffffff, stop:1 {c['surface2']})"
    return (
        "qlineargradient(x1:0, y1:0, x2:0, y2:1, "
        "stop:0 rgba(255, 255, 255, 0.055), stop:1 rgba(255, 255, 255, 0.012))"
    )


def active_nav_gradient() -> str:
    return (
        "qlineargradient(x1:0, y1:0, x2:1, y2:0, "
        "stop:0 rgba(34, 211, 238, 0.18), stop:1 rgba(124, 92, 255, 0.07))"
    )


# --------------------------------------------------------------------------
# stil sayfası
# --------------------------------------------------------------------------
def stylesheet(c: dict) -> str:
    set_current(c)
    panel = panel_gradient(c)
    return f"""
    /* ---- temel ---- */
    QWidget {{
        color: {c['text']};
        font-size: 10pt;
        selection-background-color: {c['accent_soft']};
        selection-color: {c['text']};
    }}
    QMainWindow, #Root, #Page, #Body, #ScrollBody {{ background: {c['bg']}; }}
    QLabel, QCheckBox, QRadioButton {{ background: transparent; }}
    QScrollArea, QScrollArea > QWidget > QWidget {{ background: transparent; }}
    QToolTip {{
        background: {c['surface3']};
        color: {c['text']};
        border: 1px solid {c['border_strong']};
        border-radius: 8px;
        padding: 6px 9px;
    }}

    /* ---- üst bar / kenar çubuğu ---- */
    #TopBar {{
        background: {c['bg_elev']};
        border-bottom: 1px solid {c['border_soft']};
    }}
    #CrumbRoot {{ color: {c['text_faint']}; font-size: 9pt; }}
    #CrumbSep {{ color: {c['text_faint']}; font-size: 9pt; }}
    #CrumbCurrent {{ color: {c['text']}; font-size: 9pt; font-weight: 600; }}

    #Sidebar {{
        background: {c['bg_elev']};
        border-right: 1px solid {c['border_soft']};
    }}
    #BrandName {{ font-size: 12.5pt; font-weight: 700; }}
    #BrandTag {{ color: {c['text_faint']}; font-size: 8pt; }}
    #NavSection {{
        color: {c['text_faint']};
        font-size: 7.5pt;
        font-weight: 700;
        padding: 10px 0 2px 12px;
    }}
    QPushButton[nav="true"] {{
        text-align: left;
        padding: 7px 10px 7px 13px;
        border: none;
        border-left: 2px solid transparent;
        border-radius: {RADIUS['sm']}px;
        background: transparent;
        color: {c['text_dim']};
        font-size: 9.5pt;
    }}
    QPushButton[nav="true"]:hover {{
        background: {c['row']};
        color: {c['text']};
    }}
    QPushButton[nav="true"]:checked {{
        background: {active_nav_gradient()};
        border-left: 2px solid {c['accent']};
        color: {c['text']};
        font-weight: 600;
    }}
    #KbdHint {{
        color: {c['text_faint']};
        font-size: 7pt;
        border: 1px solid {c['border']};
        border-radius: 4px;
        padding: 0px 4px;
    }}
    #DevCard {{
        background: {c['surface']};
        border: 1px solid {c['border_soft']};
        border-radius: {RADIUS['md']}px;
    }}
    #DevLabel {{ color: {c['text_faint']}; font-size: 7pt; font-weight: 700; }}
    #DevValue {{ color: {c['text']}; font-size: 8.5pt; font-weight: 600; }}
    #DevMono {{ color: {c['mono']}; font-size: 8pt; }}
    #VersionTag {{ color: {c['text_faint']}; font-size: 8pt; }}

    /* ---- üst bar parçaları ---- */
    #SearchBox {{
        background: {c['surface']};
        border: 1px solid {c['border_soft']};
        border-radius: {RADIUS['sm']}px;
    }}
    #SearchBox:focus-within {{ border-color: {c['accent_line']}; }}
    QLineEdit#SearchInput {{
        background: transparent;
        border: none;
        padding: 0px;
        color: {c['text']};
        font-size: 9pt;
    }}
    #SearchHint {{ color: {c['text_faint']}; font-size: 7.5pt; }}
    #Chip {{
        background: {c['surface']};
        border: 1px solid {c['border_soft']};
        border-radius: {RADIUS['sm']}px;
    }}
    #ChipText {{ color: {c['text_dim']}; font-size: 8.5pt; }}
    #IconButton {{
        background: {c['surface']};
        border: 1px solid {c['border_soft']};
        border-radius: {RADIUS['sm']}px;
    }}
    #IconButton:hover {{ border-color: {c['accent_line']}; background: {c['surface2']}; }}

    /* ---- tipografi ---- */
    #PageTitle {{ font-size: 19pt; font-weight: 700; }}
    #PageSub {{ color: {c['text_dim']}; font-size: 9pt; }}
    #SectionTitle {{ font-size: 10pt; font-weight: 700; }}
    #SectionHint {{ color: {c['text_faint']}; font-size: 8.5pt; }}
    #Eyebrow {{ color: {c['text_faint']}; font-size: 7.5pt; font-weight: 700; }}
    #Muted {{ color: {c['text_dim']}; }}
    #Faint {{ color: {c['text_faint']}; font-size: 9pt; }}
    #Accent {{ color: {c['accent_text']}; }}
    #Danger {{ color: {c['danger']}; }}
    #Ok {{ color: {c['ok']}; }}
    #Mono {{ color: {c['mono']}; font-size: 8.5pt; }}
    #ValueMono {{ color: {c['text']}; font-size: 10pt; font-weight: 600; }}

    /* ---- kartlar ---- */
    #Card {{
        background: {panel};
        border: 1px solid {c['border_soft']};
        border-radius: {RADIUS['lg']}px;
    }}
    #Card[accent="true"] {{
        border: 1px solid {c['accent_line']};
    }}
    #CardLabel {{ color: {c['text_faint']}; font-size: 7.5pt; font-weight: 700; }}
    #CardValue {{ font-size: 15pt; font-weight: 700; }}
    #CardValue[small="true"] {{ font-size: 11pt; }}
    #CardHint {{ color: {c['text_dim']}; font-size: 8.5pt; }}
    #Hairline {{ background: {c['border_soft']}; max-height: 1px; min-height: 1px; }}

    /* ---- hero ---- */
    #HeroCard {{
        background: {panel};
        border: 1px solid {c['border_soft']};
        border-radius: {RADIUS['lg']}px;
    }}
    #HeroTitle {{ font-size: 23pt; font-weight: 700; }}
    #HeroSub {{ color: {c['text_dim']}; font-size: 9pt; }}
    #HeroTag {{
        color: {c['text_dim']};
        font-size: 8pt;
        background: {c['row']};
        border: 1px solid {c['border_soft']};
        border-radius: 7px;
        padding: 3px 8px;
    }}
    #HeroTag b {{ color: {c['text']}; }}

    /* ---- KPI / profil / zincir ---- */
    #Kpi {{ background: {panel}; border: 1px solid {c['border_soft']}; border-radius: {RADIUS['md']}px; }}
    #KpiValue {{ font-size: 14pt; font-weight: 700; }}
    #KpiSmall {{ color: {c['text_dim']}; font-size: 8pt; }}
    #KpiIcon {{
        color: {c['accent_text']};
        background: {c['row']};
        border: 1px solid {c['border_soft']};
        border-radius: 8px;
        font-size: 9pt;
    }}
    #Pcard {{
        background: {panel};
        border: 1px solid {c['border_soft']};
        border-radius: {RADIUS['md']}px;
    }}
    #Pcard:hover {{ border-color: {c['accent_line']}; }}
    #Pcard[active="true"] {{
        border: 1px solid {c['accent_line']};
        background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
            stop:0 rgba(34, 211, 238, 0.11), stop:1 rgba(124, 92, 255, 0.05));
    }}
    #PcardName {{ font-size: 10.5pt; font-weight: 700; }}
    #PcardSub {{ color: {c['text_faint']}; font-size: 8pt; }}

    #Panel {{ background: {panel}; border: 1px solid {c['border_soft']}; border-radius: {RADIUS['lg']}px; }}
    #ChainRow:hover {{ background: {c['row']}; }}
    #ChainTitle {{ font-size: 9pt; font-weight: 600; }}
    #ChainSub {{ color: {c['text_faint']}; font-size: 8pt; }}
    #ChainWhen {{ color: {c['text_dim']}; font-size: 8pt; }}
    #HealthName {{ color: {c['text_dim']}; font-size: 8.5pt; }}
    #HealthValue {{ font-size: 8.5pt; font-weight: 600; }}

    #Qcard {{
        background: {panel};
        border: 1px solid {c['border_soft']};
        border-radius: {RADIUS['md']}px;
        text-align: left;
        padding: 0px;
    }}
    #Qcard:hover {{ border-color: {c['accent_line']}; background: {c['surface2']}; }}
    #QcardTitle {{ font-size: 8.5pt; font-weight: 600; }}
    #QcardSub {{ color: {c['text_faint']}; font-size: 7.5pt; }}
    #QcardIcon {{
        color: {c['accent_text']};
        background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
            stop:0 rgba(34, 211, 238, 0.18), stop:1 rgba(124, 92, 255, 0.12));
        border: 1px solid {c['border_soft']};
        border-radius: 8px;
        font-size: 9pt;
    }}

    /* ---- düğmeler ---- */
    QPushButton {{
        background: {c['surface2']};
        border: 1px solid {c['border_soft']};
        border-radius: {RADIUS['sm']}px;
        padding: 6px 14px;
        color: {c['text']};
        font-size: 9pt;
    }}
    QPushButton:hover {{ border-color: {c['border_strong']}; background: {c['surface3']}; }}
    QPushButton:pressed {{ background: {c['surface']}; }}
    QPushButton:disabled {{
        color: {c['text_faint']};
        border-color: {c['border_soft']};
        background: transparent;
    }}
    QPushButton:focus {{ border-color: {c['accent_line']}; }}
    QPushButton#primary {{
        background: {accent_gradient()};
        color: {c['on_accent']};
        border: 1px solid {c['accent']};
        font-weight: 700;
    }}
    QPushButton#primary:hover {{ border-color: {c['accent_text']}; }}
    QPushButton#primary:disabled {{ background: {c['surface2']}; color: {c['text_faint']}; }}
    QPushButton#danger {{
        background: transparent;
        border: 1px solid {c['danger']};
        color: {c['danger']};
        font-weight: 600;
    }}
    QPushButton#danger:hover {{ background: {c['danger_soft']}; }}
    QPushButton#ghost {{
        background: transparent;
        border: 1px solid transparent;
        color: {c['text_dim']};
        padding: 6px 10px;
    }}
    QPushButton#ghost:hover {{ background: {c['row']}; color: {c['text']}; }}
    QPushButton#ghost:checked {{ color: {c['accent_text']}; background: {c['row']}; }}
    QPushButton#flat {{
        background: {c['row']};
        border: 1px solid {c['border_soft']};
        color: {c['text']};
    }}
    QPushButton#flat:hover {{ border-color: {c['accent_line']}; color: {c['accent_text']}; }}
    QPushButton#subtle {{
        background: transparent;
        border: 1px solid {c['border']};
        color: {c['accent_text']};
        font-weight: 600;
    }}
    QPushButton#subtle:hover {{ background: {c['accent_soft']}; border-color: {c['accent']}; }}

    /* ---- tablo ---- */
    QTableWidget, QTableView {{
        background: {c['surface']};
        alternate-background-color: {c['surface2']};
        border: 1px solid {c['border_soft']};
        border-radius: {RADIUS['md']}px;
        gridline-color: transparent;
        selection-background-color: {c['accent_soft']};
        selection-color: {c['text']};
        outline: none;
    }}
    QTableWidget::item {{ padding: 7px 8px; border: none; }}
    QTableWidget::item:selected {{ background: {c['accent_soft']}; }}
    QHeaderView::section {{
        background: {c['surface2']};
        color: {c['text_faint']};
        border: none;
        border-bottom: 1px solid {c['border_soft']};
        padding: 8px;
        font-size: 7.5pt;
        font-weight: 700;
    }}
    QTableCornerButton::section {{ background: {c['surface2']}; border: none; }}

    /* ---- liste / girdi ---- */
    QListWidget, QPlainTextEdit, QTextEdit, QLineEdit {{
        background: {c['surface']};
        border: 1px solid {c['border_soft']};
        border-radius: {RADIUS['md']}px;
        padding: 6px;
        color: {c['text']};
    }}
    QLineEdit {{ padding: 7px 10px; }}
    QLineEdit:focus {{ border-color: {c['accent_line']}; }}
    QListWidget::item {{ padding: 7px; border-radius: 6px; }}
    QListWidget::item:selected {{ background: {c['accent_soft']}; color: {c['text']}; }}

    /* ---- ilerleme ---- */
    QProgressBar {{
        background: {c['surface3']};
        border: none;
        border-radius: 3px;
        height: 5px;
        text-align: center;
    }}
    QProgressBar::chunk {{ background: {accent_gradient()}; border-radius: 3px; }}
    QProgressBar[level="ok"]::chunk {{ background: {c['ok']}; }}
    QProgressBar[level="warn"]::chunk {{ background: {c['warn']}; }}
    QProgressBar[level="danger"]::chunk {{ background: {c['danger']}; }}

    /* ---- onay kutuları ---- */
    QCheckBox {{ spacing: 9px; font-size: 9pt; }}
    QCheckBox::indicator {{
        width: 16px; height: 16px;
        border-radius: 5px;
        border: 1px solid {c['border']};
        background: {c['surface2']};
    }}
    QCheckBox::indicator:checked {{
        background: {c['accent']};
        border-color: {c['accent']};
    }}

    /* ---- kaydırma ---- */
    QScrollBar:vertical {{ background: transparent; width: 10px; margin: 2px 2px 2px 0; }}
    QScrollBar::handle:vertical {{
        background: {c['surface3']};
        border-radius: 4px;
        min-height: 28px;
    }}
    QScrollBar::handle:vertical:hover {{ background: {c['text_faint']}; }}
    QScrollBar::add-line, QScrollBar::sub-line {{ height: 0; width: 0; }}
    QScrollBar:horizontal {{ background: transparent; height: 10px; }}
    QScrollBar::handle:horizontal {{
        background: {c['surface3']};
        border-radius: 4px;
        min-width: 28px;
    }}

    /* ---- bildirim ve durum ---- */
    #Toast {{
        background: {c['surface3']};
        border: 1px solid {c['border_strong']};
        border-radius: {RADIUS['md']}px;
        color: {c['text']};
        padding: 10px 16px;
        font-size: 9pt;
    }}
    #Toast[kind="danger"] {{ border-color: {c['danger']}; }}
    #Toast[kind="success"] {{ border-color: {c['ok']}; }}
    QStatusBar {{ background: {c['bg_elev']}; color: {c['text_faint']}; font-size: 8pt; }}
    QStatusBar::item {{ border: none; }}
    """


ACCENT = DARK["accent"]
DANGER = DARK["danger"]
