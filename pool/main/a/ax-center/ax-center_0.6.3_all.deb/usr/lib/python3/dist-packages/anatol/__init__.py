"""Anatol shared library (stdlib only).

Used by:
  * /usr/libexec/anatol-helper   (root, small verb whitelist)
  * anatol-context, anatol-snapshot  (user facing CLIs)
  * ax-center                    (PyQt6 GUI)

Keeping this package free of Qt and free of third party modules means the
whole system stays manageable from a terminal even if the GUI is broken.
"""

__version__ = "0.6.3"
CODENAME = "anatol"
